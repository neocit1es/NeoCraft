package org.neocraft.test;

import org.junit.jupiter.api.Test;
import org.neocraft.adapter.StubAdapter;
import org.neocraft.client.Brand;
import org.neocraft.client.NeoCraft;
import org.neocraft.events.EventBus;
import org.neocraft.events.NeoSubscribe;
import org.neocraft.events.NeoEvent;
import org.neocraft.events.TickEvent;
import org.neocraft.modules.BooleanSetting;
import org.neocraft.modules.ModeSetting;
import org.neocraft.modules.SliderSetting;
import org.neocraft.theme.Theme;
import org.neocraft.theme.ThemePreset;
import org.neocraft.theme.ThemeRegistry;

import static org.junit.jupiter.api.Assertions.*;

class CoreSystemsTest {

	@Test
	void brandStringsAreConsistent() {
		assertEquals("NeoCraft", Brand.NAME);
		assertEquals("v1.0.0", Brand.VERSION_TAG);
		assertEquals("NeoCraft v1.0.0", Brand.FULL_BRAND);
		assertEquals("Minecraft 1.12.2", Brand.MINECRAFT_VERSION);
		assertEquals("neocraft", Brand.CONFIG_DIR);
		assertTrue(Brand.WINDOW_TITLE.contains("NeoCraft v1.0.0"));
		assertEquals(6, Brand.LOADING_MESSAGES.length);
		assertEquals("Done.", Brand.LOADING_MESSAGES[5]);
	}

	@Test
	void themeColorsAreArgb() {
		assertEquals(0xFF00E5FF, Theme.PRIMARY);
		assertEquals(0xFF8B5CF6, Theme.SECONDARY);
		assertEquals(0xFF0E1016, Theme.BACKGROUND);
		assertEquals(0xFFF5F7FA, Theme.TEXT);
		assertEquals(0xFF38D39F, Theme.SUCCESS);
		assertEquals(0xFFF5B041, Theme.WARNING);
		assertEquals(0xFFEF4444, Theme.ERROR);
	}

	@Test
	void themeAlphaAndLerpWork() {
		int c = Theme.withAlpha(Theme.PRIMARY, 0x40);
		assertEquals(0x40, Theme.alpha(c));
		assertEquals(0x00, Theme.red(c) & 0xFF & 0x00); // sanity
		int mid = Theme.lerp(Theme.argb(0x000000), Theme.argb(0xFFFFFF), 0.5f);
		assertTrue(Theme.red(mid) > 100 && Theme.red(mid) < 156);
	}

	@Test
	void themeRegistrySwapsLivePalette() {
		ThemePreset p = ThemeRegistry.get().get("emerald");
		assertNotNull(p);
		ThemeRegistry.get().setActive("emerald");
		assertEquals(Theme.argb(0x38D39F), Theme.livePrimary());
		ThemeRegistry.get().setActive("neocraft");
		assertEquals(Theme.argb(0x00E5FF), Theme.livePrimary());
	}

	@Test
	void settingsSerializeAndDeserialize() {
		BooleanSetting b = new BooleanSetting("x", true);
		b.set(false);
		assertEquals("false", b.serialize());
		b.deserialize("true");
		assertTrue(b.get());

		SliderSetting s = new SliderSetting("s", 0, 100, 50);
		s.set(73);
		assertTrue(s.get() >= 72 && s.get() <= 74);
		s.deserialize("20");
		assertTrue(Math.abs(s.get() - 20) < 0.5);

		SliderSetting si = new SliderSetting("si", null, 0, 10, 5, 1, true);
		assertEquals(5, si.getInt());

		ModeSetting m = new ModeSetting("m", "pick", "A", "B", "C");
		assertEquals("A", m.get());
		m.cycle();
		assertEquals("B", m.get());
		m.deserialize("C");
		assertEquals("C", m.get());
	}

	@Test
	void eventBusDispatchesAndUnregisters() {
		EventBus bus = new EventBus();
		int[] count = {0};
		Object sub = new Object() {
			@NeoSubscribe
			void onTick(TickEvent e) { count[0]++; }
		};
		bus.register(sub);
		bus.post(new TickEvent());
		bus.post(new TickEvent());
		assertEquals(2, count[0]);
		bus.unregister(sub);
		bus.post(new TickEvent());
		assertEquals(2, count[0]);
	}

	@Test
	void eventBusCancellableStopsDispatch() {
		EventBus bus = new EventBus();
		boolean[] secondCalled = {false};
		Object sub = new Object() {
			@NeoSubscribe(priority = 10)
			void first(TickEvent e) { e.cancel(); }
			@NeoSubscribe(priority = 1)
			void second(TickEvent e) { secondCalled[0] = true; }
		};
		bus.register(sub);
		bus.post(new TickEvent());
		assertFalse(secondCalled[0], "lower-priority handler must not run when cancelled");
	}

	@Test
	void neoCraftBootstrapsAndLoadsState() {
		NeoCraft.resetForTesting();
		StubAdapter a = new StubAdapter();
		NeoCraft nc = NeoCraft.init(a);
		assertNotNull(nc);
		assertSame(a, nc.adapter());
		assertTrue(nc.isStarted());
		// idempotent
		assertSame(nc, NeoCraft.init(a));
		nc.shutdown();
		NeoCraft.resetForTesting();
	}
}
