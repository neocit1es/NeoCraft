package org.neocraft.test;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import org.neocraft.adapter.StubAdapter;
import org.neocraft.adapter.StubRenderer;
import org.neocraft.client.NeoCraft;
import org.neocraft.theme.Theme;
import org.neocraft.theme.ThemePreset;
import org.neocraft.theme.ThemeRegistry;
import org.neocraft.util.NotificationManager;
import org.neocraft.util.Profiles;
import org.neocraft.util.ScreenshotManager;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Verifies Phase 7 systems: notification toast lifecycle, profile
 * create/switch/delete, screenshot capture + recent list, and theme registry
 * persistence + live palette updates.
 */
class SystemsTest {

	private StubAdapter adapter;
	private NeoCraft nc;

	@BeforeEach
	void setup() {
		NeoCraft.resetForTesting();
		adapter = new StubAdapter();
		adapter.setScaledSize(854, 480);
		nc = NeoCraft.init(adapter);
	}

	@AfterEach
	void teardown() {
		if (nc != null) nc.shutdown();
		NeoCraft.resetForTesting();
	}

	// ---- Notifications ----------------------------------------------------

	@Test
	void notificationInfoAddsToActive() {
		nc.notifications().info("Test", "Hello");
		assertEquals(1, nc.notifications().activeCount());
	}

	@Test
	void notificationMultipleSeveritiesCoexist() {
		nc.notifications().info("Info", "msg");
		nc.notifications().success("Good", "msg");
		nc.notifications().warning("Warn", "msg");
		nc.notifications().error("Bad", "msg");
		assertEquals(4, nc.notifications().activeCount());
	}

	@Test
	void notificationAutoDismissAfterDuration() {
		nc.notifications().info("Test", "Hello");
		assertEquals(1, nc.notifications().activeCount());
		// advance time past the 3s duration + fade-out
		adapter.advance(3500L);
		nc.notifications().render(0f);
		// Need a few more render calls for anim to fade to 0
		for (int i = 0; i < 15; i++) {
			nc.notifications().render(0f);
		}
		assertEquals(0, nc.notifications().activeCount());
	}

	@Test
	void notificationRendersDrawCalls() {
		nc.notifications().info("Test", "Hello");
		StubRenderer r = (StubRenderer) adapter.renderer();
		int before = r.getDrawCount();
		nc.notifications().render(0f);
		assertTrue(r.getDrawCount() > before, "rendering a notification should produce draw calls");
	}

	@Test
	void notificationClearRemovesAll() {
		nc.notifications().info("A", "a");
		nc.notifications().info("B", "b");
		nc.notifications().clear();
		assertEquals(0, nc.notifications().activeCount());
	}

	// ---- Profiles ---------------------------------------------------------

	@Test
	void profilesDefaultExists() {
		Profiles profiles = nc.profiles();
		assertTrue(profiles.list().contains("Default"));
		assertEquals("Default", profiles.active());
	}

	@Test
	void profilesCreateAddsNewProfile() {
		Profiles profiles = nc.profiles();
		boolean created = profiles.create("PvP");
		assertTrue(created);
		assertTrue(profiles.list().contains("PvP"));
	}

	@Test
	void profilesCreateDuplicateReturnsFalse() {
		Profiles profiles = nc.profiles();
		profiles.create("PvP");
		assertFalse(profiles.create("PvP"));
	}

	@Test
	void profilesSwitchToChangesActive() {
		Profiles profiles = nc.profiles();
		profiles.create("PvP");
		profiles.switchTo("PvP");
		assertEquals("PvP", profiles.active());
	}

	@Test
	void profilesSwitchToUnknownDoesNothing() {
		Profiles profiles = nc.profiles();
		profiles.switchTo("Nonexistent");
		assertEquals("Default", profiles.active());
	}

	@Test
	void profilesDeleteRemovesProfile() {
		Profiles profiles = nc.profiles();
		profiles.create("Temp");
		assertTrue(profiles.delete("Temp"));
		assertFalse(profiles.list().contains("Temp"));
	}

	@Test
	void profilesCannotDeleteDefault() {
		Profiles profiles = nc.profiles();
		assertFalse(profiles.delete("Default"));
		assertTrue(profiles.list().contains("Default"));
	}

	@Test
	void profilesDeleteActiveRevertsToDefault() {
		Profiles profiles = nc.profiles();
		profiles.create("Temp");
		profiles.switchTo("Temp");
		assertEquals("Temp", profiles.active());
		profiles.delete("Temp");
		assertEquals("Default", profiles.active());
	}

	@Test
	void profilesActiveStoreIsNamespace() {
		Profiles profiles = nc.profiles();
		profiles.create("PvP");
		profiles.switchTo("PvP");
		assertNotNull(profiles.activeStore());
		// writing to the active store should be isolated
		profiles.activeStore().set("key", "pvp_value");
		assertEquals("pvp_value", profiles.activeStore().get("key", ""));
	}

	// ---- Screenshot Manager ----------------------------------------------

	@Test
	void screenshotCaptureReturnsFileName() {
		String name = nc.screenshots().capture();
		assertNotNull(name);
		assertTrue(name.startsWith(ScreenshotManager.prefix()));
	}

	@Test
	void screenshotCaptureAddsToRecent() {
		nc.screenshots().capture();
		nc.screenshots().capture();
		assertEquals(2, nc.screenshots().recent().size());
	}

	@Test
	void screenshotRecentCappedAt24() {
		for (int i = 0; i < 30; i++) {
			nc.screenshots().capture();
		}
		assertEquals(24, nc.screenshots().recent().size());
	}

	@Test
	void screenshotMostRecentIsFirstInList() {
		nc.screenshots().capture();
		adapter.advance(100L);
		nc.screenshots().capture();
		// most recent (second capture) should be at index 0
		assertTrue(nc.screenshots().recent().get(0).contains("_100"));
	}

	// ---- Theme Registry ---------------------------------------------------

	@Test
	void themeRegistryHasFiveBuiltinPresets() {
		assertEquals(5, ThemeRegistry.get().presets().size());
	}

	@Test
	void themeRegistryDefaultActiveIsNeocraft() {
		assertEquals("neocraft", ThemeRegistry.get().activeId());
	}

	@Test
	void themeRegistrySwitchUpdatesActiveId() {
		ThemeRegistry.get().setActive("amethyst");
		assertEquals("amethyst", ThemeRegistry.get().activeId());
	}

	@Test
	void themeRegistrySwitchUpdatesLivePalette() {
		ThemePreset amethyst = ThemeRegistry.get().get("amethyst");
		ThemeRegistry.get().setActive("amethyst");
		assertEquals(amethyst.primary, Theme.livePrimary());
		assertEquals(amethyst.background, Theme.liveBackground());
	}

	@Test
	void themeRegistrySwitchToUnknownReturnsFalse() {
		assertFalse(ThemeRegistry.get().setActive("nonexistent"));
	}

	@Test
	void themeRegistrySaveAndLoadState() {
		ThemeRegistry.get().setActive("emerald");
		nc.config().set("theme.active", "emerald");
		// Simulate reload
		ThemeRegistry.get().loadState(nc.config());
		assertEquals("emerald", ThemeRegistry.get().activeId());
	}

	@Test
	void themeRegistryInstallAddsCustomPreset() {
		ThemePreset custom = new ThemePreset("custom", "My Theme",
				Theme.argb(0xFF00FF), Theme.argb(0x00FFFF), Theme.argb(0x000000),
				Theme.argb(0x111111), Theme.argb(0xFFFFFF), Theme.argb(0x00FF00),
				Theme.argb(0xFFFF00), Theme.argb(0xFF0000));
		ThemeRegistry.get().install(custom);
		assertTrue(ThemeRegistry.get().presets().stream()
				.anyMatch(p -> p.id.equals("custom")));
		assertEquals("custom", ThemeRegistry.get().activeId());
	}

	@Test
	void themeRegistryResetRestoresDefaults() {
		ThemeRegistry.get().setActive("crimson");
		Theme.resetPreset();
		// After reset, the live palette should match the Theme static constants
		assertEquals(Theme.PRIMARY, Theme.livePrimary());
		assertEquals(Theme.BACKGROUND, Theme.liveBackground());
	}

	// ---- Notification + Module integration -------------------------------

	@Test
	void notificationsTriggerModuleFiresToastOnLowHealth() {
		// Enable the notifications module
		org.neocraft.modules.Module n = nc.modules().get("Notifications");
		assertNotNull(n);
		n.enable();
		// Wire up a low-health situation
		adapter.setHealth(4.0f);
		adapter.setMaxHealth(20.0f);
		nc.events().post(new org.neocraft.events.TickEvent());
		// The NotificationsTrigger module should have fired a warning toast
		assertTrue(nc.notifications().activeCount() > 0,
				"low health should trigger a notification");
	}

	// ---- Theme + GUI integration -----------------------------------------

	@Test
	void themeChangeAffectsPanelRendererColors() {
		// Before switching, livePrimary should be the default cyan
		assertEquals(Theme.PRIMARY, Theme.livePrimary());
		// Switch to crimson (red primary)
		ThemeRegistry.get().setActive("crimson");
		assertEquals(ThemeRegistry.get().get("crimson").primary, Theme.livePrimary());
		// Render a screen to verify it uses the new colors without error
		org.neocraft.gui.MainMenu menu = new org.neocraft.gui.MainMenu(adapter, (m, id) -> {});
		menu.onOpen();
		menu.render(0f);
		assertTrue(((StubRenderer) adapter.renderer()).getDrawCount() > 0);
	}
}
