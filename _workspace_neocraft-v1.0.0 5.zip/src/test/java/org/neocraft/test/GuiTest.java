package org.neocraft.test;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import org.neocraft.adapter.StubAdapter;
import org.neocraft.adapter.StubRenderer;
import org.neocraft.client.NeoCraft;
import org.neocraft.gui.ClickGui;
import org.neocraft.gui.CreditsScreen;
import org.neocraft.gui.LoadingScreen;
import org.neocraft.gui.MainMenu;
import org.neocraft.gui.SettingsScreen;
import org.neocraft.modules.Category;
import org.neocraft.theme.ThemeRegistry;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Verifies the Phase 6 GUI screens: main menu button layout, ClickGUI
 * category/search/expand, settings screen theme switching, credits rendering,
 * and loading screen progress.
 */
class GuiTest {

	private StubAdapter adapter;
	private StubRenderer renderer;
	private NeoCraft nc;

	@BeforeEach
	void setup() {
		NeoCraft.resetForTesting();
		adapter = new StubAdapter();
		adapter.setScaledSize(854, 480);
		renderer = (StubRenderer) adapter.renderer();
		nc = NeoCraft.init(adapter);
	}

	@AfterEach
	void teardown() {
		if (nc != null) nc.shutdown();
		NeoCraft.resetForTesting();
	}

	// ---- Main Menu --------------------------------------------------------

	@Test
	void mainMenuButtonIdAtReturnsCorrectButton() {
		// Button 0 ("singleplayer") is the first in the stack
		double stackY = 480 * 0.18 + 90 + 32;
		String id = MainMenu.buttonIdAt(854, 480, 854 / 2.0, stackY + 19);
		assertNotNull(id);
		assertEquals("singleplayer", id);
	}

	@Test
	void mainMenuButtonIdAtReturnsNullOutsideButtons() {
		String id = MainMenu.buttonIdAt(854, 480, 10, 10);
		assertNull(id);
	}

	@Test
	void mainMenuFiresActionOnButtonClick() {
		final boolean[] fired = { false };
		final String[] firedId = { null };
		MainMenu menu = new MainMenu(adapter, (m, id) -> { fired[0] = true; firedId[0] = id; });
		menu.onOpen();
		menu.render(0f);

		// Click on the first button
		double bx = (854 - 240) / 2.0;
		double by = 480 * 0.18 + 90 + 32;
		menu.onMouseClick(bx + 120, by + 19, 0);
		assertTrue(fired[0]);
		assertEquals("singleplayer", firedId[0]);
	}

	@Test
	void mainMenuRendersWithoutError() {
		MainMenu menu = new MainMenu(adapter, (m, id) -> {});
		menu.onOpen();
		menu.render(0f);
		assertTrue(renderer.getDrawCount() > 0);
	}

	// ---- ClickGUI ---------------------------------------------------------

	@Test
	void clickGuiStartsOnCombatCategory() {
		ClickGui gui = new ClickGui(adapter);
		gui.onOpen();
		gui.render(0f);
		assertEquals(Category.COMBAT, gui.selectedCategory());
	}

	@Test
	void clickGuiSearchFiltersModules() {
		ClickGui gui = new ClickGui(adapter);
		gui.onOpen();
		// Type "fps" into the search bar
		gui.onKeyPress(0, 'f');
		gui.onKeyPress(0, 'p');
		gui.onKeyPress(0, 's');
		assertEquals("fps", gui.query());
		gui.render(0f);
	}

	@Test
	void clickGuiEscapeClosesScreen() {
		ClickGui gui = new ClickGui(adapter);
		gui.onOpen();
		assertTrue(gui.isOpen());
		gui.onKeyPress(1, (char) 0);
		assertFalse(gui.isOpen());
	}

	@Test
	void clickGuiSearchBackspaceRemovesLastChar() {
		ClickGui gui = new ClickGui(adapter);
		gui.onOpen();
		gui.onKeyPress(0, 'a');
		gui.onKeyPress(0, 'b');
		assertEquals("ab", gui.query());
		gui.onKeyPress(14, (char) 0); // backspace
		assertEquals("a", gui.query());
	}

	@Test
	void clickGuiRendersWithoutError() {
		ClickGui gui = new ClickGui(adapter);
		gui.onOpen();
		gui.render(0f);
		assertTrue(renderer.getDrawCount() > 0);
	}

	// ---- Settings Screen --------------------------------------------------

	@Test
	void settingsScreenStartsOnThemeTab() {
		SettingsScreen settings = new SettingsScreen(adapter);
		settings.onOpen();
		settings.render(0f);
		assertEquals("THEME", settings.activeTab());
	}

	@Test
	void settingsScreenThemeSwitchChangesActivePreset() {
		SettingsScreen settings = new SettingsScreen(adapter);
		settings.onOpen();
		settings.render(0f);

		// default active theme is "neocraft"
		assertEquals("neocraft", ThemeRegistry.get().activeId());

		// Click on the second preset card (index 1 = amethyst, right column)
		// Panel: px = (854-700)/2 = 77, py = (480-440)/2 = 20
		// sidebar = 140, content x = 77 + 140 + 10 = 227
		// card width = (560)/2 - 6 = 274
		// second card column x = 227 + 280 + 6 = 513 (right column)
		double panelW = 700;
		double contentX = 77 + 140 + 10;
		double cardW = (panelW - 140 - 20) / 2.0 - 6;
		double rightCardX = contentX + cardW + 6;
		double cardY = 20 + 64 + 30;
		settings.onMouseClick(rightCardX + 10, cardY + 10, 0);
		// Theme should have changed to the second preset (amethyst)
		assertNotNull(ThemeRegistry.get().activeId());
	}

	@Test
	void settingsScreenSearchFiltersPresets() {
		SettingsScreen settings = new SettingsScreen(adapter);
		settings.onOpen();
		settings.onKeyPress(0, 'a');
		settings.onKeyPress(0, 'm');
		settings.onKeyPress(0, 'e');
		assertEquals("ame", settings.query());
		settings.render(0f);
	}

	@Test
	void settingsScreenEscapeCloses() {
		SettingsScreen settings = new SettingsScreen(adapter);
		settings.onOpen();
		assertTrue(settings.isOpen());
		settings.onKeyPress(1, (char) 0);
		assertFalse(settings.isOpen());
	}

	@Test
	void settingsScreenRendersWithoutError() {
		SettingsScreen settings = new SettingsScreen(adapter);
		settings.onOpen();
		settings.render(0f);
		assertTrue(renderer.getDrawCount() > 0);
	}

	// ---- Credits Screen ---------------------------------------------------

	@Test
	void creditsScreenRendersWithoutError() {
		CreditsScreen credits = new CreditsScreen(adapter);
		credits.onOpen();
		credits.render(0f);
		assertTrue(renderer.getDrawCount() > 0);
	}

	@Test
	void creditsScreenEscapeCloses() {
		CreditsScreen credits = new CreditsScreen(adapter);
		credits.onOpen();
		assertTrue(credits.isOpen());
		credits.onKeyPress(1, (char) 0);
		assertFalse(credits.isOpen());
	}

	// ---- Loading Screen ---------------------------------------------------

	@Test
	void loadingScreenProgressUpdates() {
		LoadingScreen loading = new LoadingScreen(adapter);
		loading.onOpen();
		loading.setProgress(0.5f);
		loading.render(0f);
		assertTrue(renderer.getDrawCount() > 0);
	}

	@Test
	void loadingScreenCompletesAtFullProgress() {
		LoadingScreen loading = new LoadingScreen(adapter);
		loading.onOpen();
		assertFalse(loading.isDone());
		loading.setProgress(1.0f);
		assertTrue(loading.isDone());
	}

	@Test
	void loadingScreenMessageCanBeOverridden() {
		LoadingScreen loading = new LoadingScreen(adapter);
		loading.setMessage("Custom message");
		loading.render(0f);
		assertNotNull(loading);
	}

	// ---- Screen fade animations ------------------------------------------

	@Test
	void screenFadeInAnimatesOnOpen() {
		MainMenu menu = new MainMenu(adapter, (m, id) -> {});
		menu.onOpen();
		assertEquals(0f, menu.fade(), 0.01f);
		// advance time and render to let the animation update
		adapter.advance(200L);
		menu.render(0f);
		assertTrue(menu.fade() > 0f, "fade should increase after time advances");
	}
}
