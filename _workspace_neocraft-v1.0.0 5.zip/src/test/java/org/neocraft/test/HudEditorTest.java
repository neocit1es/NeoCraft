package org.neocraft.test;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import org.neocraft.adapter.StubAdapter;
import org.neocraft.client.NeoCraft;
import org.neocraft.hud.HudElement;
import org.neocraft.hud.HudManager;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Verifies the Phase 5 HUD editor: dragging elements, editor toggle, and the
 * HUD editor module wiring.
 */
class HudEditorTest {

	private StubAdapter adapter;
	private NeoCraft nc;

	@BeforeEach
	void setup() {
		NeoCraft.resetForTesting();
		adapter = new StubAdapter();
		adapter.setScaledSize(854, 480);
		nc = NeoCraft.init(adapter);
	}

	@AfterEach
	void teardown() {
		if (nc != null) nc.shutdown();
		NeoCraft.resetForTesting();
	}

	@Test
	void editorToggles() {
		HudManager hud = nc.hud();
		assertFalse(hud.isEditor());
		hud.toggleEditor();
		assertTrue(hud.isEditor());
		hud.toggleEditor();
		assertFalse(hud.isEditor());
	}

	@Test
	void editorModuleTogglesHudEditor() {
		var mod = nc.modules().get("HUDEditor");
		assertNotNull(mod);
		assertFalse(nc.hud().isEditor());
		mod.enable();
		assertTrue(nc.hud().isEditor());
		mod.disable();
		assertFalse(nc.hud().isEditor());
	}

	@Test
	void draggingMovesElement() {
		HudManager hud = nc.hud();
		HudElement fps = hud.get("fps");
		assertNotNull(fps);
		assertTrue(fps.isEnabled());
		hud.setEditor(true);
		double startX = fps.getX();
		double startY = fps.getY();
		// click on the element
		boolean clicked = hud.onMouseClick(startX + 4, startY + 4);
		assertTrue(clicked, "click should grab the element");
		// drag to a new position
		hud.onMouseDrag(200, 200);
		// element should have moved
		assertTrue(fps.getX() != startX || fps.getY() != startY, "element should move on drag");
		hud.onMouseRelease();
		assertFalse(fps.isDragging(), "release should stop dragging");
	}

	@Test
	void dragClampsToViewport() {
		HudManager hud = nc.hud();
		HudElement fps = hud.get("fps");
		assertNotNull(fps);
		hud.setEditor(true);
		hud.onMouseClick(fps.getX() + 2, fps.getY() + 2);
		// drag far off-screen
		hud.onMouseDrag(-500, -500);
		assertTrue(fps.getX() >= 0, "x should clamp >= 0, got " + fps.getX());
		assertTrue(fps.getY() >= 0, "y should clamp >= 0, got " + fps.getY());
		hud.onMouseRelease();
	}

	@Test
	void editorRendersWithoutError() {
		HudManager hud = nc.hud();
		hud.setEditor(true);
		// should render all elements + editor frames without throwing
		hud.render(0f);
		hud.setEditor(false);
		hud.render(0f);
	}

	@Test
	void elementLookupById() {
		assertNotNull(nc.hud().get("fps"));
		assertNotNull(nc.hud().get("ping"));
		assertNotNull(nc.hud().get("keystrokes"));
		assertNotNull(nc.hud().get("session"));
	}
}
