package org.neocraft.test;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import org.neocraft.adapter.StubAdapter;
import org.neocraft.client.NeoCraft;
import org.neocraft.events.EventBus;
import org.neocraft.events.KeyInputEvent;
import org.neocraft.modules.Category;
import org.neocraft.modules.Module;
import org.neocraft.modules.ModuleManager;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Verifies the Phase 3 functional modules behave correctly against the stub
 * adapter: Fullbright gamma, Sprint sprinting, NotificationsTrigger firing,
 * HUD-toggle modules syncing their element, favourites, and registry
 * completeness.
 */
class ModulesTest {

	private StubAdapter adapter;
	private NeoCraft nc;

	@BeforeEach
	void setup() {
		NeoCraft.resetForTesting();
		adapter = new StubAdapter();
		nc = NeoCraft.init(adapter);
	}

	@AfterEach
	void teardown() {
		if (nc != null) nc.shutdown();
		NeoCraft.resetForTesting();
	}

	@Test
	void builtinModulesAreRegistered() {
		ModuleManager mm = nc.modules();
		// render + movement + misc + 9 HUD toggles = 15
		assertTrue(mm.all().size() >= 14, "expected at least 14 builtin modules, got " + mm.all().size());
		assertNotNull(mm.get("Fullbright"));
		assertNotNull(mm.get("Sprint"));
		assertNotNull(mm.get("Zoom"));
		assertNotNull(mm.get("ReachDisplay"));
		assertNotNull(mm.get("Notifications"));
		assertNotNull(mm.get("FPS"));
		assertNotNull(mm.get("Keystrokes"));
		assertNotNull(mm.get("SessionStats"));
	}

	@Test
	void fullbrightSetsAndRestoresGamma() {
		adapter.setGamma(0.5f);
		Module fb = nc.modules().get("Fullbright");
		assertNotNull(fb);
		assertFalse(fb.isEnabled());
		fb.enable();
		assertTrue(adapter.getGamma() >= 14.0, "gamma should be maxed, was " + adapter.getGamma());
		fb.disable();
		assertEquals(0.5f, adapter.getGamma(), 0.001, "gamma should be restored to 0.5");
	}

	@Test
	void sprintForcesSprintingWhenForwardHeld() {
		Module sprint = nc.modules().get("Sprint");
		assertNotNull(sprint);
		sprint.enable();
		// forward not held -> not sprinting (drive via the event bus tick)
		nc.events().post(new org.neocraft.events.TickEvent());
		assertFalse(adapter.isSprinting(), "should not sprint without forward");

		// hold W (LWJGL 17)
		adapter.setKey(17, true);
		nc.events().post(new org.neocraft.events.TickEvent());
		assertTrue(adapter.isSprinting(), "should sprint with forward held");

		adapter.setKey(17, false);
		sprint.disable();
		assertFalse(adapter.isSprinting(), "sprint cleared on disable");
	}

	@Test
	void notificationsTriggerFiresOnLowHealth() {
		Module n = nc.modules().get("Notifications");
		assertNotNull(n);
		n.enable();
		adapter.setHealth(4f);
		adapter.setMaxHealth(20f);
		nc.events().post(new org.neocraft.events.TickEvent());
		assertTrue(nc.notifications().activeCount() >= 1, "low-health notification should fire");
	}

	@Test
	void hudToggleModuleSyncsElementVisibility() {
		Module fps = nc.modules().get("FPS");
		assertNotNull(fps);
		// Find the matching HUD element
		var el = nc.hud().elements().stream().filter(e -> e.id().equals("fps")).findFirst().orElse(null);
		assertNotNull(el);
		boolean before = el.isEnabled();
		fps.enable();
		assertTrue(el.isEnabled(), "enabling FPS module should show the HUD element");
		fps.disable();
		assertFalse(el.isEnabled(), "disabling FPS module should hide the HUD element");
		// restore
		el.setEnabled(before);
	}

	@Test
	void keybindTogglesModule() {
		Module fb = nc.modules().get("Fullbright");
		assertNotNull(fb);
		fb.setKeyCode(33); // 'F'
		assertFalse(fb.isEnabled());
		nc.events().post(new KeyInputEvent(33, 'f'));
		assertTrue(fb.isEnabled(), "keybind should toggle the module on");
		nc.events().post(new KeyInputEvent(33, 'f'));
		assertFalse(fb.isEnabled(), "keybind should toggle the module off");
	}

	@Test
	void favouritesAreTracked() {
		Module fb = nc.modules().get("Fullbright");
		assertNotNull(fb);
		assertFalse(fb.isFavourite());
		fb.setFavourite(true);
		assertEquals(1, nc.modules().favourites().size());
		assertTrue(nc.modules().favourites().contains(fb));
		fb.setFavourite(false);
		assertEquals(0, nc.modules().favourites().size());
	}

	@Test
	void searchFindsModules() {
		var results = nc.modules().search("bright");
		assertFalse(results.isEmpty());
		assertTrue(results.stream().anyMatch(m -> m.name().equals("Fullbright")));
	}

	@Test
	void modulesAreGroupedByCategory() {
		ModuleManager mm = nc.modules();
		assertTrue(mm.inCategory(Category.RENDER).size() >= 3, "render category should have >= 3");
		assertTrue(mm.inCategory(Category.MOVEMENT).size() >= 1);
		assertTrue(mm.inCategory(Category.HUD).size() >= 9, "HUD category should have >= 9 toggles");
	}
}
