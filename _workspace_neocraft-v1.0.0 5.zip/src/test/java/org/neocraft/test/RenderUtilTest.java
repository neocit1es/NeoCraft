package org.neocraft.test;

import org.junit.jupiter.api.Test;

import org.neocraft.adapter.StubFont;
import org.neocraft.adapter.StubRenderer;
import org.neocraft.util.Animation;
import org.neocraft.util.Easing;
import org.neocraft.util.RenderUtil;
import org.neocraft.util.TextCache;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Verifies the Phase 4 render & animation utilities.
 */
class RenderUtilTest {

	@Test
	void easingClampsAndReverses() {
		assertEquals(0f, Easing.linear(0f));
		assertEquals(1f, Easing.linear(1f));
		assertEquals(0f, Easing.easeIn(-0.5f), "negative clamps to 0");
		assertEquals(1f, Easing.easeOut(2f), "overshoot clamps to 1");
		// ease-out should be >= linear at the midpoint (decelerating)
		assertTrue(Easing.easeOut(0.5f) >= Easing.linear(0.5f));
		// ease-in should be <= linear at the midpoint (accelerating)
		assertTrue(Easing.easeIn(0.5f) <= Easing.linear(0.5f));
	}

	@Test
	void easeInOutIsSymmetricAtMidpoint() {
		// at t=0.5 ease-in-out should be ~0.5
		assertEquals(0.5f, Easing.easeInOut(0.5f), 0.01f);
	}

	@Test
	void easeOutBackOvershootsThenSettles() {
		// back easing overshoots past 1 near the end, then returns to 1
		float nearEnd = Easing.easeOutBack(0.85f);
		assertTrue(nearEnd > 1f, "back easing should overshoot near end, got " + nearEnd);
		assertEquals(1f, Easing.easeOutBack(1f), 0.001f);
	}

	@Test
	void animationSnapsAndSettles() {
		Animation a = new Animation(0f);
		a.snap(5f);
		assertEquals(5f, a.value());
		assertTrue(a.settled());
	}

	@Test
	void animationContinuousLerpApproachesTarget() {
		Animation a = new Animation(0f);
		a.speed(0.5f);
		a.target(10f);
		// after one update at 50% speed: 0 + 10*0.5 = 5
		a.update(0L);
		assertEquals(5f, a.value(), 0.001f);
		// next update: 5 + 5*0.5 = 7.5
		a.update(0L);
		assertEquals(7.5f, a.value(), 0.001f);
	}

	@Test
	void animationDurationReachesTarget() {
		Animation a = new Animation(0f);
		a.to(100f, 1000L, 0L); // explicit clock start at 0
		assertTrue(a.isAnimating());
		// halfway
		a.update(500L);
		assertTrue(a.value() > 0f && a.value() < 100f, "midpoint should be in transit, got " + a.value());
		// complete
		a.update(1500L);
		assertEquals(100f, a.value(), 0.001f);
		assertTrue(!a.isAnimating());
	}

	@Test
	void textCacheCachesWidths() {
		StubFont font = new StubFont(); // 6px per char
		TextCache cache = new TextCache(font);
		assertEquals(6 * 5, cache.width("hello"));
		// second call should be cached (size still 1)
		cache.width("hello");
		assertEquals(1, cache.size());
		assertEquals(6 * 3, cache.width("abc"));
		assertEquals(2, cache.size());
	}

	@Test
	void textCacheTruncatesWithEllipsis() {
		StubFont font = new StubFont();
		TextCache cache = new TextCache(font);
		// "hello" = 30px; maxWidth 20 -> should truncate
		String t = cache.truncate("hello", 20);
		assertTrue(t.endsWith("\u2026"));
		assertTrue(cache.width(t) <= 20);
	}

	@Test
	void renderUtilProgressBarClamps() {
		StubRenderer r = new StubRenderer();
		RenderUtil util = new RenderUtil(r);
		// progress out of range should clamp without error
		util.progressBar(0, 0, 100, 10, -0.5, 0xFF000000, 0xFF111111);
		util.progressBar(0, 0, 100, 10, 1.5, 0xFF000000, 0xFF111111);
		assertTrue(r.getDrawCount() > 0, "progress bar should draw something");
	}

	@Test
	void renderUtilGlowDrawsLayers() {
		StubRenderer r = new StubRenderer();
		RenderUtil util = new RenderUtil(r);
		int before = r.getDrawCount();
		util.glow(10, 10, 50, 20, 0xFF00E5FF, 4);
		assertTrue(r.getDrawCount() > before, "glow should add draw calls");
	}
}
