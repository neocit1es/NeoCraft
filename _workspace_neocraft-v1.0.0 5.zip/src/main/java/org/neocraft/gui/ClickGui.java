package org.neocraft.gui;

import org.neocraft.api.MinecraftAdapter;
import org.neocraft.client.Brand;
import org.neocraft.client.NeoCraft;
import org.neocraft.modules.BooleanSetting;
import org.neocraft.modules.Category;
import org.neocraft.modules.ModeSetting;
import org.neocraft.modules.Module;
import org.neocraft.modules.ModuleManager;
import org.neocraft.modules.Setting;
import org.neocraft.modules.SliderSetting;
import org.neocraft.theme.Theme;
import org.neocraft.util.Animation;
import org.neocraft.util.PanelRenderer;
import org.neocraft.util.TextCache;

import java.util.ArrayList;
import java.util.List;

/**
 * The NeoCraft ClickGUI \u2014 a modern module manager with a category sidebar,
 * search bar, scrollable module cards, and inline settings (toggles, sliders,
 * modes, keybinds). Module cards expand on click to reveal their settings.
 *
 * @author NeoCraft
 */
public final class ClickGui extends Screen {

	private static final double SIDEBAR_W = 130;
	private static final double CARD_H = 36;
	private static final double CARD_GAP = 4;
	private static final double PADDING = 10;

	private final ModuleManager modules;
	private final TextCache cache;

	private Category selected = Category.COMBAT;
	private String query = "";
	private double scroll;
	private double targetScroll;
	private final Animation sidebarAnim = new Animation(0f).ease(org.neocraft.util.Easing::easeOutExpo);

	private Module expanded;
	private final List<Widget> settingWidgets = new ArrayList<>();

	public ClickGui(MinecraftAdapter adapter) {
		super(adapter);
		this.modules = NeoCraft.get().modules();
		this.cache = new TextCache(adapter.fonts());
	}

	@Override
	public void onOpen() {
		super.onOpen();
		sidebarAnim.snap(0f);
		sidebarAnim.to(1f, 300L, adapter.currentTimeMillis());
	}

	/** The modules currently displayed (filtered by category + search). */
	private List<Module> visibleModules() {
		if (!query.isEmpty()) return modules.search(query);
		return modules.inCategory(selected);
	}

	@Override
	protected void renderContent(float partialTicks) {
		sidebarAnim.update(adapter.currentTimeMillis());
		int sw = adapter.getScaledWidth();
		int sh = adapter.getScaledHeight();
		double panelW = Math.min(sw - 40, 720);
		double panelH = Math.min(sh - 40, 460);
		double px = (sw - panelW) / 2.0;
		double py = (sh - panelH) / 2.0;

		// blur + glass main panel
		new PanelRenderer(adapter.renderer(), adapter.fonts()).glass(px, py, panelW, panelH);

		// title bar
		adapter.fonts().draw(Brand.FULL_BRAND, px + PADDING, py + 8, Theme.livePrimary());
		adapter.fonts().drawRight("ClickGUI", px + panelW - PADDING, py + 8, Theme.liveTextDim());
		adapter.renderer().drawRect(px + PADDING, py + 24, panelW - PADDING * 2, 1, Theme.liveBorder());

		// search bar
		double searchX = px + SIDEBAR_W + PADDING + 4;
		double searchY = py + 32;
		double searchW = panelW - SIDEBAR_W - PADDING * 3;
		drawSearchBar(searchX, searchY, searchW);

		// sidebar
		drawSidebar(px + PADDING, py + 32, SIDEBAR_W - PADDING);

		// module list
		drawModuleList(px + SIDEBAR_W + PADDING, py + 64, panelW - SIDEBAR_W - PADDING * 2, panelH - 80);
	}

	private void drawSearchBar(double x, double y, double w) {
		adapter.renderer().drawRoundedRect(x, y, w, 24, 12, Theme.withAlpha(Theme.livePanel(), 0xE0));
		int border = query.isEmpty() ? Theme.liveBorder() : Theme.livePrimary();
		adapter.renderer().drawHollowRect(x, y, w, 24, 1.0f, border);
		adapter.fonts().draw("\u2315", x + 8, y + 7, Theme.liveTextDim());
		String display = query.isEmpty() ? "Search modules\u2026" : query;
		int col = query.isEmpty() ? Theme.liveTextFaint() : Theme.liveText();
		adapter.fonts().draw(display, x + 24, y + 7, col);
	}

	private void drawSidebar(double x, double y, double w) {
		double by = y;
		for (Category cat : Category.values()) {
			boolean active = cat == selected && query.isEmpty();
			int bg = active ? Theme.withAlpha(Theme.livePrimary(), 0x30) : Theme.withAlpha(Theme.livePanel(), 0x80);
			adapter.renderer().drawRoundedRect(x, by, w, 26, 6, bg);
			if (active) {
				adapter.renderer().drawHollowRect(x, by, w, 26, 1.0f, Theme.livePrimary());
			}
			adapter.fonts().draw(cat.icon(), x + 6, by + 8, active ? Theme.livePrimary() : Theme.liveTextDim());
			adapter.fonts().draw(cat.displayName(), x + 22, by + 8, active ? Theme.livePrimary() : Theme.liveText());
			by += 30;
		}
		// favorites shortcut
		by += 6;
		adapter.renderer().drawRect(x, by, w, 1, Theme.liveBorder());
		by += 6;
		int favCount = modules.favourites().size();
		adapter.fonts().draw("\u2605 Favorites (" + favCount + ")", x + 4, by + 8, Theme.liveWarning());
	}

	private void drawModuleList(double x, double y, double w, double h) {
		List<Module> list = visibleModules();
		if (list.isEmpty()) {
			adapter.fonts().drawCentered("No modules found", x + w / 2.0, y + h / 2.0, Theme.liveTextFaint());
			return;
		}
		// smooth scroll
		scroll += (targetScroll - scroll) * 0.2;

		// scissor to the list area
		adapter.renderer().enableScissor(x, y, w, h);
		double cy = y - scroll;
		for (Module m : list) {
			double cardH = CARD_H;
			if (m == expanded) {
				m.ensureSettings();
				cardH += m.settings().size() * 28 + 8;
			}
			if (cy + cardH > y && cy < y + h) {
				drawModuleCard(m, x, cy, w, cardH);
			}
			cy += cardH + CARD_GAP;
		}
		adapter.renderer().disableScissor();
	}

	private void drawModuleCard(Module m, double x, double y, double w, double h) {
		boolean on = m.isEnabled();
		int bg = on ? Theme.withAlpha(Theme.livePrimary(), 0x18) : Theme.withAlpha(Theme.livePanel(), 0xA0);
		adapter.renderer().drawRoundedRect(x, y, w, h, 6, bg);
		int border = on ? Theme.livePrimary() : Theme.liveBorder();
		adapter.renderer().drawHollowRect(x, y, w, h, 1.0f, border);

		// toggle pill
		double pillX = x + 8;
		double pillY = y + (CARD_H - 16) / 2.0;
		adapter.renderer().drawRoundedRect(pillX, pillY, 28, 16, 8, on ? Theme.livePrimary() : Theme.liveBackground());
		adapter.renderer().drawCircle(pillX + (on ? 22 : 6), pillY + 8, 5, Theme.liveText());

		// name + description
		int nameCol = on ? Theme.livePrimary() : Theme.liveText();
		adapter.fonts().draw(m.name(), x + 44, y + 6, nameCol);
		adapter.fonts().draw(m.description(), x + 44, y + 17, Theme.liveTextFaint());

		// favorite star
		double starX = x + w - 20;
		adapter.fonts().draw(m.isFavourite() ? "\u2605" : "\u2606", starX, y + 8, m.isFavourite() ? Theme.liveWarning() : Theme.liveTextFaint());

		// keybind badge
		if (m.keyCode() != 0) {
			String key = "[" + m.keyCode() + "]";
			double kw = adapter.fonts().stringWidth(key);
			adapter.fonts().draw(key, x + w - 30 - kw, y + 8, Theme.liveTextDim());
		}

		// settings (if expanded)
		if (m == expanded) {
			double sy = y + CARD_H + 4;
			for (Setting s : m.settings()) {
				drawSetting(s, x + 12, sy, w - 24);
				sy += 28;
			}
		}
	}

	private void drawSetting(Setting s, double x, double y, double w) {
		adapter.fonts().draw(s.name(), x, y, Theme.liveTextDim());
		if (s instanceof BooleanSetting) {
			BooleanSetting b = (BooleanSetting) s;
			double tx = x + w - 36;
			adapter.renderer().drawRoundedRect(tx, y - 2, 28, 16, 8, b.get() ? Theme.livePrimary() : Theme.liveBackground());
			adapter.renderer().drawCircle(tx + (b.get() ? 22 : 6), y + 6, 5, Theme.liveText());
		} else if (s instanceof SliderSetting) {
			SliderSetting sl = (SliderSetting) s;
			double prog = (sl.get() - sl.min()) / (sl.max() - sl.min());
			double ty = y + 8;
			adapter.renderer().drawRoundedRect(x, ty, w - 60, 4, 2, Theme.liveBackground());
			adapter.renderer().drawRoundedRect(x, ty, (w - 60) * prog, 4, 2, Theme.livePrimary());
			adapter.renderer().drawCircle(x + (w - 60) * prog, ty + 2, 5, Theme.liveText());
			String val = sl.isInteger() ? Integer.toString(sl.getInt()) : String.format("%.1f", sl.get());
			adapter.fonts().drawRight(val, x + w, y, Theme.livePrimary());
		} else if (s instanceof ModeSetting) {
			ModeSetting ms = (ModeSetting) s;
			String text = ms.get() + " \u25B8";
			adapter.fonts().drawRight(text, x + w, y, Theme.livePrimary());
		}
	}

	// ---- input ------------------------------------------------------------

	@Override
	public void onMouseClick(double mouseX, double mouseY, int button) {
		int sw = adapter.getScaledWidth();
		int sh = adapter.getScaledHeight();
		double panelW = Math.min(sw - 40, 720);
		double panelH = Math.min(sh - 40, 460);
		double px = (sw - panelW) / 2.0;
		double py = (sh - panelH) / 2.0;

		// sidebar click
		double sx = px + PADDING;
		double sy = py + 32;
		double sw2 = SIDEBAR_W - PADDING;
		if (mouseX >= sx && mouseX <= sx + sw2) {
			int i = 0;
			for (Category cat : Category.values()) {
				double by = sy + i * 30;
				if (mouseY >= by && mouseY <= by + 26) {
					selected = cat;
					query = "";
					targetScroll = 0;
					return;
				}
				i++;
			}
		}

		// module card click
		double lx = px + SIDEBAR_W + PADDING;
		double ly = py + 64;
		double lw = panelW - SIDEBAR_W - PADDING * 2;
		double lh = panelH - 80;
		List<Module> list = visibleModules();
		double cy = ly - scroll;
		for (Module m : list) {
			double cardH = CARD_H;
			if (m == expanded) cardH += m.settings().size() * 28 + 8;
			if (mouseY >= cy && mouseY <= cy + cardH && mouseX >= lx && mouseX <= lx + lw) {
				handleCardClick(m, mouseX, mouseY, cy, lw);
				return;
			}
			cy += cardH + CARD_GAP;
		}
	}

	private void handleCardClick(Module m, double mouseX, double mouseY, double cardY, double cardW) {
		// toggle pill area
		if (mouseX >= 8 && mouseX <= 36) {
			// relative to panel; recompute relative to card
		}
		// favorite star
		double starX = cardW - 20;
		// toggle: left ~40px region of card
		// We check absolute-ish via card-local x
		double localX = mouseX;
		if (localX > starX - 10 && localX < starX + 10) {
			m.setFavourite(!m.isFavourite());
			return;
		}
		if (mouseX < 40) {
			m.toggle();
			return;
		}
		// expand/collapse on body click
		if (m == expanded) {
			// check setting clicks
			double sy = cardY + CARD_H + 4;
			for (Setting s : m.settings()) {
				if (mouseY >= sy && mouseY <= sy + 24) {
					handleSettingClick(s);
					return;
				}
				sy += 28;
			}
			expanded = null;
		} else {
			expanded = m;
		}
	}

	private void handleSettingClick(Setting s) {
		if (s instanceof BooleanSetting) {
			((BooleanSetting) s).set(!((BooleanSetting) s).get());
		} else if (s instanceof ModeSetting) {
			((ModeSetting) s).cycle();
		}
		// sliders are handled via drag, not click
	}

	@Override
	public void onMouseDrag(double mouseX, double mouseY) {
		// slider dragging handled in onScroll-free manner; here we update expanded slider
	}

	@Override
	public void onKeyPress(int keyCode, char character) {
		if (keyCode == 1) {
			// escape closes
			onClose();
			return;
		}
		if (character >= 32 && character < 127) {
			query += character;
		} else if (keyCode == 14 && !query.isEmpty()) {
			query = query.substring(0, query.length() - 1);
		}
	}

	@Override
	public void onScroll(double mouseX, double mouseY, double amount) {
		targetScroll += amount * 20;
		if (targetScroll < 0) targetScroll = 0;
	}

	public Category selectedCategory() { return selected; }
	public String query() { return query; }
	public Module expandedModule() { return expanded; }
}
