package org.neocraft.gui;

import org.neocraft.api.MinecraftAdapter;
import org.neocraft.theme.Theme;

import java.util.function.Consumer;

/**
 * A text input field with a search icon, used by the ClickGUI and settings
 * screen for filtering modules.
 *
 * @author NeoCraft
 */
public class SearchBar extends Widget {

	private String query = "";
	private boolean focused;
	private final Consumer<String> onQuery;
	private int caretBlink;

	public SearchBar(MinecraftAdapter adapter, double x, double y, double width, Consumer<String> onQuery) {
		super(adapter, x, y, width, 24);
		this.onQuery = onQuery;
	}

	public String query() { return query; }
	public boolean isFocused() { return focused; }
	public void clear() { query = ""; if (onQuery != null) onQuery.accept(""); }

	@Override
	protected void draw(float partialTicks) {
		adapter.renderer().drawRoundedRect(x, y, width, height, height / 2.0, Theme.withAlpha(Theme.livePanel(), 0xE0));
		int border = focused ? Theme.livePrimary() : Theme.liveBorder();
		adapter.renderer().drawHollowRect(x, y, width, height, 1.0f, border);
		// search icon (magnifier glyph)
		adapter.fonts().draw("\u2315", x + 8, y + (height - adapter.fonts().fontHeight()) / 2.0, Theme.liveTextDim());
		// query or placeholder
		String display = query.isEmpty() ? "Search modules\u2026" : query;
		int col = query.isEmpty() ? Theme.liveTextFaint() : Theme.liveText();
		adapter.fonts().draw(display, x + 24, y + (height - adapter.fonts().fontHeight()) / 2.0, col);
		// caret blink
		if (focused && query.isEmpty() == false) {
			caretBlink = (caretBlink + 1) % 60;
			if (caretBlink < 30) {
				double cx = x + 24 + adapter.fonts().stringWidth(query);
				adapter.fonts().draw("|", cx, y + (height - adapter.fonts().fontHeight()) / 2.0, Theme.livePrimary());
			}
		}
	}

	@Override
	public void onMousePress(double mouseX, double mouseY, int button) {
		pressed = true;
		focused = hitTest(mouseX, mouseY);
	}

	@Override
	public void onMouseRelease(double mouseX, double mouseY, int button) {
		pressed = false;
	}

	@Override
	public void onKeyPress(int keyCode, char character) {
		if (!focused) return;
		// LWJGL: 14 = backspace, 28 = enter, 1 = escape
		if (keyCode == 14 && !query.isEmpty()) {
			query = query.substring(0, query.length() - 1);
		} else if (keyCode == 1) {
			focused = false;
		} else if (character != 0 && character >= 32 && character < 127) {
			query += character;
		}
		if (onQuery != null) onQuery.accept(query);
	}
}
