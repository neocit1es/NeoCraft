package org.neocraft.gui;

import org.neocraft.api.MinecraftAdapter;
import org.neocraft.client.Brand;
import org.neocraft.theme.Theme;
import org.neocraft.util.Animation;
import org.neocraft.util.RenderUtil;

/**
 * The NeoCraft animated loading screen. Displays the brand logo with a glow
 * pulse, a rotating set of loading messages, and a progress bar that fills as
 * the client initialises. A particle field drifts behind everything for depth.
 *
 * <p>The host calls {@link #setProgress(float)} and {@link #setMessage(String)}
 * as subsystems come online; once progress reaches 1.0 the screen auto-closes.
 *
 * @author NeoCraft
 */
public final class LoadingScreen extends Screen {

	private static final double BAR_W = 320;
	private static final double BAR_H = 6;

	private float progress;
	private String message;
	private int messageIndex;
	private long lastMessageSwap;
	private final Animation pulse = new Animation(0f).ease(org.neocraft.util.Easing::easeInOut);
	private boolean done;

	public LoadingScreen(MinecraftAdapter adapter) {
		super(adapter);
		this.message = Brand.LOADING_MESSAGES[0];
		this.lastMessageSwap = 0;
		this.pulse.target(1f);
		this.pulse.speed(0.5f);
	}

	/** Update loading progress (0..1). */
	public void setProgress(float progress) {
		this.progress = Math.max(0f, Math.min(1f, progress));
		if (this.progress >= 1f) done = true;
	}

	/** Override the current loading message. */
	public void setMessage(String message) {
		this.message = message;
	}

	/** Whether loading has completed (progress reached 1.0). */
	public boolean isDone() { return done; }

	@Override
	public void onOpen() {
		super.onOpen();
		lastMessageSwap = adapter.currentTimeMillis();
	}

	@Override
	protected void renderBackground(float partialTicks) {
		// darker background for loading
		adapter.renderer().drawRect(0, 0, adapter.getScaledWidth(), adapter.getScaledHeight(),
				Theme.liveBackground());
		particles.render(partialTicks);
	}

	@Override
	protected void renderContent(float partialTicks) {
		int sw = adapter.getScaledWidth();
		int sh = adapter.getScaledHeight();
		double cx = sw / 2.0;
		double cy = sh / 2.0;
		float fade = fadeIn.value();

		// cycle loading messages every 2.5s
		if (adapter.currentTimeMillis() - lastMessageSwap > 2500L) {
			messageIndex = (messageIndex + 1) % Brand.LOADING_MESSAGES.length;
			message = Brand.LOADING_MESSAGES[messageIndex];
			lastMessageSwap = adapter.currentTimeMillis();
		}

		// logo with pulse glow
		pulse.update();
		float pulseVal = pulse.value();
		int glowAlpha = (int) (0x30 + 0x20 * pulseVal);
		new RenderUtil(adapter.renderer()).glow( cx - 80, cy - 50, 160, 40,
				Theme.withAlpha(Theme.livePrimary(), glowAlpha), 4);
		adapter.fonts().drawCentered(Brand.NAME, cx, cy - 40,
				Theme.withAlpha(Theme.livePrimary(), (int) (0xFF * fade)));
		adapter.fonts().drawCentered(Brand.SPLASH, cx, cy - 24,
				Theme.withAlpha(Theme.liveTextDim(), (int) (0xFF * fade)));

		// version
		adapter.fonts().drawCentered(Brand.FULL_BRAND + " \u00B7 " + Brand.MINECRAFT_VERSION,
				cx, cy + 4, Theme.liveTextFaint());

		// progress bar
		double barX = cx - BAR_W / 2.0;
		double barY = cy + 30;
		new RenderUtil(adapter.renderer()).progressBar( barX, barY, BAR_W, BAR_H, progress,
				Theme.livePrimary(), Theme.withAlpha(Theme.livePanel(), 0xC0));

		// percentage + message
		int pct = (int) (progress * 100);
		adapter.fonts().drawCentered(pct + "%", cx, barY + 14, Theme.liveText());
		adapter.fonts().drawCentered(message, cx, barY + 28, Theme.liveTextDim());

		// footer
		adapter.fonts().drawCentered("\u00A9 NeoCraft \u00B7 MIT License",
				cx, sh - 20, Theme.liveTextFaint());
	}

	@Override
	public void onKeyPress(int keyCode, char character) {
		// loading screen ignores all input
	}
}
