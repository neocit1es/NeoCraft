package org.neocraft.gui;

import org.neocraft.api.MinecraftAdapter;
import org.neocraft.client.Brand;
import org.neocraft.client.NeoCraft;
import org.neocraft.theme.Theme;
import org.neocraft.util.PanelRenderer;
import org.neocraft.util.RenderUtil;

/**
 * The redesigned NeoCraft main menu. Features a centred glass logo panel,
 * animated fade-in, drifting particle background, rounded action buttons with
 * hover glow, a version footer, and a subtle gradient vignette.
 *
 * <p>Buttons: Singleplayer (stub), Multiplayer (stub), Mods (opens ClickGUI),
 * Settings, Credits, Quit. Each button animates a hover lerp from panel to
 * primary with a soft glow halo.
 *
 * @author NeoCraft
 */
public final class MainMenu extends Screen {

	private static final double BUTTON_W = 240;
	private static final double BUTTON_H = 38;
	private static final double BUTTON_GAP = 8;
	private static final int BUTTON_COUNT = 6;

	/** Callback fired when a menu button is clicked. */
	@FunctionalInterface
	public interface MenuAction {
		void activate(MainMenu menu, String id);
	}

	private final MenuAction action;
	private int hoveredButton = -1;

	/** Button identifiers, in display order. */
	private static final String[] BUTTON_IDS = {
		"singleplayer", "multiplayer", "mods", "settings", "credits", "quit"
	};
	private static final String[] BUTTON_LABELS = {
		"Singleplayer", "Multiplayer", "Mods", "Settings", "Credits", "Quit Game"
	};

	public MainMenu(MinecraftAdapter adapter, MenuAction action) {
		super(adapter);
		this.action = action;
	}

	@Override
	protected void renderContent(float partialTicks) {
		int sw = adapter.getScaledWidth();
		int sh = adapter.getScaledHeight();
		float fade = fadeIn.value();

		// ---- vignette gradient (subtle top-to-bottom darkening) -----------
		adapter.renderer().drawGradientRect(0, 0, sw, sh, Theme.withAlpha(Theme.BACKGROUND, 0x00),
				Theme.withAlpha(Theme.BACKGROUND, 0x60));

		// ---- logo panel ---------------------------------------------------
		double logoW = 360;
		double logoH = 90;
		double logoX = (sw - logoW) / 2.0;
		double logoY = sh * 0.18;
		new PanelRenderer(adapter.renderer(), adapter.fonts()).glass(logoX, logoY, logoW, logoH);

		// brand name with glow
		String brand = Brand.NAME;
		adapter.fonts().drawCentered(brand, sw / 2.0, logoY + 22, Theme.livePrimary());
		new RenderUtil(adapter.renderer()).glow( logoX + logoW / 2.0 - 60, logoY + 18, 120, 18,
				Theme.withAlpha(Theme.livePrimary(), 0x30), 3);

		// version + splash
		adapter.fonts().drawCentered(Brand.VERSION_TAG + " \u00B7 " + Brand.SPLASH,
				sw / 2.0, logoY + 46, Theme.liveTextDim());
		adapter.fonts().drawCentered(Brand.MINECRAFT_VERSION,
				sw / 2.0, logoY + 64, Theme.liveTextFaint());

		// ---- button stack -------------------------------------------------
		double stackX = (sw - BUTTON_W) / 2.0;
		double stackY = logoY + logoH + 32;
		for (int i = 0; i < BUTTON_COUNT; i++) {
			double by = stackY + i * (BUTTON_H + BUTTON_GAP);
			drawMenuButton(i, stackX, by, fade);
		}

		// ---- footer -------------------------------------------------------
		double footerY = sh - 24;
		adapter.renderer().drawRect(0, footerY - 2, sw, 1, Theme.withAlpha(Theme.liveBorder(), 0x60));
		adapter.fonts().draw(Brand.FOOTER_VERSION, 8, footerY, Theme.liveTextFaint());
		adapter.fonts().drawRight(Brand.FOOTER_MINECRAFT, sw - 8, footerY, Theme.liveTextFaint());
	}

	private void drawMenuButton(int index, double x, double y, float fade) {
		boolean hover = hoveredButton == index;
		float h = hover ? 1f : 0f;
		// lerp background panel -> primary tint
		int bg = Theme.lerp(Theme.withAlpha(Theme.livePanel(), 0xC0),
				Theme.withAlpha(Theme.livePrimary(), 0x40), h);
		adapter.renderer().drawRoundedRect(x, y, BUTTON_W, BUTTON_H, 10, bg);

		// border
		int border = hover ? Theme.livePrimary() : Theme.liveBorder();
		adapter.renderer().drawHollowRect(x, y, BUTTON_W, BUTTON_H, 1.5f, border);

		// glow on hover
		if (hover) {
			new RenderUtil(adapter.renderer()).glow( x, y, BUTTON_W, BUTTON_H,
					Theme.withAlpha(Theme.livePrimary(), 0x20), 2);
		}

		// label (lerp text -> primary)
		int labelCol = Theme.lerp(Theme.liveText(), Theme.livePrimary(), h);
		adapter.fonts().drawCentered(BUTTON_LABELS[index], x + BUTTON_W / 2.0,
				y + (BUTTON_H - 9) / 2.0, Theme.withAlpha(labelCol, (int) (0xFF * fade)));
	}

	@Override
	public void onMouseClick(double mouseX, double mouseY, int button) {
		int sw = adapter.getScaledWidth();
		int sh = adapter.getScaledHeight();
		double logoW = 360;
		double logoH = 90;
		double logoY = sh * 0.18;
		double stackX = (sw - BUTTON_W) / 2.0;
		double stackY = logoY + logoH + 32;
		for (int i = 0; i < BUTTON_COUNT; i++) {
			double by = stackY + i * (BUTTON_H + BUTTON_GAP);
			if (mouseX >= stackX && mouseX <= stackX + BUTTON_W &&
					mouseY >= by && mouseY <= by + BUTTON_H) {
				action.activate(this, BUTTON_IDS[i]);
				return;
			}
		}
	}

	@Override
	public void onMouseDrag(double mouseX, double mouseY) {
		updateHover(mouseX, mouseY);
	}

	/** Called each frame by the host to track which button the cursor is over. */
	public void updateHover(double mouseX, double mouseY) {
		int sw = adapter.getScaledWidth();
		int sh = adapter.getScaledHeight();
		double logoW = 360;
		double logoH = 90;
		double logoY = sh * 0.18;
		double stackX = (sw - BUTTON_W) / 2.0;
		double stackY = logoY + logoH + 32;
		hoveredButton = -1;
		for (int i = 0; i < BUTTON_COUNT; i++) {
			double by = stackY + i * (BUTTON_H + BUTTON_GAP);
			if (mouseX >= stackX && mouseX <= stackX + BUTTON_W &&
					mouseY >= by && mouseY <= by + BUTTON_H) {
				hoveredButton = i;
				return;
			}
		}
	}

	@Override
	public void onKeyPress(int keyCode, char character) {
		if (keyCode == 1) {
			// escape does nothing on main menu (or could quit)
		}
	}

	/** Static helper to check which button id is at a position (for tests). */
	public static String buttonIdAt(int sw, int sh, double mouseX, double mouseY) {
		double logoY = sh * 0.18;
		double stackX = (sw - BUTTON_W) / 2.0;
		double stackY = logoY + 90 + 32;
		for (int i = 0; i < BUTTON_COUNT; i++) {
			double by = stackY + i * (BUTTON_H + BUTTON_GAP);
			if (mouseX >= stackX && mouseX <= stackX + BUTTON_W &&
					mouseY >= by && mouseY <= by + BUTTON_H) {
				return BUTTON_IDS[i];
			}
		}
		return null;
	}
}
