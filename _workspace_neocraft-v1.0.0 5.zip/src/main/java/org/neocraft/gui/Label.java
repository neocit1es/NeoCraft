package org.neocraft.gui;

import org.neocraft.api.MinecraftAdapter;

/**
 * A simple text label widget.
 *
 * @author NeoCraft
 */
public class Label extends Widget {

	private String text;
	private int color;
	private boolean centered;

	public Label(MinecraftAdapter adapter, String text, double x, double y, int color) {
		super(adapter, x, y, adapter.fonts().stringWidth(text), adapter.fonts().fontHeight());
		this.text = text;
		this.color = color;
		this.centered = false;
	}

	public Label centered(boolean centered) {
		this.centered = centered;
		return this;
	}

	public void setText(String text) {
		this.text = text;
		this.width = adapter.fonts().stringWidth(text);
	}

	public String text() { return text; }

	@Override
	protected void draw(float partialTicks) {
		if (centered) {
			adapter.fonts().drawCentered(text, x, y, color);
		} else {
			adapter.fonts().draw(text, x, y, color);
		}
	}
}
