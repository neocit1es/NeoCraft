package org.neocraft.gui;

import org.neocraft.api.MinecraftAdapter;
import org.neocraft.modules.SliderSetting;
import org.neocraft.theme.Theme;
import org.neocraft.util.TextCache;

/**
 * A draggable slider bound to a {@link SliderSetting}.
 *
 * <p>Shows the setting name on the left and the current value on the right,
 * with a rounded track and a filled portion. Dragging horizontally adjusts the
 * value within the setting's min/max/step.
 *
 * @author NeoCraft
 */
public class SliderWidget extends Widget {

	private final SliderSetting setting;
	private final TextCache cache;
	private boolean dragging;

	public SliderWidget(MinecraftAdapter adapter, SliderSetting setting, double x, double y, double width) {
		super(adapter, x, y, width, 24);
		this.setting = setting;
		this.cache = new TextCache(adapter.fonts());
	}

	public SliderSetting setting() { return setting; }

	private double progress() {
		return (setting.get() - setting.min()) / (setting.max() - setting.min());
	}

	private void setValueFromMouse(double mouseX) {
		double p = (mouseX - x) / width;
		p = Math.max(0, Math.min(1, p));
		double raw = setting.min() + p * (setting.max() - setting.min());
		setting.set(raw);
	}

	@Override
	protected void draw(float partialTicks) {
		// panel
		adapter.renderer().drawRoundedRect(x, y, width, height, 6, Theme.withAlpha(Theme.livePanel(), 0xE0));
		adapter.renderer().drawHollowRect(x, y, width, height, 1.0f, Theme.liveBorder());
		// track
		double trackY = y + height - 8;
		double trackH = 4;
		adapter.renderer().drawRoundedRect(x + 6, trackY, width - 12, trackH, trackH / 2.0, Theme.liveBackground());
		// fill
		double prog = progress();
		adapter.renderer().drawRoundedRect(x + 6, trackY, (width - 12) * prog, trackH, trackH / 2.0, Theme.livePrimary());
		// knob
		double knobX = x + 6 + (width - 12) * prog;
		adapter.renderer().drawCircle(knobX, trackY + trackH / 2.0, 5, Theme.liveText());
		// labels
		String val = setting.isInteger() ? Integer.toString(setting.getInt()) : String.format("%.1f", setting.get());
		adapter.fonts().draw(setting.name(), x + 8, y + 4, Theme.liveTextDim());
		adapter.fonts().drawRight(val, x + width - 8, y + 4, Theme.livePrimary());
	}

	@Override
	public void onMousePress(double mouseX, double mouseY, int button) {
		pressed = true;
		dragging = true;
		setValueFromMouse(mouseX);
	}

	@Override
	public void onMouseDrag(double mouseX, double mouseY) {
		if (dragging) setValueFromMouse(mouseX);
	}

	@Override
	public void onMouseRelease(double mouseX, double mouseY, int button) {
		pressed = false;
		dragging = false;
	}
}
