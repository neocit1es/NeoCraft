package org.neocraft.gui;

import org.neocraft.api.MinecraftAdapter;
import org.neocraft.util.Animation;

/**
 * Base class for interactive GUI widgets (buttons, toggles, sliders).
 *
 * <p>Widgets own a bounding box, a hover animation, and an enabled state. The
 * owning {@link Screen} routes mouse events to widgets via {@link #hitTest}.
 *
 * @author NeoCraft
 */
public abstract class Widget {

	protected final MinecraftAdapter adapter;
	protected final Animation hover = new Animation(0f).ease(org.neocraft.util.Easing::easeOutExpo);

	protected double x;
	protected double y;
	protected double width;
	protected double height;
	protected boolean enabled = true;
	protected boolean visible = true;
	protected boolean pressed;

	protected Widget(MinecraftAdapter adapter, double x, double y, double width, double height) {
		this.adapter = adapter;
		this.x = x;
		this.y = y;
		this.width = width;
		this.height = height;
	}

	public double getX() { return x; }
	public double getY() { return y; }
	public double getWidth() { return width; }
	public double getHeight() { return height; }
	public boolean isEnabled() { return enabled; }
	public boolean isVisible() { return visible; }
	public void setPos(double x, double y) { this.x = x; this.y = y; }
	public void setSize(double w, double h) { this.width = w; this.height = h; }
	public void setEnabled(boolean enabled) { this.enabled = enabled; }
	public void setVisible(boolean visible) { this.visible = visible; }

	/** Is the point inside the widget bounds? */
	public boolean hitTest(double mouseX, double mouseY) {
		return mouseX >= x && mouseX <= x + width && mouseY >= y && mouseY <= y + height;
	}

	/** Update hover state and render. */
	public void render(float partialTicks) {
		if (!visible) return;
		hover.update();
		draw(partialTicks);
	}

	/** Subclass draw implementation. */
	protected abstract void draw(float partialTicks);

	/** Called on mouse press if hitTest passes. */
	public void onMousePress(double mouseX, double mouseY, int button) {
		pressed = true;
	}

	/** Called on mouse release. */
	public void onMouseRelease(double mouseX, double mouseY, int button) {
		pressed = false;
	}

	/** Called while the mouse is dragged with a button held. */
	public void onMouseDrag(double mouseX, double mouseY) {}

	/** Update hover animation based on current mouse position. */
	public void updateHover(double mouseX, double mouseY) {
		hover.target(hitTest(mouseX, mouseY) && enabled ? 1f : 0f);
		hover.update();
	}

	/** Handle a key press. Default: no-op. */
	public void onKeyPress(int keyCode, char character) {}
}
