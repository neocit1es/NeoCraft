package org.neocraft.gui;

import org.neocraft.api.MinecraftAdapter;
import org.neocraft.util.Animation;
import org.neocraft.util.ParticleField;

/**
 * Base class for every NeoCraft full-screen GUI (main menu, ClickGUI, settings,
 * credits). A screen owns its widgets, receives mouse/keyboard input, and is
 * rendered each frame.
 *
 * <p>Screens are framework-agnostic: they draw solely through the adapter's
 * renderer and font system, never touching {@code net.minecraft.*}.
 *
 * @author NeoCraft
 */
public abstract class Screen {

	protected final MinecraftAdapter adapter;
	protected final ParticleField particles;
	protected final Animation fadeIn;

	private boolean open;

	protected Screen(MinecraftAdapter adapter) {
		this.adapter = adapter;
		this.particles = new ParticleField(adapter, 40, 1.0);
		this.fadeIn = new Animation(0f).ease(org.neocraft.util.Easing::easeOutExpo);
	}

	/** Called once when the screen opens. */
	public void onOpen() {
		open = true;
		fadeIn.snap(0f);
		fadeIn.to(1f, 400L, adapter.currentTimeMillis());
	}

	/** Called when the screen closes. */
	public void onClose() {
		open = false;
	}

	/** Whether the screen is currently open. */
	public boolean isOpen() { return open; }

	/** Current fade-in progress (0..1). */
	public float fade() { return fadeIn.value(); }

	/** Render the screen. Called each frame while open. */
	public void render(float partialTicks) {
		fadeIn.update(adapter.currentTimeMillis());
		renderBackground(partialTicks);
		renderContent(partialTicks);
	}

	/** Draw the shared background: dark base + particle field. Override to customise. */
	protected void renderBackground(float partialTicks) {
		adapter.renderer().drawRect(0, 0, adapter.getScaledWidth(), adapter.getScaledHeight(),
				org.neocraft.theme.Theme.liveBackground());
		particles.render(partialTicks);
	}

	/** Draw the screen-specific content. */
	protected abstract void renderContent(float partialTicks);

	// ---- input (override as needed) ---------------------------------------
	public void onMouseClick(double mouseX, double mouseY, int button) {}
	public void onMouseDrag(double mouseX, double mouseY) {}
	public void onMouseRelease(double mouseX, double mouseY) {}
	public void onKeyPress(int keyCode, char character) {}
	public void onScroll(double mouseX, double mouseY, double amount) {}
}
