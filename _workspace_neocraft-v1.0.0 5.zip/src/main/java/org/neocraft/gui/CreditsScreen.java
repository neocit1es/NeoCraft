package org.neocraft.gui;

import org.neocraft.api.MinecraftAdapter;
import org.neocraft.client.Brand;
import org.neocraft.client.NeoCraft;
import org.neocraft.theme.Theme;
import org.neocraft.util.PanelRenderer;
import org.neocraft.util.RenderUtil;

/**
 * The NeoCraft credits screen. Displays the NeoCraft brand, authorship, the
 * MIT licence summary, and preserved attribution to the original TuffXPlus
 * project (MIT, &copy; TuffNetwork) and TuffClient (inspiration, closed-source)
 * that inspired this client's feature set.
 *
 * @author NeoCraft
 */
public final class CreditsScreen extends Screen {

	private static final String[] ATTRIBUTION_LINES = {
		"NeoCraft is an original, MIT-licensed PvP mod layer for Minecraft 1.12.2.",
		"Built with an adapter pattern: core logic is framework-agnostic and compiles",
		"against stub interfaces; a real MCP-mapped bridge ships separately in /integration.",
		"",
		"Inspiration & Attribution",
		"\u2022 TuffXPlus \u2014 MIT License, \u00A9 TuffNetwork",
		"  Server-side Spigot plugin that inspired the PvP feature direction.",
		"\u2022 TuffClient \u2014 Eaglercraft PvP client (closed-source)",
		"  Feature set and UX design used as inspiration for this client.",
		"",
		"NeoCraft is not affiliated with, endorsed by, or derived from Mojang AB.",
		"Minecraft is a trademark of Mojang AB / Microsoft.",
	};

	private static final String LICENSE_SUMMARY =
		"MIT License \u2014 Permission is hereby granted, free of charge, to any person " +
		"obtaining a copy of this software to deal in it without restriction, " +
		"including without limitation the rights to use, copy, modify, merge, " +
		"publish, distribute, sublicense, and/or sell copies, subject to the " +
		"following condition: the above copyright notice and this permission " +
		"notice shall be included in all copies or substantial portions.";

	public CreditsScreen(MinecraftAdapter adapter) {
		super(adapter);
	}

	@Override
	protected void renderContent(float partialTicks) {
		int sw = adapter.getScaledWidth();
		int sh = adapter.getScaledHeight();
		double panelW = Math.min(sw - 40, 560);
		double panelH = Math.min(sh - 40, 420);
		double px = (sw - panelW) / 2.0;
		double py = (sh - panelH) / 2.0;

		new PanelRenderer(adapter.renderer(), adapter.fonts()).glass(px, py, panelW, panelH);

		// header with glow
		adapter.fonts().drawCentered(Brand.NAME, sw / 2.0, py + 16, Theme.livePrimary());
		new RenderUtil(adapter.renderer()).glow( px + panelW / 2.0 - 80, py + 12, 160, 18,
				Theme.withAlpha(Theme.livePrimary(), 0x25), 3);
		adapter.fonts().drawCentered("Credits & License", sw / 2.0, py + 34, Theme.liveTextDim());
		adapter.renderer().drawRect(px + 20, py + 50, panelW - 40, 1, Theme.liveBorder());

		// version line
		adapter.fonts().drawCentered(Brand.FULL_BRAND + " \u00B7 " + Brand.MINECRAFT_VERSION,
				sw / 2.0, py + 60, Theme.liveText());

		// attribution block
		double ty = py + 84;
		double tx = px + 20;
		double tw = panelW - 40;
		for (String line : ATTRIBUTION_LINES) {
			boolean isHeader = line.startsWith("Inspiration");
			int col = isHeader ? Theme.liveSecondary() : Theme.liveText();
			if (line.isEmpty()) {
				ty += 8;
				continue;
			}
			adapter.fonts().draw(line, tx, ty, isHeader ? Theme.liveSecondary() : Theme.liveText());
			ty += 12;
		}

		// divider
		ty += 6;
		adapter.renderer().drawRect(tx, ty, tw, 1, Theme.liveBorder());
		ty += 8;

		// license summary (wrapped)
		adapter.fonts().draw("License", tx, ty, Theme.liveWarning());
		ty += 14;
		java.util.List<String> wrapped = adapter.fonts().splitToWidth(LICENSE_SUMMARY, (int) tw);
		for (String w : wrapped) {
			adapter.fonts().draw(w, tx, ty, Theme.liveTextDim());
			ty += 11;
		}

		// footer hint
		adapter.fonts().drawCentered("Press ESC to return", sw / 2.0, py + panelH - 20,
				Theme.liveTextFaint());
	}

	@Override
	public void onKeyPress(int keyCode, char character) {
		if (keyCode == 1) {
			onClose();
		}
	}
}
