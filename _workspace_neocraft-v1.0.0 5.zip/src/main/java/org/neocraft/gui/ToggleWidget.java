package org.neocraft.gui;

import org.neocraft.api.MinecraftAdapter;
import org.neocraft.theme.Theme;
import org.neocraft.util.Animation;

import java.util.function.Consumer;

/**
 * A rounded toggle switch with a sliding knob.
 *
 * @author NeoCraft
 */
public class ToggleWidget extends Widget {

	private boolean on;
	private final Animation knob = new Animation(0f).ease(org.neocraft.util.Easing::easeOutBack);
	private final Consumer<Boolean> onChange;

	public ToggleWidget(MinecraftAdapter adapter, boolean initial, double x, double y, Consumer<Boolean> onChange) {
		super(adapter, x, y, 40, 20);
		this.on = initial;
		this.onChange = onChange;
		this.knob.snap(initial ? 1f : 0f);
	}

	public boolean isOn() { return on; }
	public void setOn(boolean on) {
		this.on = on;
		knob.to(on ? 1f : 0f, 200L);
	}

	@Override
	protected void draw(float partialTicks) {
		knob.update();
		float t = knob.value();
		int trackCol = Theme.lerp(Theme.livePanel(), Theme.livePrimary(), t);
		int borderCol = on ? Theme.livePrimary() : Theme.liveBorder();
		adapter.renderer().drawRoundedRect(x, y, width, height, height / 2.0, Theme.withAlpha(trackCol, 0xE0));
		adapter.renderer().drawHollowRect(x, y, width, height, 1.0f, borderCol);
		// knob
		double knobSize = height - 6;
		double knobX = x + 3 + t * (width - knobSize - 6);
		double knobY = y + 3;
		adapter.renderer().drawCircle(knobX + knobSize / 2.0, knobY + knobSize / 2.0, knobSize / 2.0, Theme.liveText());
	}

	@Override
	public void onMouseRelease(double mouseX, double mouseY, int button) {
		boolean wasPressed = pressed;
		pressed = false;
		if (wasPressed && hitTest(mouseX, mouseY) && enabled) {
			setOn(!on);
			if (onChange != null) onChange.accept(on);
		}
	}
}
