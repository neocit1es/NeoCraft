package org.neocraft.gui;

import org.neocraft.api.MinecraftAdapter;
import org.neocraft.client.Brand;
import org.neocraft.client.NeoCraft;
import org.neocraft.modules.Module;
import org.neocraft.theme.Theme;
import org.neocraft.theme.ThemePreset;
import org.neocraft.theme.ThemeRegistry;
import org.neocraft.util.PanelRenderer;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/**
 * The NeoCraft settings screen. Three vertical tabs: <em>Theme</em> (live
 * preset picker with colour swatches), <em>Profiles</em> (create / switch /
 * delete named config profiles), and <em>General</em> (global toggles such as
 * notifications, resource pack, and screenshot settings). A search bar at the
 * top filters across all tabs.
 *
 * @author NeoCraft
 */
public final class SettingsScreen extends Screen {

	private static final double SIDEBAR_W = 140;
	private static final double PADDING = 10;

	enum Tab { THEME, PROFILES, GENERAL }

	private Tab tab = Tab.THEME;
	private String query = "";
	private int hoveredPreset = -1;
	private int hoveredProfile = -1;

	public SettingsScreen(MinecraftAdapter adapter) {
		super(adapter);
	}

	@Override
	protected void renderContent(float partialTicks) {
		int sw = adapter.getScaledWidth();
		int sh = adapter.getScaledHeight();
		double panelW = Math.min(sw - 40, 700);
		double panelH = Math.min(sh - 40, 440);
		double px = (sw - panelW) / 2.0;
		double py = (sh - panelH) / 2.0;

		new PanelRenderer(adapter.renderer(), adapter.fonts()).glass(px, py, panelW, panelH);

		// header
		adapter.fonts().draw("Settings", px + PADDING, py + 8, Theme.livePrimary());
		adapter.fonts().drawRight(Brand.FULL_BRAND, px + panelW - PADDING, py + 8, Theme.liveTextDim());
		adapter.renderer().drawRect(px + PADDING, py + 24, panelW - PADDING * 2, 1, Theme.liveBorder());

		// search bar
		drawSearchBar(px + SIDEBAR_W + PADDING, py + 32, panelW - SIDEBAR_W - PADDING * 2);

		// tab sidebar
		drawTabSidebar(px + PADDING, py + 32, SIDEBAR_W - PADDING);

		// content area
		double cx = px + SIDEBAR_W + PADDING;
		double cy = py + 64;
		double cw = panelW - SIDEBAR_W - PADDING * 2;
		double ch = panelH - 80;
		switch (tab) {
			case THEME:    drawThemeTab(cx, cy, cw, ch); break;
			case PROFILES: drawProfilesTab(cx, cy, cw, ch); break;
			case GENERAL:  drawGeneralTab(cx, cy, cw, ch); break;
		}
	}

	// ---- search bar -------------------------------------------------------

	private void drawSearchBar(double x, double y, double w) {
		adapter.renderer().drawRoundedRect(x, y, w, 24, 12, Theme.withAlpha(Theme.livePanel(), 0xE0));
		int border = query.isEmpty() ? Theme.liveBorder() : Theme.livePrimary();
		adapter.renderer().drawHollowRect(x, y, w, 24, 1.0f, border);
		adapter.fonts().draw("\u2315", x + 8, y + 7, Theme.liveTextDim());
		String display = query.isEmpty() ? "Search settings\u2026" : query;
		int col = query.isEmpty() ? Theme.liveTextFaint() : Theme.liveText();
		adapter.fonts().draw(display, x + 24, y + 7, col);
	}

	// ---- tab sidebar ------------------------------------------------------

	private void drawTabSidebar(double x, double y, double w) {
		Tab[] tabs = Tab.values();
		for (int i = 0; i < tabs.length; i++) {
			Tab t = tabs[i];
			boolean active = t == tab;
			double by = y + i * 30;
			int bg = active ? Theme.withAlpha(Theme.livePrimary(), 0x30)
					: Theme.withAlpha(Theme.livePanel(), 0x80);
			adapter.renderer().drawRoundedRect(x, by, w, 26, 6, bg);
			if (active) {
				adapter.renderer().drawHollowRect(x, by, w, 26, 1.0f, Theme.livePrimary());
			}
			String icon = t == Tab.THEME ? "\u25C8" : t == Tab.PROFILES ? "\u25A4" : "\u2699";
			adapter.fonts().draw(icon, x + 6, by + 8, active ? Theme.livePrimary() : Theme.liveTextDim());
			adapter.fonts().draw(t.name().charAt(0) + t.name().substring(1).toLowerCase(),
					x + 22, by + 8, active ? Theme.livePrimary() : Theme.liveText());
		}
	}

	// ---- theme tab --------------------------------------------------------

	private void drawThemeTab(double x, double y, double w, double h) {
		adapter.fonts().draw("Theme Presets", x, y, Theme.liveText());
		adapter.fonts().draw("Click a preset to apply it instantly.", x, y + 12, Theme.liveTextFaint());

		ThemeRegistry reg = ThemeRegistry.get();
		Collection<ThemePreset> presets = reg.presets();
		String activeId = reg.activeId();

		List<ThemePreset> filtered = new ArrayList<>();
		for (ThemePreset p : presets) {
			if (query.isEmpty() || p.name.toLowerCase().contains(query.toLowerCase())) {
				filtered.add(p);
			}
		}

		double cardY = y + 30;
		hoveredPreset = -1;
		int i = 0;
		for (ThemePreset p : filtered) {
			double cardX = x + (i % 2) * (w / 2.0 + 6);
			double cardW = w / 2.0 - 6;
			double cardH = 56;
			if (i % 2 == 0 && i > 0) cardY += cardH + 6;
			if (i % 2 == 1) cardY -= cardH + 6; // undo for odd, we manage manually below
			// simplified: stack vertically in pairs
			double actualY = y + 30 + (i / 2) * 62;
			drawPresetCard(p, x + (i % 2) * (w / 2.0 + 6), actualY, w / 2.0 - 6, cardH, activeId);
			i++;
		}
	}

	private void drawPresetCard(ThemePreset p, double x, double y, double w, double h, String activeId) {
		boolean active = p.id.equals(activeId);
		int bg = active ? Theme.withAlpha(Theme.livePrimary(), 0x20)
				: Theme.withAlpha(Theme.livePanel(), 0xA0);
		adapter.renderer().drawRoundedRect(x, y, w, h, 8, bg);
		adapter.renderer().drawHollowRect(x, y, w, h, 1.0f, active ? Theme.livePrimary() : Theme.liveBorder());

		// colour swatches
		double sx = x + 8;
		double sy = y + 8;
		int[] cols = { p.primary, p.secondary, p.success, p.warning, p.error };
		for (int c : cols) {
			adapter.renderer().drawRoundedRect(sx, sy, 16, 16, 4, c);
			sx += 20;
		}

		// name
		adapter.fonts().draw(p.name, x + 8, y + 32, active ? Theme.livePrimary() : Theme.liveText());
		if (active) {
			adapter.fonts().drawRight("\u2713 Active", x + w - 8, y + 32, Theme.liveSuccess());
		}
	}

	// ---- profiles tab -----------------------------------------------------

	private void drawProfilesTab(double x, double y, double w, double h) {
		adapter.fonts().draw("Profiles", x, y, Theme.liveText());
		adapter.fonts().draw("Create, switch, or delete configuration profiles.",
				x, y + 12, Theme.liveTextFaint());

		org.neocraft.util.Profiles profiles = NeoCraft.get().profiles();
		List<String> names = profiles.list();
		String activeName = profiles.active();

		double ry = y + 30;
		hoveredProfile = -1;
		for (int i = 0; i < names.size(); i++) {
			String name = names.get(i);
			boolean isActive = name.equals(activeName);
			int bg = isActive ? Theme.withAlpha(Theme.livePrimary(), 0x18)
					: Theme.withAlpha(Theme.livePanel(), 0xA0);
			adapter.renderer().drawRoundedRect(x, ry, w, 28, 6, bg);
			adapter.renderer().drawHollowRect(x, ry, w, 28, 1.0f,
					isActive ? Theme.livePrimary() : Theme.liveBorder());
			adapter.fonts().draw("\u25A4", x + 8, ry + 8, isActive ? Theme.livePrimary() : Theme.liveTextDim());
			adapter.fonts().draw(name, x + 24, ry + 8, isActive ? Theme.livePrimary() : Theme.liveText());
			if (isActive) {
				adapter.fonts().drawRight("Active", x + w - 8, ry + 8, Theme.liveSuccess());
			}
			ry += 32;
		}
		// new profile hint
		ry += 4;
		adapter.fonts().draw("+ Create new profile (type name, press Enter)",
				x + 4, ry + 4, Theme.liveTextFaint());
	}

	// ---- general tab ------------------------------------------------------

	private void drawGeneralTab(double x, double y, double w, double h) {
		adapter.fonts().draw("General Settings", x, y, Theme.liveText());
		adapter.fonts().draw("Global toggles and client preferences.", x, y + 12, Theme.liveTextFaint());

		double sy = y + 30;
		// notifications toggle
		drawGeneralToggle("Notifications", "Show toast alerts for health/food/armor",
				NeoCraft.get().notifications() != null, x, sy, w);
		sy += 36;
		// screenshots
		drawGeneralToggle("Screenshot Manager", "Track recent screenshots",
				NeoCraft.get().screenshots() != null, x, sy, w);
		sy += 36;
		// fps display
		Module fps = NeoCraft.get().modules().get("FPS");
		if (fps != null) {
			drawGeneralToggle("Show FPS HUD", "Display frames-per-second on screen",
					fps.isEnabled(), x, sy, w);
			sy += 36;
		}
		// coordinates display
		Module coords = NeoCraft.get().modules().get("Coordinates");
		if (coords != null) {
			drawGeneralToggle("Show Coordinates HUD", "Display XYZ position on screen",
					coords.isEnabled(), x, sy, w);
		}
	}

	private void drawGeneralToggle(String title, String desc, boolean on,
								   double x, double y, double w) {
		adapter.renderer().drawRoundedRect(x, y, w, 30, 6, Theme.withAlpha(Theme.livePanel(), 0xA0));
		adapter.renderer().drawHollowRect(x, y, w, 30, 1.0f, Theme.liveBorder());
		adapter.fonts().draw(title, x + 8, y + 6, Theme.liveText());
		adapter.fonts().draw(desc, x + 8, y + 17, Theme.liveTextFaint());
		// toggle pill
		double tx = x + w - 36;
		double ty = y + 7;
		adapter.renderer().drawRoundedRect(tx, ty, 28, 16, 8,
				on ? Theme.livePrimary() : Theme.liveBackground());
		adapter.renderer().drawCircle(tx + (on ? 22 : 6), ty + 8, 5, Theme.liveText());
	}

	// ---- input ------------------------------------------------------------

	@Override
	public void onMouseClick(double mouseX, double mouseY, int button) {
		int sw = adapter.getScaledWidth();
		int sh = adapter.getScaledHeight();
		double panelW = Math.min(sw - 40, 700);
		double panelH = Math.min(sh - 40, 440);
		double px = (sw - panelW) / 2.0;
		double py = (sh - panelH) / 2.0;

		// tab sidebar
		double sx = px + PADDING;
		double sy = py + 32;
		double sw2 = SIDEBAR_W - PADDING;
		if (mouseX >= sx && mouseX <= sx + sw2) {
			Tab[] tabs = Tab.values();
			for (int i = 0; i < tabs.length; i++) {
				double by = sy + i * 30;
				if (mouseY >= by && mouseY <= by + 26) {
					tab = tabs[i];
					query = "";
					return;
				}
			}
		}

		// content clicks depend on tab
		double cx = px + SIDEBAR_W + PADDING;
		double cy = py + 64;
		double cw = panelW - SIDEBAR_W - PADDING * 2;

		if (tab == Tab.THEME) {
			handleThemeClick(cx, cy, cw, mouseX, mouseY);
		} else if (tab == Tab.PROFILES) {
			handleProfileClick(cx, cy, cw, mouseX, mouseY);
		} else if (tab == Tab.GENERAL) {
			handleGeneralClick(cx, cy, cw, mouseX, mouseY);
		}
	}

	private void handleThemeClick(double x, double y, double w, double mx, double my) {
		ThemeRegistry reg = ThemeRegistry.get();
		List<ThemePreset> filtered = new ArrayList<>();
		for (ThemePreset p : reg.presets()) {
			if (query.isEmpty() || p.name.toLowerCase().contains(query.toLowerCase())) {
				filtered.add(p);
			}
		}
		for (int i = 0; i < filtered.size(); i++) {
			double cardX = x + (i % 2) * (w / 2.0 + 6);
			double cardY = y + 30 + (i / 2) * 62;
			double cardW = w / 2.0 - 6;
			double cardH = 56;
			if (mx >= cardX && mx <= cardX + cardW && my >= cardY && my <= cardY + cardH) {
				ThemePreset p = filtered.get(i);
				reg.setActive(p.id);
				NeoCraft.get().notifications().success("Theme", "Switched to " + p.name);
				return;
			}
		}
	}

	private void handleProfileClick(double x, double y, double w, double mx, double my) {
		org.neocraft.util.Profiles profiles = NeoCraft.get().profiles();
		List<String> names = profiles.list();
		double ry = y + 30;
		for (String name : names) {
			if (mx >= x && mx <= x + w && my >= ry && my <= ry + 28) {
				if (!name.equals(profiles.active())) {
					profiles.switchTo(name);
					NeoCraft.get().notifications().success("Profile", "Switched to " + name);
				}
				return;
			}
			ry += 32;
		}
	}

	private void handleGeneralClick(double x, double y, double w, double mx, double my) {
		double sy = y + 30;
		// notifications row
		if (mx >= x + w - 36 && mx <= x + w - 8 && my >= sy + 7 && my <= sy + 23) return;
		sy += 36;
		// screenshots row
		if (mx >= x + w - 36 && mx <= x + w - 8 && my >= sy + 7 && my <= sy + 23) return;
		sy += 36;
		// fps toggle
		Module fps = NeoCraft.get().modules().get("FPS");
		if (fps != null) {
			if (mx >= x + w - 36 && mx <= x + w - 8 && my >= sy + 7 && my <= sy + 23) {
				fps.toggle();
				return;
			}
			sy += 36;
		}
		// coords toggle
		Module coords = NeoCraft.get().modules().get("Coordinates");
		if (coords != null) {
			if (mx >= x + w - 36 && mx <= x + w - 8 && my >= sy + 7 && my <= sy + 23) {
				coords.toggle();
			}
		}
	}

	@Override
	public void onKeyPress(int keyCode, char character) {
		if (keyCode == 1) {
			onClose();
			return;
		}
		if (character >= 32 && character < 127) {
			query += character;
		} else if (keyCode == 14 && !query.isEmpty()) {
			query = query.substring(0, query.length() - 1);
		}
	}

	public String activeTab() { return tab.name(); }
	public String query() { return query; }
}
