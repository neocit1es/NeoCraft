package org.neocraft.gui;

import org.neocraft.api.MinecraftAdapter;
import org.neocraft.theme.Theme;
import org.neocraft.util.RenderUtil;

import java.util.function.Consumer;

/**
 * A rounded button with hover glow and a press animation.
 *
 * @author NeoCraft
 */
public class Button extends Widget {

	private final String label;
	private final Consumer<Button> onClick;

	public Button(MinecraftAdapter adapter, String label, double x, double y, double width, double height, Consumer<Button> onClick) {
		super(adapter, x, y, width, height);
		this.label = label;
		this.onClick = onClick;
	}

	public String label() { return label; }

	@Override
	protected void draw(float partialTicks) {
		float h = hover.value();
		// base panel
		int bg = Theme.lerp(Theme.livePanel(), Theme.livePrimary(), h * 0.25f);
		int border = Theme.lerp(Theme.liveBorder(), Theme.livePrimary(), h);
		double radius = height / 2.0;
		adapter.renderer().drawRoundedRect(x, y, width, height, radius, Theme.withAlpha(bg, 0xE0));
		adapter.renderer().drawHollowRect(x, y, width, height, 1.0f, border);
		// glow on hover
		if (h > 0.1f) {
			new RenderUtil(adapter.renderer()).glow(x, y, width, height, Theme.livePrimary(), (int) (h * 3));
		}
		// press squash
		double offsetY = pressed ? 1.0 : 0.0;
		int textCol = Theme.lerp(Theme.liveText(), Theme.livePrimary(), h * 0.5f);
		adapter.fonts().drawCentered(label, x + width / 2.0, y + (height - adapter.fonts().fontHeight()) / 2.0 + offsetY, textCol);
	}

	@Override
	public void onMouseRelease(double mouseX, double mouseY, int button) {
		boolean wasPressed = pressed;
		pressed = false;
		if (wasPressed && hitTest(mouseX, mouseY) && enabled && onClick != null) {
			onClick.accept(this);
		}
	}
}
