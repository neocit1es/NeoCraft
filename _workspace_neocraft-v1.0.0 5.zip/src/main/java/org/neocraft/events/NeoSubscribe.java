package org.neocraft.events;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Marks a single-argument {@link NeoEvent} method as an event listener.
 *
 * @author NeoCraft
 */
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.METHOD)
public @interface NeoSubscribe {
	/** Dispatch priority; higher runs first. Default 0. */
	int priority() default 0;
}
