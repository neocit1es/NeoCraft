package org.neocraft.events;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * Lightweight, annotation-driven event bus.
 *
 * <p>Listeners register a subscriber object; every method annotated with
 * {@link NeoSubscribe} taking a single {@link NeoEvent} subtype is invoked when
 * that event is posted. Post order follows priority on the annotation (higher
 * first), then registration order.
 *
 * <p>Designed to be allocation-light in the hot path: the dispatch list per
 * event type is built once and cached.
 *
 * @author NeoCraft
 */
public final class EventBus {

	private final Map<Class<?>, List<Handler>> handlers = new ConcurrentHashMap<>();
	private final List<Object> subscribers = new CopyOnWriteArrayList<>();

	/** Register all {@link NeoSubscribe} methods on {@code subscriber}. */
	public void register(Object subscriber) {
		if (subscriber == null) return;
		subscribers.add(subscriber);
		// Walk the full class hierarchy so inherited @NeoSubscribe methods
		// (e.g. Module.onTickInternal) are discovered on subclasses.
		for (Class<?> cls = subscriber.getClass(); cls != null && cls != Object.class; cls = cls.getSuperclass()) {
			for (Method m : cls.getDeclaredMethods()) {
				NeoSubscribe sub = m.getAnnotation(NeoSubscribe.class);
				if (sub == null) continue;
				Class<?>[] params = m.getParameterTypes();
				if (params.length != 1 || !NeoEvent.class.isAssignableFrom(params[0])) continue;
				@SuppressWarnings("unchecked")
				Class<? extends NeoEvent> type = (Class<? extends NeoEvent>) params[0];
				m.setAccessible(true);
				addHandler(type, new Handler(subscriber, m, sub.priority()));
			}
		}
	}

	/** Unregister all handlers owned by {@code subscriber}. */
	public void unregister(Object subscriber) {
		if (subscriber == null) return;
		subscribers.remove(subscriber);
		for (List<Handler> list : handlers.values()) {
			list.removeIf(h -> h.owner == subscriber);
		}
	}

	private void addHandler(Class<? extends NeoEvent> type, Handler h) {
		List<Handler> list = handlers.computeIfAbsent(type, k -> new CopyOnWriteArrayList<>());
		list.add(h);
		// keep sorted by priority desc
		list.sort((a, b) -> Integer.compare(b.priority, a.priority));
	}

	/** Post {@code event} to all registered handlers for its type. */
	public void post(NeoEvent event) {
		List<Handler> list = handlers.get(event.getClass());
		if (list == null || list.isEmpty()) return;
		// snapshot to avoid CME if a handler registers/unregisters during post
		List<Handler> snapshot = new ArrayList<>(list);
		for (Handler h : snapshot) {
			try {
				h.method.invoke(h.owner, event);
			} catch (Throwable t) {
				// never let one listener break the dispatch chain
				System.out.println("[NeoCraft/EventBus] listener threw: " + t);
			}
			if (event.isCancelled()) break;
		}
	}

	/** Number of registered handlers for a given event type (testing). */
	public int handlerCount(Class<? extends NeoEvent> type) {
		List<Handler> list = handlers.get(type);
		return list == null ? 0 : list.size();
	}

	/** Total subscriber count (testing). */
	public int subscriberCount() {
		return subscribers.size();
	}

	private static final class Handler {
		final Object owner;
		final Method method;
		final int priority;
		Handler(Object owner, Method method, int priority) {
			this.owner = owner;
			this.method = method;
			this.priority = priority;
		}
	}
}
