package org.neocraft.events;

/** Fired each client tick (20Hz) while in-game. */
public class TickEvent extends NeoEvent {
	public TickEvent() {}
}
