package org.neocraft.events;

/** Fired each rendered frame, after the world and before/around HUD overlay. */
public class RenderEvent extends NeoEvent {
	public final float partialTicks;
	public RenderEvent(float partialTicks) { this.partialTicks = partialTicks; }
}
