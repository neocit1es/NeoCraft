package org.neocraft.events;

/** Fired for a 2D overlay (HUD) render pass. */
public class Render2DEvent extends NeoEvent {
	public final float partialTicks;
	public Render2DEvent(float partialTicks) { this.partialTicks = partialTicks; }
}
