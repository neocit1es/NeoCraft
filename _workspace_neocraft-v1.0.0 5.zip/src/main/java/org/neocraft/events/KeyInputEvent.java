package org.neocraft.events;

/** Fired when a keyboard key is pressed. {@code keyCode} uses LWJGL key codes. */
public class KeyInputEvent extends NeoEvent {
	public final int keyCode;
	public final char character;
	public KeyInputEvent(int keyCode, char character) {
		this.keyCode = keyCode;
		this.character = character;
	}
}
