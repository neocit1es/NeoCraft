package org.neocraft.events;

/**
 * Base class for all NeoCraft events.
 *
 * <p>Events posted on the {@link EventBus}. Cancellable events set
 * {@code cancelled = true} to stop further (lower-priority) dispatch.
 *
 * @author NeoCraft
 */
public abstract class NeoEvent {

	private boolean cancelled;

	public boolean isCancelled() { return cancelled; }
	public void cancel() { this.cancelled = true; }
	public void setCancelled(boolean cancelled) { this.cancelled = cancelled; }
}
