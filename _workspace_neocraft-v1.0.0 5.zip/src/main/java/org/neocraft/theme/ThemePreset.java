package org.neocraft.theme;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * A named, serialisable colour preset. {@link ThemeRegistry} holds the
 * built-in presets and any user-saved ones; the {@code gui} settings screen
 * lets the user pick between them (Theme Selector feature).
 *
 * <p>Only the core accent/background/text/status colours are swappable, since
 * the derived shades are computed from those in {@link Theme}.
 *
 * @author NeoCraft
 */
public final class ThemePreset {

	public final String id;
	public final String name;
	public final int primary;
	public final int secondary;
	public final int background;
	public final int panel;
	public final int text;
	public final int success;
	public final int warning;
	public final int error;

	public ThemePreset(String id, String name,
					   int primary, int secondary, int background, int panel, int text,
					   int success, int warning, int error) {
		this.id = id;
		this.name = name;
		this.primary = primary;
		this.secondary = secondary;
		this.background = background;
		this.panel = panel;
		this.text = text;
		this.success = success;
		this.warning = warning;
		this.error = error;
	}

	/** Serialise to a flat string map for {@link org.neocraft.api.ConfigStore}. */
	public Map<String, String> toMap() {
		Map<String, String> m = new LinkedHashMap<>();
		m.put("id", id);
		m.put("name", name);
		m.put("primary", Integer.toHexString(primary));
		m.put("secondary", Integer.toHexString(secondary));
		m.put("background", Integer.toHexString(background));
		m.put("panel", Integer.toHexString(panel));
		m.put("text", Integer.toHexString(text));
		m.put("success", Integer.toHexString(success));
		m.put("warning", Integer.toHexString(warning));
		m.put("error", Integer.toHexString(error));
		return m;
	}

	/** Deserialise from a flat string map. */
	public static ThemePreset fromMap(Map<String, String> m) {
		return new ThemePreset(
			m.getOrDefault("id", "custom"),
			m.getOrDefault("name", "Custom"),
			parseRgb(m.get("primary"), Theme.PRIMARY),
			parseRgb(m.get("secondary"), Theme.SECONDARY),
			parseRgb(m.get("background"), Theme.BACKGROUND),
			parseRgb(m.get("panel"), Theme.PANEL),
			parseRgb(m.get("text"), Theme.TEXT),
			parseRgb(m.get("success"), Theme.SUCCESS),
			parseRgb(m.get("warning"), Theme.WARNING),
			parseRgb(m.get("error"), Theme.ERROR)
		);
	}

	private static int parseRgb(String hex, int fallback) {
		if (hex == null) return fallback;
		try {
			return Theme.argb(Integer.parseInt(hex, 16));
		} catch (NumberFormatException e) {
			return fallback;
		}
	}
}
