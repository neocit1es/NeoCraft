package org.neocraft.theme;

import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Registry of all available {@link ThemePreset}s plus the currently active one.
 *
 * <p>The active preset's colours are reflected into the {@link Theme} class's
 * live palette so every GUI element updates the instant the user selects a new
 * theme. {@link #saveState}/{@link #loadState} persist the selection.
 *
 * @author NeoCraft
 */
public final class ThemeRegistry {

	private static final ThemeRegistry INSTANCE = new ThemeRegistry();

	private final Map<String, ThemePreset> presets = new LinkedHashMap<>();
	private String activeId;

	private ThemeRegistry() {
		registerBuiltins();
		this.activeId = "neocraft";
	}

	public static ThemeRegistry get() {
		return INSTANCE;
	}

	private void registerBuiltins() {
		put(new ThemePreset("neocraft", "NeoCraft (Cyan)",
			Theme.argb(0x00E5FF), Theme.argb(0x8B5CF6), Theme.argb(0x0E1016),
			Theme.argb(0x181C24), Theme.argb(0xF5F7FA), Theme.argb(0x38D39F),
			Theme.argb(0xF5B041), Theme.argb(0xEF4444)));
		put(new ThemePreset("amethyst", "Amethyst",
			Theme.argb(0x8B5CF6), Theme.argb(0x00E5FF), Theme.argb(0x141019),
			Theme.argb(0x1E1A2A), Theme.argb(0xF5F7FA), Theme.argb(0x38D39F),
			Theme.argb(0xF5B041), Theme.argb(0xEF4444)));
		put(new ThemePreset("emerald", "Emerald",
			Theme.argb(0x38D39F), Theme.argb(0x00E5FF), Theme.argb(0x0E1410),
			Theme.argb(0x18241C), Theme.argb(0xF5F7FA), Theme.argb(0x38D39F),
			Theme.argb(0xF5B041), Theme.argb(0xEF4444)));
		put(new ThemePreset("sunset", "Sunset",
			Theme.argb(0xF5B041), Theme.argb(0xEF4444), Theme.argb(0x14100C),
			Theme.argb(0x241C16), Theme.argb(0xF5F7FA), Theme.argb(0x38D39F),
			Theme.argb(0xF5B041), Theme.argb(0xEF4444)));
		put(new ThemePreset("crimson", "Crimson",
			Theme.argb(0xEF4444), Theme.argb(0x8B5CF6), Theme.argb(0x140E0E),
			Theme.argb(0x241618), Theme.argb(0xF5F7FA), Theme.argb(0x38D39F),
			Theme.argb(0xF5B041), Theme.argb(0xEF4444)));
	}

	private void put(ThemePreset p) {
		presets.put(p.id, p);
	}

	/** All available presets, insertion-ordered. */
	public Collection<ThemePreset> presets() {
		return Collections.unmodifiableCollection(presets.values());
	}

	public ThemePreset get(String id) {
		return presets.get(id);
	}

	public ThemePreset active() {
		return presets.getOrDefault(activeId, presets.values().iterator().next());
	}

	public String activeId() {
		return activeId;
	}

	/** Switch the active preset. Returns true if the id was known. */
	public boolean setActive(String id) {
		if (!presets.containsKey(id)) return false;
		this.activeId = id;
		apply(active());
		return true;
	}

	/** Add or replace a user preset, then activate it. */
	public void install(ThemePreset preset) {
		presets.put(preset.id, preset);
		setActive(preset.id);
	}

	/** Apply a preset's colours into the live {@link Theme} palette. */
	private void apply(ThemePreset p) {
		Theme.applyPreset(p);
	}

	// ---- persistence -------------------------------------------------------
	public void saveState(org.neocraft.api.ConfigStore cfg) {
		cfg.set("theme.active", activeId);
	}
	public void loadState(org.neocraft.api.ConfigStore cfg) {
		String id = cfg.get("theme.active", "neocraft");
		if (setActive(id)) return;
		setActive("neocraft");
	}
}
