package org.neocraft.theme;

/**
 * NeoCraft's centralised colour theme.
 *
 * <p><b>Every</b> GUI colour in the project is read from this class. No GUI,
 * HUD, ClickGUI or module code may hardcode an ARGB value. To re-skin the
 * entire client you change values here (or apply a {@link ThemePreset}) and
 * nothing else.
 *
 * <p>Colours are stored as 32-bit ARGB ints to map cleanly onto Minecraft's
 * renderer. The {@link #argb} / {@link #withAlpha} / {@link #lerp} helpers keep
 * conversions consistent. GUI code should prefer the {@code live*()} accessors
 * so that theme swaps via {@link ThemeRegistry} take effect immediately.
 *
 * @author NeoCraft
 */
public final class Theme {

	// ---- brand palette (from the NeoCraft design spec) ----
	public static final int PRIMARY    = argb(0x00E5FF); // cyan
	public static final int SECONDARY  = argb(0x8B5CF6); // purple
	public static final int BACKGROUND = argb(0x0E1016); // near-black
	public static final int PANEL      = argb(0x181C24); // dark slate
	public static final int TEXT       = argb(0xF5F7FA); // off-white
	public static final int SUCCESS    = argb(0x38D39F); // green
	public static final int WARNING    = argb(0xF5B041); // amber
	public static final int ERROR      = argb(0xEF4444); // red

	// ---- derived convenience shades ----
	public static final int TEXT_DIM      = withAlpha(TEXT, 0xB0);
	public static final int TEXT_FAINT    = withAlpha(TEXT, 0x60);
	public static final int PRIMARY_DIM   = withAlpha(PRIMARY, 0x80);
	public static final int SECONDARY_DIM = withAlpha(SECONDARY, 0x80);
	public static final int PANEL_LIGHT   = argb(0x21262F);
	public static final int PANEL_DARK    = argb(0x11151C);
	public static final int BORDER        = withAlpha(PRIMARY, 0x40);
	public static final int BORDER_SOFT   = withAlpha(TEXT, 0x18);
	public static final int HOVER         = withAlpha(PRIMARY, 0x20);
	public static final int ACTIVE        = PRIMARY;
	public static final int SHADOW        = argb(0x000000);

	// ---- panel opacities ----
	public static final int GLASS_PANEL      = withAlpha(PANEL, 0xC8);
	public static final int GLASS_PANEL_DARK = withAlpha(BACKGROUND, 0xA0);
	public static final int BLUR_TINT        = withAlpha(BACKGROUND, 0x55);

	private Theme() {}

	/** Build an opaque ARGB int from an RGB hex value (alpha forced to 0xFF). */
	public static int argb(int rgb) {
		return 0xFF000000 | (rgb & 0x00FFFFFF);
	}

	/** Build an ARGB int from discrete 0..255 channels. */
	public static int argb(int a, int r, int g, int b) {
		return ((a & 0xFF) << 24) | ((r & 0xFF) << 16) | ((g & 0xFF) << 8) | (b & 0xFF);
	}

	/** Return {@code color} with its alpha channel replaced by {@code alpha}. */
	public static int withAlpha(int color, int alpha) {
		return (color & 0x00FFFFFF) | ((alpha & 0xFF) << 24);
	}

	/** Extract the 0..255 alpha channel. */
	public static int alpha(int color) {
		return (color >>> 24) & 0xFF;
	}

	/** Extract the 0..255 red channel. */
	public static int red(int color) {
		return (color >>> 16) & 0xFF;
	}

	/** Extract the 0..255 green channel. */
	public static int green(int color) {
		return (color >>> 8) & 0xFF;
	}

	/** Extract the 0..255 blue channel. */
	public static int blue(int color) {
		return color & 0xFF;
	}

	/** Linearly interpolate two ARGB colours by {@code t} in 0..1. */
	public static int lerp(int a, int b, float t) {
		if (t <= 0f) return a;
		if (t >= 1f) return b;
		int aa = alpha(a), ba = alpha(b);
		int ra = red(a), ga = green(a), bla = blue(a);
		int rb = red(b), gb = green(b), blb = blue(b);
		return argb(
			(int) (aa + (ba - aa) * t),
			(int) (ra + (rb - ra) * t),
			(int) (ga + (gb - ga) * t),
			(int) (bla + (blb - bla) * t)
		);
	}

	/** Lighten an RGB colour toward white by {@code amount} in 0..1. */
	public static int lighten(int color, float amount) {
		return lerp(color, argb(0xFFFFFF), amount);
	}

	/** Darken an RGB colour toward black by {@code amount} in 0..1. */
	public static int darken(int color, float amount) {
		return lerp(color, argb(0x000000), amount);
	}

	/** Status colour for a boolean module state. */
	public static int stateColor(boolean on) {
		return on ? SUCCESS : withAlpha(TEXT, 0x50);
	}

	// ---- live palette (mutable so ThemeRegistry can swap presets) ----------
	// These are read by all GUI code; applyPreset() re-points them.
	private static volatile int LIVE_PRIMARY    = PRIMARY;
	private static volatile int LIVE_SECONDARY  = SECONDARY;
	private static volatile int LIVE_BACKGROUND = BACKGROUND;
	private static volatile int LIVE_PANEL      = PANEL;
	private static volatile int LIVE_TEXT       = TEXT;
	private static volatile int LIVE_SUCCESS    = SUCCESS;
	private static volatile int LIVE_WARNING    = WARNING;
	private static volatile int LIVE_ERROR      = ERROR;

	/** Copy a preset's core colours into the live palette. */
	public static void applyPreset(ThemePreset p) {
		LIVE_PRIMARY = p.primary;
		LIVE_SECONDARY = p.secondary;
		LIVE_BACKGROUND = p.background;
		LIVE_PANEL = p.panel;
		LIVE_TEXT = p.text;
		LIVE_SUCCESS = p.success;
		LIVE_WARNING = p.warning;
		LIVE_ERROR = p.error;
	}

	/** Restore the built-in NeoCraft palette as the live palette. */
	public static void resetPreset() {
		applyPreset(ThemeRegistry.get().get("neocraft"));
	}

	// Live accessors — GUI code should prefer these over the constants so
	// theme swaps take effect immediately without recompilation.
	public static int livePrimary()    { return LIVE_PRIMARY; }
	public static int liveSecondary()  { return LIVE_SECONDARY; }
	public static int liveBackground() { return LIVE_BACKGROUND; }
	public static int livePanel()      { return LIVE_PANEL; }
	public static int liveText()       { return LIVE_TEXT; }
	public static int liveSuccess()    { return LIVE_SUCCESS; }
	public static int liveWarning()    { return LIVE_WARNING; }
	public static int liveError()      { return LIVE_ERROR; }

	public static int liveBorder()     { return withAlpha(LIVE_PRIMARY, 0x40); }
	public static int liveHover()      { return withAlpha(LIVE_PRIMARY, 0x20); }
	public static int liveGlassPanel() { return withAlpha(LIVE_PANEL, 0xC8); }
	public static int liveTextDim()    { return withAlpha(LIVE_TEXT, 0xB0); }
	public static int liveTextFaint()  { return withAlpha(LIVE_TEXT, 0x60); }
}
