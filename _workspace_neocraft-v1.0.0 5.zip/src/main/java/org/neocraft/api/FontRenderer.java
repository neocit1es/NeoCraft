package org.neocraft.api;

/**
 * Abstraction over the Minecraft font system with measurement and caching.
 */
public interface FontRenderer {

	/** Draw a single-line string at the given position with an ARGB colour. */
	void drawString(String text, double x, double y, int argb, boolean shadow);

	/** Draw with the theme default shadow. */
	default void draw(String text, double x, double y, int argb) {
		drawString(text, x, y, argb, true);
	}

	/** Draw without shadow. */
	default void drawNoShadow(String text, double x, double y, int argb) {
		drawString(text, x, y, argb, false);
	}

	/** Draw centered on {@code centerX}. */
	default void drawCentered(String text, double centerX, double y, int argb) {
		drawString(text, centerX - stringWidth(text) / 2.0, y, argb, true);
	}

	/** Draw right-aligned to {@code rightX}. */
	default void drawRight(String text, double rightX, double y, int argb) {
		drawString(text, rightX - stringWidth(text), y, argb, true);
	}

	/** Pixel width of {@code text} at the current font scale. */
	int stringWidth(String text);

	/** Pixel height of a line (commonly ~9 at scale 1). */
	int fontHeight();

	/** Split {@code text} to fit within {@code maxWidth}; returns the lines. */
	java.util.List<String> splitToWidth(String text, int maxWidth);
}
