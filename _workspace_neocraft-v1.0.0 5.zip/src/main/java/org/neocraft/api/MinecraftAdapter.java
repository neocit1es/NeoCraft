package org.neocraft.api;

/**
 * NeoCraft's portability surface.
 *
 * <p>All Minecraft-dependent behaviour (rendering, input, world access, the
 * font system, network state, configuration storage) is accessed exclusively
 * through this interface. NeoCraft's core packages ({@code client}, {@code gui},
 * {@code hud}, {@code modules}, {@code theme}, {@code render}, {@code events})
 * never import {@code net.minecraft.*} directly, which keeps the project
 * original and free of proprietary code.
 *
 * <p>A self-contained stub implementation ({@link org.neocraft.adapter.StubAdapter})
 * lets the core compile and unit-test in any environment. The real,
 * MCP-mapped 1.12.2 wiring lives in {@code /integration} and is supplied to the
 * adapter at startup by the host workspace (see {@code INTEGRATION.md}).
 *
 * @author NeoCraft
 */
public interface MinecraftAdapter {

	/* ---------------- identity / branding ---------------- */

	/** Display name of the running client build, e.g. {@code "NeoCraft v1.0.0"}. */
	String getClientBrand();

	/** Minecraft protocol target, e.g. {@code "Minecraft 1.12.2"}. */
	String getMinecraftVersion();

	/* ---------------- timing ---------------- */

	/** Monotonic time in milliseconds, used by the animation system. */
	long currentTimeMillis();

	/** Partial-tick / render-frame counter for smooth interpolation. */
	float getPartialTicks();

	/** Frames rendered in the last second. */
	int getFps();

	/* ---------------- input ---------------- */

	boolean isKeyDown(int keyCode);

	/** Left mouse button held this frame. */
	boolean isMouseLeftDown();

	/** Right mouse button held this frame. */
	boolean isMouseRightDown();

	int getMouseX();

	int getMouseY();

	/** Current viewport width in scaled GUI pixels. */
	int getScaledWidth();

	/** Current viewport height in scaled GUI pixels. */
	int getScaledHeight();

	/* ---------------- player / world ---------------- */

	boolean isInGame();

	boolean isInWorld();

	double getPlayerX();

	double getPlayerY();

	double getPlayerZ();

	/** Current network latency to the server in milliseconds, or -1 if unknown. */
	int getPing();

	/** Number of left-click attacks registered in the last second (CPS). */
	int getLeftClickCps();

	/** Number of right-click uses registered in the last second. */
	int getRightClickCps();

	/** Frame delta in seconds for smooth motion. */
	float getFrameDelta();

	/* ---------------- gameplay hooks (functional modules) ------------- */

	/** Player health in half-hearts, or 20 (full) if unknown. */
	float getHealth();

	/** Player max health in half-hearts, or 20 if unknown. */
	float getMaxHealth();

	/** Player food level (0-20), or 20 if unknown. */
	int getFood();

	/** Player armor value (0-20), or 0 if unknown. */
	int getArmor();

	/** The player's current attack reach in blocks; 3.0 default in 1.12.2. */
	double getReach();

	/** Gamma/brightness setting (0.0-1.0+; vanilla night vision caps at 1.0). */
	float getGamma();

	/** Set the gamma/brightness value. Used by Fullbright. */
	void setGamma(float gamma);

	/** Field-of-view multiplier (0 = default). Used by Zoom/Fov modules. */
	float getFov();

	/** Set the field-of-view multiplier (0 = default/unchanged). */
	void setFov(float fov);

	/** Is the player currently sprinting? */
	boolean isSprinting();

	/** Force-set the sprint state. Used by Sprint. */
	void setSprinting(boolean sprinting);

	/** Is the player currently sneaking? */
	boolean isSneaking();

	/** Player horizontal movement speed (blocks/tick); 0.0 if unknown. */
	double getMoveSpeed();

	/* ---------------- rendering ---------------- */

	GameRenderer renderer();

	FontRenderer fonts();

	/** Push a flat 2D matrix stack frame (orthographic GUI rendering). */
	void enableGuiMatrix();

	void disableGuiMatrix();

	/* ---------------- persistence ---------------- */

	ConfigStore config();

	/** Notify the adapter that NeoCraft took a screenshot; returns the saved file name or null. */
	String takeScreenshot();
}
