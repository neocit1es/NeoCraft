package org.neocraft.api;

/**
 * Abstraction over the 2D immediate-mode GUI renderer.
 *
 * <p>All NeoCraft rendering (rounded panels, gradients, blur, text) goes through
 * this surface so the core never touches OpenGL directly. The integration
 * bridge implements this with Minecraft's {@code GlStateManager} / {@code Tessellator}.
 */
public interface GameRenderer {

	void drawRect(double x, double y, double width, double height, int argb);

	void drawRoundedRect(double x, double y, double width, double height, double radius, int argb);

	void drawHollowRect(double x, double y, double width, double height, float lineWidth, int argb);

	void drawGradientRect(double x, double y, double width, double height, int topArgb, int bottomArgb);

	void drawHorizontalGradient(double x, double y, double width, double height, int leftArgb, int rightArgb);

	void drawLine(double x1, double y1, double x2, double y2, float lineWidth, int argb);

	void drawCircle(double centerX, double centerY, double radius, int argb);

	/** Full-screen translucent blur of the region behind the given rectangle. */
	void drawBlur(double x, double y, double width, double height, float strength);

	/** Vertical or circular particle draw used by the main menu. */
	void drawParticle(double x, double y, double size, int argb, float alpha);

	void enableScissor(double x, double y, double width, double height);

	void disableScissor();

	/** Push a translucency/blend state for stacked glass panels. */
	void pushBlend();

	void popBlend();

	/** Set a uniform alpha multiplier for subsequent draws (0..1). */
	void setGlobalAlpha(float alpha);

	float getGlobalAlpha();

	void setColor(int argb);
}
