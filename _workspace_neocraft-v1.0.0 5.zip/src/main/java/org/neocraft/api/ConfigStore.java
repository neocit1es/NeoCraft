package org.neocraft.api;

/**
 * Key/value persistence for NeoCraft configuration (profiles, HUD layouts,
 * theme selection, module states, keybinds). The integration bridge maps this
 * to a per-world / per-profile file under the NeoCraft config directory.
 */
public interface ConfigStore {

	void set(String key, String value);

	String get(String key, String defaultValue);

	default String get(String key) {
		return get(key, null);
	}

	void setInt(String key, int value);

	int getInt(String key, int defaultValue);

	void setDouble(String key, double value);

	double getDouble(String key, double defaultValue);

	void setBoolean(String key, boolean value);

	boolean getBoolean(String key, boolean defaultValue);

	void remove(String key);

	/** Persist the current in-memory state to disk. */
	void save();

	/** Reload from disk. */
	void reload();

	/** Returns an isolated namespace for a named profile. */
	ConfigStore namespace(String name);
}
