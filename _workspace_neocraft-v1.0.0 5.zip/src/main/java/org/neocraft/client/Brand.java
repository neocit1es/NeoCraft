package org.neocraft.client;

/**
 * Centralised branding constants for NeoCraft.
 *
 * <p>Every user-visible reference to the client name or version resolves
 * through here so the rebrand is a single source of truth. Window titles,
 * splash text, loading screens, the main menu, config directory names and
 * build metadata all read from {@link Brand}.
 *
 * @author NeoCraft
 */
public final class Brand {

	/** Primary client name shown in titles and menus. */
	public static final String NAME = "NeoCraft";

	/** Full display name with version, e.g. used in window titles. */
	public static final String DISPLAY_NAME = "NeoCraft";

	/** Semantic version string. */
	public static final String VERSION = "1.0.0";

	/** Display version, e.g. {@code "v1.0.0"}. */
	public static final String VERSION_TAG = "v" + VERSION;

	/** Full client brand, e.g. {@code "NeoCraft v1.0.0"}. */
	public static final String FULL_BRAND = NAME + " " + VERSION_TAG;

	/** Target Minecraft version. */
	public static final String MINECRAFT_VERSION = "Minecraft 1.12.2";

	/** Config directory name under the game's root. */
	public static final String CONFIG_DIR = "neocraft";

	/** Resource namespace for NeoCraft assets. */
	public static final String NAMESPACE = "neocraft";

	/** Update-checker identifier / user-agent component. */
	public static final String UPDATE_ID = "neocraft";

	/** Window title. */
	public static final String WINDOW_TITLE = FULL_BRAND + " - " + MINECRAFT_VERSION;

	/** Browser / favicon document title. */
	public static final String BROWSER_TITLE = FULL_BRAND;

	/** Splash line shown beneath the logo on the loading screen. */
	public static final String SPLASH = "The future of PvP.";

	/** Loading-screen messages, in order. */
	public static final String[] LOADING_MESSAGES = {
		"Initializing NeoCraft...",
		"Loading modules...",
		"Loading assets...",
		"Optimizing renderer...",
		"Preparing multiplayer...",
		"Done."
	};

	/** Main menu footer, line 1. */
	public static final String FOOTER_VERSION = FULL_BRAND;

	/** Main menu footer, line 2. */
	public static final String FOOTER_MINECRAFT = MINECRAFT_VERSION;

	private Brand() {}
}
