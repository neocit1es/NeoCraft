package org.neocraft.client;

import org.neocraft.api.ConfigStore;
import org.neocraft.api.MinecraftAdapter;
import org.neocraft.events.EventBus;
import org.neocraft.hud.HudManager;
import org.neocraft.modules.ModuleManager;
import org.neocraft.theme.ThemeRegistry;
import org.neocraft.util.NotificationManager;
import org.neocraft.util.Profiles;
import org.neocraft.util.ScreenshotManager;
import org.neocraft.util.ResourcePackManager;

/**
 * The NeoCraft client singleton — the root container that owns every subsystem
 * and is initialised once by the host workspace's integration bridge.
 *
 * <p>The bridge calls {@link #init(MinecraftAdapter)} on startup and
 * {@link #shutdown()} on teardown. GUI/HUD/module code reaches the game solely
 * through {@link #adapter()}, never through {@code net.minecraft.*}.
 *
 * @author NeoCraft
 */
public final class NeoCraft {

	private static NeoCraft instance;

	private final MinecraftAdapter adapter;
	private final EventBus eventBus;
	private final ModuleManager modules;
	private final HudManager hud;
	private final NotificationManager notifications;
	private final Profiles profiles;
	private final ScreenshotManager screenshots;
	private final ResourcePackManager resourcePack;
	private final ConfigStore config;
	private volatile boolean started;

	private NeoCraft(MinecraftAdapter adapter) {
		this.adapter = adapter;
		this.eventBus = new EventBus();
		this.config = adapter.config();
		this.modules = new ModuleManager(adapter, eventBus);
		this.hud = new HudManager(adapter, eventBus);
		this.notifications = new NotificationManager(adapter);
		this.profiles = new Profiles(adapter);
		this.screenshots = new ScreenshotManager(adapter);
		this.resourcePack = new ResourcePackManager(config);
	}

	/** Initialise the client against an adapter. Idempotent. */
	public static synchronized NeoCraft init(MinecraftAdapter adapter) {
		if (instance != null) return instance;
		if (adapter == null) throw new IllegalArgumentException("adapter");
		instance = new NeoCraft(adapter);
		instance.start();
		return instance;
	}

	/** Get the running instance, or null before {@link #init}. */
	public static NeoCraft get() {
		return instance;
	}

	/**
	 * Test-only: discard the singleton so the next {@link #init} creates a fresh
	 * client against a new adapter. Not for production use.
	 */
	public static synchronized void resetForTesting() {
		if (instance != null) {
			try { instance.shutdown(); } catch (Throwable ignored) {}
		}
		instance = null;
	}

	private void start() {
		if (started) return;
		started = true;
		// Load persisted theme selection first so everything renders themed.
		ThemeRegistry.get().loadState(config);
		// Register built-in modules then load persisted state on top.
		modules.registerBuiltins();
		modules.loadState(config);
		hud.loadState(config);
		// Restore last profile.
		profiles.loadState(config);
		resourcePack.loadState(config);
		// Announce.
		Log.banner(adapter);
	}

	/** Persist all state and tear down. */
	public void shutdown() {
		if (!started) return;
		started = false;
		modules.saveState(config);
		hud.saveState(config);
		ThemeRegistry.get().saveState(config);
		profiles.saveState(config);
		resourcePack.saveState(config);
		config.save();
	}

	// ---- accessors ---------------------------------------------------------
	public MinecraftAdapter adapter() { return adapter; }
	public EventBus events() { return eventBus; }
	public ModuleManager modules() { return modules; }
	public HudManager hud() { return hud; }
	public NotificationManager notifications() { return notifications; }
	public Profiles profiles() { return profiles; }
	public ScreenshotManager screenshots() { return screenshots; }
	public ResourcePackManager resourcePack() { return resourcePack; }
	public ConfigStore config() { return config; }
	public boolean isStarted() { return started; }
}
