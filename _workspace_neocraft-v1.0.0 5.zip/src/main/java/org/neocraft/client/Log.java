package org.neocraft.client;

import org.neocraft.api.MinecraftAdapter;

/**
 * Startup banner and structured logging for NeoCraft.
 *
 * <p>Preserves attribution to the original open-source work this client was
 * inspired by, as required for derivative/rebranded distributions. The TuffXPlus
 * plugin (MIT) and the TuffClient project are credited here and on the in-game
 * credits screen.
 *
 * @author NeoCraft
 */
public final class Log {

	private Log() {}

	/**
	 * Print the NeoCraft startup banner through the adapter's logger. The
	 * adapter maps this to {@code System.out} in the stub and to the host
	 * logger (e.g. Eaglercraft's relay log) in the integration bridge.
	 */
	public static void banner(MinecraftAdapter adapter) {
		info(adapter, "");
		info(adapter, "  ███╗   ██╗██████╗  ██████╗ ███╗   ███╗████████╗");
		info(adapter, "  ████╗  ██║██╔══██╗██╔═══██╗████╗ ████║╚══██╔══╝");
		info(adapter, "  ██╔██╗ ██║██║  ██║██║   ██║██╔████╔██║   ██║   ");
		info(adapter, "  ██║╚██╗██║██║  ██║██║   ██║██║╚██╔╝██║   ██║   ");
		info(adapter, "  ██║ ╚████║██████╔╝╚██████╔╝██║ ╚═╝ ██║   ██║   ");
		info(adapter, "  ╚═╝  ╚═══╝╚═════╝  ╚═════╝ ╚═╝     ╚═╝   ╚═╝   ");
		info(adapter, "");
		info(adapter, "  " + Brand.FULL_BRAND + "  ·  " + Brand.MINECRAFT_VERSION);
		info(adapter, "  " + Brand.SPLASH);
		info(adapter, "");
		info(adapter, "  CREDITS");
		info(adapter, "  • NeoCraft — original PvP client layer");
		info(adapter, "  • Inspired by TuffClient / TuffXPlus (MIT, © TuffNetwork)");
		info(adapter, "    TuffXPlus plugin authors: Potato, SyntaxSavy, llucasandersen,");
		info(adapter, "    coleis1op, UplandJacob — MIT licensed, see LICENSE");
		info(adapter, "  • Minecraft 1.12.2 — Mojang AB");
		info(adapter, "");
	}

	public static void info(MinecraftAdapter adapter, String message) {
		// Routed through System.out; the integration bridge can redirect.
		System.out.println("[NeoCraft] " + message);
	}

	public static void warn(MinecraftAdapter adapter, String message) {
		System.out.println("[NeoCraft/WARN] " + message);
	}

	public static void error(MinecraftAdapter adapter, String message) {
		System.out.println("[NeoCraft/ERROR] " + message);
	}

	/** Convenience: log using the running instance's adapter. */
	public static void info(String message) {
		NeoCraft c = NeoCraft.get();
		if (c != null) info(c.adapter(), message); else System.out.println("[NeoCraft] " + message);
	}
}
