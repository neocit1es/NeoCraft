package org.neocraft.modules;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/** A single-choice setting cycling through a fixed list of modes. */
public class ModeSetting extends Setting {

	private final List<String> modes;
	private int index;

	/**
	 * Convenience constructor with no description.
	 * Uses a {@code List} rather than varargs to avoid ambiguity with the
	 * described constructor (two {@code String...} signatures are inherently ambiguous).
	 */
	public ModeSetting(String name, List<String> modes) {
		this(name, null, modes.toArray(new String[0]));
	}

	public ModeSetting(String name, String description, String... modes) {
		super(name, description);
		this.modes = Collections.unmodifiableList(Arrays.asList(modes));
		this.index = 0;
	}

	public List<String> modes() { return modes; }

	public String get() { return modes.get(index); }

	public void set(String mode) {
		int i = modes.indexOf(mode);
		if (i >= 0) index = i;
	}

	public void setIndex(int i) {
		if (i >= 0 && i < modes.size()) index = i;
	}

	public int index() { return index; }

	public void cycle() {
		index = (index + 1) % modes.size();
	}

	@Override public String serialize() { return get(); }
	@Override public void deserialize(String value) {
		if (value != null) set(value);
	}
}
