package org.neocraft.modules;

import org.neocraft.api.ConfigStore;
import org.neocraft.api.MinecraftAdapter;
import org.neocraft.events.EventBus;
import org.neocraft.events.KeyInputEvent;
import org.neocraft.events.NeoSubscribe;
import org.neocraft.events.TickEvent;
import org.neocraft.modules.impl.ArmorModule;
import org.neocraft.modules.impl.ClockModule;
import org.neocraft.modules.impl.CoordinatesModule;
import org.neocraft.modules.impl.CpsModule;
import org.neocraft.modules.impl.FpsModule;
import org.neocraft.modules.impl.Fullbright;
import org.neocraft.modules.impl.HudEditorModule;
import org.neocraft.modules.impl.KeystrokesModule;
import org.neocraft.modules.impl.NotificationsTrigger;
import org.neocraft.modules.impl.PingModule;
import org.neocraft.modules.impl.PotionModule;
import org.neocraft.modules.impl.ReachDisplay;
import org.neocraft.modules.impl.SessionStatsModule;
import org.neocraft.modules.impl.Sprint;
import org.neocraft.modules.impl.Zoom;

import java.util.ArrayList;
import java.util.Collections;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * Owns the lifecycle of every {@link Module}: registration, keybind dispatch,
 * per-category grouping, favourites, and persistence.
 *
 * @author NeoCraft
 */
public final class ModuleManager {

	private final MinecraftAdapter adapter;
	private final EventBus eventBus;
	private final List<Module> modules = new CopyOnWriteArrayList<>();
	private final Map<Category, List<Module>> byCategory = new EnumMap<>(Category.class);
	private boolean registered;

	public ModuleManager(MinecraftAdapter adapter, EventBus eventBus) {
		this.adapter = adapter;
		this.eventBus = eventBus;
		for (Category c : Category.values()) byCategory.put(c, new ArrayList<>());
	}

	/** Register the built-in module set once. Idempotent. */
	public synchronized void registerBuiltins() {
		if (registered) return;
		registered = true;
		eventBus.register(this);
		// Render
		addModule(new Fullbright());
		addModule(new ReachDisplay());
		addModule(new Zoom());
		// Movement
		addModule(new Sprint());
		// Misc
		addModule(new NotificationsTrigger());
		// HUD toggles (mirror HudManager elements)
		addModule(new FpsModule());
		addModule(new PingModule());
		addModule(new CoordinatesModule());
		addModule(new CpsModule());
		addModule(new KeystrokesModule());
		addModule(new ArmorModule());
		addModule(new PotionModule());
		addModule(new ClockModule());
		addModule(new SessionStatsModule());
		addModule(new HudEditorModule());
	}

	/** Add a module instance. */
	public void addModule(Module module) {
		modules.add(module);
		byCategory.get(module.category()).add(module);
	}

	/** Unmodifiable view of all modules. */
	public List<Module> all() {
		return Collections.unmodifiableList(modules);
	}

	/** Modules in a category. */
	public List<Module> inCategory(Category category) {
		return Collections.unmodifiableList(byCategory.getOrDefault(category, Collections.emptyList()));
	}

	/** Lookup by name (case-insensitive). */
	public Module get(String name) {
		for (Module m : modules) if (m.name().equalsIgnoreCase(name)) return m;
		return null;
	}

	/** Favourite modules, in registration order. */
	public List<Module> favourites() {
		List<Module> out = new ArrayList<>();
		for (Module m : modules) if (m.isFavourite()) out.add(m);
		return out;
	}

	/** Modules whose name/description match {@code query} (case-insensitive). */
	public List<Module> search(String query) {
		String q = query == null ? "" : query.trim().toLowerCase();
		List<Module> out = new ArrayList<>();
		if (q.isEmpty()) return out;
		for (Module m : modules) {
			if (m.name().toLowerCase().contains(q) || m.description().toLowerCase().contains(q)) out.add(m);
		}
		return out;
	}

	@NeoSubscribe
	private void onKey(KeyInputEvent event) {
		for (Module m : modules) {
			if (m.keyCode() != 0 && m.keyCode() == event.keyCode) {
				m.toggle();
			}
		}
	}

	// ---- persistence -------------------------------------------------------
	public void saveState(ConfigStore cfg) {
		for (Module m : modules) {
			cfg.set("module." + m.name().toLowerCase().replace(' ', '_'), m.serialize());
		}
	}

	public void loadState(ConfigStore cfg) {
		for (Module m : modules) {
			m.ensureSettings();
			String s = cfg.get("module." + m.name().toLowerCase().replace(' ', '_'));
			if (s != null) m.deserialize(s);
		}
	}

	/** Tick every enabled module. Called by the host each game tick. */
	public void tick() {
		eventBus.post(new TickEvent());
	}

	MinecraftAdapter adapter() { return adapter; }
	EventBus eventBus() { return eventBus; }
}
