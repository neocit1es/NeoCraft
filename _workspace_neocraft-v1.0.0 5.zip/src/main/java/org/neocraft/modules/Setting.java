package org.neocraft.modules;

/**
 * Base class for a module setting. Settings are owned by a {@link Module} and
 * rendered by the ClickGUI with category-appropriate controls.
 *
 * @author NeoCraft
 */
public abstract class Setting {

	private final String name;
	private final String description;
	private boolean visible = true;

	protected Setting(String name, String description) {
		this.name = name;
		this.description = description;
	}

	public String name() { return name; }
	public String description() { return description; }
	public boolean isVisible() { return visible; }
	public void setVisible(boolean visible) { this.visible = visible; }

	/** Persist to a string value for {@link org.neocraft.api.ConfigStore}. */
	public abstract String serialize();

	/** Restore from a previously serialised string. */
	public abstract void deserialize(String value);
}
