package org.neocraft.modules;

/** A boolean toggle setting. */
public class BooleanSetting extends Setting {

	private boolean value;

	public BooleanSetting(String name, boolean defaultValue) {
		this(name, null, defaultValue);
	}

	public BooleanSetting(String name, String description, boolean defaultValue) {
		super(name, description);
		this.value = defaultValue;
	}

	public boolean get() { return value; }
	public void set(boolean value) { this.value = value; }

	@Override public String serialize() { return Boolean.toString(value); }
	@Override public void deserialize(String value) {
		if (value != null) this.value = Boolean.parseBoolean(value);
	}
}
