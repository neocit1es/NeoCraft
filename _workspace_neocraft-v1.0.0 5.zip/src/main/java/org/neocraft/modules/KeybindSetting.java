package org.neocraft.modules;

/** A keybind setting storing an LWJGL key code (0 = unbound). */
public class KeybindSetting extends Setting {

	private int keyCode;

	public KeybindSetting(String name, int defaultKeyCode) {
		this(name, null, defaultKeyCode);
	}

	public KeybindSetting(String name, String description, int defaultKeyCode) {
		super(name, description);
		this.keyCode = defaultKeyCode;
	}

	public int get() { return keyCode; }
	public void set(int keyCode) { this.keyCode = keyCode; }
	public boolean isBound() { return keyCode != 0; }

	@Override public String serialize() { return Integer.toString(keyCode); }
	@Override public void deserialize(String value) {
		if (value == null) return;
		try { keyCode = Integer.parseInt(value); } catch (NumberFormatException ignored) {}
	}
}
