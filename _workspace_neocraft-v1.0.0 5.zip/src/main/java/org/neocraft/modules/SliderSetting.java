package org.neocraft.modules;

/** A double slider setting with min/max/step and an optional integer mode. */
public class SliderSetting extends Setting {

	private final double min;
	private final double max;
	private final double step;
	private final boolean integer;
	private double value;

	public SliderSetting(String name, double min, double max, double defaultValue) {
		this(name, null, min, max, defaultValue, 0.1, false);
	}

	/** Convenience: described double slider with default step 0.1. */
	public SliderSetting(String name, String description, double min, double max, double defaultValue) {
		this(name, description, min, max, defaultValue, 0.1, false);
	}

	/** Convenience: described integer slider with step 1. */
	public SliderSetting(String name, String description, int min, int max, int defaultValue) {
		this(name, description, min, max, defaultValue, 1, true);
	}

	public SliderSetting(String name, String description, double min, double max,
						 double defaultValue, double step, boolean integer) {
		super(name, description);
		this.min = min;
		this.max = max;
		this.step = step <= 0 ? 0.1 : step;
		this.integer = integer;
		this.value = clamp(defaultValue);
	}

	public double min() { return min; }
	public double max() { return max; }
	public double step() { return step; }
	public boolean isInteger() { return integer; }

	public double get() { return value; }
	public int getInt() { return (int) Math.round(value); }

	public void set(double value) { this.value = clamp(value); }

	private double clamp(double v) {
		if (v < min) v = min;
		if (v > max) v = max;
		// snap to step grid
		double steps = Math.round((v - min) / step);
		double snapped = min + steps * step;
		if (snapped > max) snapped = max;
		return integer ? Math.round(snapped) : snapped;
	}

	@Override public String serialize() {
		return integer ? Integer.toString(getInt()) : Double.toString(value);
	}
	@Override public void deserialize(String value) {
		if (value == null) return;
		try { set(Double.parseDouble(value)); } catch (NumberFormatException ignored) {}
	}
}
