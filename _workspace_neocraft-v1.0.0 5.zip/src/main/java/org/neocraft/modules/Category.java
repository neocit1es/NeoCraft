package org.neocraft.modules;

/**
 * Module categories for the ClickGUI grouping and HUD organisation.
 *
 * @author NeoCraft
 */
public enum Category {
	COMBAT("Combat", "\u2694"),     // crossed swords
	MOVEMENT("Movement", "\u27A4"), // arrowhead
	RENDER("Render", "\u25C9"),     // fisheye
	PLAYER("Player", "\u263B"),     // smiley
	HUD("HUD", "\u25A6"),           // square pattern
	WORLD("World", "\u25D0"),       // half circle
	MISC("Misc", "\u2699");         // gear

	private final String displayName;
	private final String icon;

	Category(String displayName, String icon) {
		this.displayName = displayName;
		this.icon = icon;
	}

	public String displayName() { return displayName; }
	public String icon() { return icon; }
}
