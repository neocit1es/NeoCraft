package org.neocraft.modules.impl;

import org.neocraft.modules.BooleanSetting;
import org.neocraft.modules.Category;
import org.neocraft.modules.Module;

/**
 * Sprint \u2014 automatically keeps the player sprinting while moving forward.
 *
 * <p>With {@code Always} off, sprint is only forced while the forward key is
 * held; with it on, sprint is forced whenever the player is on the ground and
 * able to move. On disable the forced sprint state is released so vanilla
 * behaviour resumes.
 *
 * @author NeoCraft
 */
public final class Sprint extends Module {

	private final BooleanSetting always;

	public Sprint() {
		super("Sprint", "Automatically sprints while moving forward.", Category.MOVEMENT);
		this.always = new BooleanSetting("Always", "Sprint even when not pressing forward.", false);
	}

	@Override
	protected void configure() {
		addSetting(always);
	}

	@Override
	protected void onTick() {
		if (adapter == null || !adapter.isInGame()) return;
		// W = LWJGL key 17
		boolean forward = adapter.isKeyDown(17);
		boolean shouldSprint = always.get() || forward;
		adapter.setSprinting(shouldSprint);
	}

	@Override
	protected void onDisable() {
		if (adapter != null) adapter.setSprinting(false);
	}
}
