package org.neocraft.modules.impl;

/** Armor HUD toggle module. */
public final class ArmorModule extends HudToggleModule {
	public ArmorModule() { super("ArmorHUD", "Shows your equipped armor and held item.", "armor"); }
}
