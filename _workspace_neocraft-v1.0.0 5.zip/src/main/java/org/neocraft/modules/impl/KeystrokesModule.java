package org.neocraft.modules.impl;

/** Keystrokes HUD toggle module. */
public final class KeystrokesModule extends HudToggleModule {
	public KeystrokesModule() { super("Keystrokes", "Shows which keys and mouse buttons you hold.", "keystrokes"); }
}
