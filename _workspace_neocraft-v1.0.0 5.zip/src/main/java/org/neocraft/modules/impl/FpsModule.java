package org.neocraft.modules.impl;

/** FPS HUD toggle module. */
public final class FpsModule extends HudToggleModule {
	public FpsModule() { super("FPS", "Shows your frames per second.", "fps"); }
}
