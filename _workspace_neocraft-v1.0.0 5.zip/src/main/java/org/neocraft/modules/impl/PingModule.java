package org.neocraft.modules.impl;

/** Ping HUD toggle module. */
public final class PingModule extends HudToggleModule {
	public PingModule() { super("Ping", "Shows your network latency.", "ping"); }
}
