package org.neocraft.modules.impl;

/** Session stats HUD toggle module. */
public final class SessionStatsModule extends HudToggleModule {
	public SessionStatsModule() { super("SessionStats", "Shows session uptime, FPS, and ping.", "session"); }
}
