package org.neocraft.modules.impl;

import org.neocraft.client.NeoCraft;
import org.neocraft.modules.BooleanSetting;
import org.neocraft.modules.Category;
import org.neocraft.modules.Module;
import org.neocraft.modules.SliderSetting;
import org.neocraft.util.NotificationManager;

/**
 * NotificationsTrigger \u2014 watches player vitals and fires toast notifications
 * when they cross configurable danger thresholds.
 *
 * <p>Alerts are rate-limited so a single low-health situation produces one
 * notification rather than spamming every tick. Each alert type can be toggled
 * independently and its threshold tuned.
 *
 * @author NeoCraft
 */
public final class NotificationsTrigger extends Module {

	private final BooleanSetting lowHealth = new BooleanSetting("Low Health", "Warn when health drops below threshold.", true);
	private final SliderSetting healthThreshold = new SliderSetting("Health", "Hearts below which to warn.", 0, 20, 6);
	private final BooleanSetting lowFood = new BooleanSetting("Low Food", "Warn when food drops below threshold.", true);
	private final SliderSetting foodThreshold = new SliderSetting("Food", "Food below which to warn.", 0, 20, 6);
	private final BooleanSetting lowArmor = new BooleanSetting("Low Armor", "Warn when armor drops below threshold.", false);
	private final SliderSetting armorThreshold = new SliderSetting("Armor", "Armor below which to warn.", 0, 20, 4);

	private long lastHealthAlert = Long.MIN_VALUE / 2;
	private long lastFoodAlert = Long.MIN_VALUE / 2;
	private long lastArmorAlert = Long.MIN_VALUE / 2;
	private static final long COOLDOWN_MS = 8000;

	public NotificationsTrigger() {
		super("Notifications", "Triggers alerts for low health, food, and armor.", Category.MISC);
	}

	@Override
	protected void configure() {
		addSetting(lowHealth);
		addSetting(healthThreshold);
		addSetting(lowFood);
		addSetting(foodThreshold);
		addSetting(lowArmor);
		addSetting(armorThreshold);
	}

	@Override
	protected void onTick() {
		if (adapter == null || !adapter.isInGame()) return;
		NeoCraft nc = NeoCraft.get();
		if (nc == null) return;
		NotificationManager nm = nc.notifications();
		long now = adapter.currentTimeMillis();

		if (lowHealth.get()) {
			float hp = adapter.getHealth();
			float max = adapter.getMaxHealth();
			if (hp > 0 && hp <= healthThreshold.get() && now - lastHealthAlert > COOLDOWN_MS) {
				nm.warning("Low Health", String.format("%.0f / %.0f hearts", hp, max));
				lastHealthAlert = now;
			}
		}
		if (lowFood.get()) {
			int food = adapter.getFood();
			if (food > 0 && food <= foodThreshold.getInt() && now - lastFoodAlert > COOLDOWN_MS) {
				nm.warning("Low Food", food + " / 20 hunger");
				lastFoodAlert = now;
			}
		}
		if (lowArmor.get()) {
			int arm = adapter.getArmor();
			if (arm >= 0 && arm <= armorThreshold.getInt() && now - lastArmorAlert > COOLDOWN_MS) {
				nm.warning("Low Armor", arm + " / 20 armor");
				lastArmorAlert = now;
			}
		}
	}
}
