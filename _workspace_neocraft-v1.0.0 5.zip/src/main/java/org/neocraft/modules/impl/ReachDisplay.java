package org.neocraft.modules.impl;

import org.neocraft.api.GameRenderer;
import org.neocraft.api.MinecraftAdapter;
import org.neocraft.client.NeoCraft;
import org.neocraft.events.NeoSubscribe;
import org.neocraft.events.Render2DEvent;
import org.neocraft.modules.Category;
import org.neocraft.modules.Module;
import org.neocraft.theme.Theme;
import org.neocraft.util.PanelRenderer;

/**
 * ReachDisplay \u2014 renders the player's current attack reach as a small HUD
 * indicator so PvP players can tell whether hits will register.
 *
 * <p>Draws a rounded translucent pill near the crosshair area showing the reach
 * value in blocks, colour-coded by how close it is to the 3.0 block default.
 *
 * @author NeoCraft
 */
public final class ReachDisplay extends Module {

	private final MinecraftAdapter liveAdapter;

	public ReachDisplay() {
		super("ReachDisplay", "Shows your current attack reach on screen.", Category.RENDER);
		this.liveAdapter = NeoCraft.get() != null ? NeoCraft.get().adapter() : null;
	}

	private MinecraftAdapter adapter() {
		return liveAdapter != null ? liveAdapter : adapter;
	}

	@NeoSubscribe
	private void onRender2D(Render2DEvent event) {
		if (!isEnabled()) return;
		MinecraftAdapter a = adapter();
		if (a == null || !a.isInGame()) return;
		double reach = a.getReach();
		String text = String.format("Reach: %.2f", reach);
		GameRenderer r = a.renderer();
		double w = a.fonts().stringWidth(text) + 16;
		double h = a.fonts().fontHeight() + 10;
		double x = a.getScaledWidth() / 2.0 - w / 2.0;
		double y = a.getScaledHeight() / 2.0 + 18;
		int color = reach >= 2.9 ? Theme.liveSuccess() : (reach >= 2.5 ? Theme.liveWarning() : Theme.liveError());
		PanelRenderer p = new PanelRenderer(r, a.fonts());
		p.panel(x, y, w, h);
		r.drawCircle(x + 8, y + h / 2.0, 3, color);
		a.fonts().draw(text, x + 16, y + 5, Theme.liveText());
	}
}
