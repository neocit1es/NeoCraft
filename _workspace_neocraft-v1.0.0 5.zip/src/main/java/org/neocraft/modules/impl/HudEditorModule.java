package org.neocraft.modules.impl;

import org.neocraft.client.NeoCraft;
import org.neocraft.modules.Category;
import org.neocraft.modules.Module;

/**
 * HUD Editor \u2014 toggles the in-game HUD layout editor so the user can drag
 * HUD elements to reposition them.
 *
 * @author NeoCraft
 */
public final class HudEditorModule extends Module {

	public HudEditorModule() {
		super("HUDEditor", "Toggle the HUD layout editor to drag elements.", Category.HUD);
	}

	@Override
	protected void onEnable() {
		NeoCraft nc = NeoCraft.get();
		if (nc != null) nc.hud().setEditor(true);
	}

	@Override
	protected void onDisable() {
		NeoCraft nc = NeoCraft.get();
		if (nc != null) nc.hud().setEditor(false);
	}
}
