package org.neocraft.modules.impl;

import org.neocraft.modules.Category;
import org.neocraft.modules.Module;
import org.neocraft.modules.SliderSetting;

/**
 * Fullbright \u2014 forces maximum gamma so caves and the night sky are fully lit.
 *
 * <p>When enabled the adapter gamma is pushed to the configured target (default
 * 15.0, well above the vanilla 1.0 cap, which the integration bridge maps to a
 * brightness override). On disable the previous gamma value is restored.
 *
 * @author NeoCraft
 */
public final class Fullbright extends Module {

	private final SliderSetting target;
	private float previousGamma = -1f;

	public Fullbright() {
		super("Fullbright", "Removes darkness by maxing out brightness.", Category.RENDER);
		this.target = new SliderSetting("Gamma", "Target brightness override.", 1.0, 16.0, 15.0);
	}

	@Override
	protected void configure() {
		addSetting(target);
	}

	@Override
	protected void onEnable() {
		if (adapter != null) {
			previousGamma = adapter.getGamma();
			adapter.setGamma((float) target.get());
		}
	}

	@Override
	protected void onTick() {
		if (adapter != null && Math.abs(adapter.getGamma() - target.get()) > 0.01) {
			adapter.setGamma((float) target.get());
		}
	}

	@Override
	protected void onDisable() {
		if (adapter != null) {
			adapter.setGamma(previousGamma >= 0f ? previousGamma : 0.5f);
		}
	}
}
