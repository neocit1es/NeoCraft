package org.neocraft.modules.impl;

/** Clock HUD toggle module. */
public final class ClockModule extends HudToggleModule {
	public ClockModule() { super("Clock", "Shows the real-world time.", "clock"); }
}
