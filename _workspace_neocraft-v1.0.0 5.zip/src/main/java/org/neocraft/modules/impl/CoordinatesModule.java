package org.neocraft.modules.impl;

/** Coordinates HUD toggle module. */
public final class CoordinatesModule extends HudToggleModule {
	public CoordinatesModule() { super("Coordinates", "Shows your XYZ position.", "coordinates"); }
}
