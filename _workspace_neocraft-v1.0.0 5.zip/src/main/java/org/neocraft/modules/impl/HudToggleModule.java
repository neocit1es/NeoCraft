package org.neocraft.modules.impl;

import org.neocraft.client.NeoCraft;
import org.neocraft.hud.HudElement;
import org.neocraft.hud.HudManager;
import org.neocraft.modules.Category;
import org.neocraft.modules.Module;

/**
 * A module whose enable/disable state mirrors a {@link HudElement}'s visibility.
 *
 * <p>This lets every HUD indicator (FPS, Ping, Coordinates, \u2026) appear in the
 * ClickGUI as a normal toggleable module while the actual rendering/layout is
 * owned by the {@link HudManager}. Enabling the module shows the element;
 * disabling hides it.
 *
 * @author NeoCraft
 */
public abstract class HudToggleModule extends Module {

	private final String hudId;

	protected HudToggleModule(String name, String description, String hudId) {
		super(name, description, Category.HUD);
		this.hudId = hudId;
	}

	private HudElement element() {
		NeoCraft nc = NeoCraft.get();
		if (nc == null) return null;
		for (HudElement e : nc.hud().elements()) {
			if (e.id().equals(hudId)) return e;
		}
		return null;
	}

	@Override
	protected void onEnable() {
		HudElement e = element();
		if (e != null) e.setEnabled(true);
	}

	@Override
	protected void onDisable() {
		HudElement e = element();
		if (e != null) e.setEnabled(false);
	}
}
