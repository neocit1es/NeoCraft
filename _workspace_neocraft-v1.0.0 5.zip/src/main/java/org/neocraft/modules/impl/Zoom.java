package org.neocraft.modules.impl;

import org.neocraft.modules.Category;
import org.neocraft.modules.Module;
import org.neocraft.modules.SliderSetting;

/**
 * Zoom \u2014 narrows the field of view while enabled, useful for scouting.
 *
 * <p>The FOV multiplier is driven by a slider (lower = more zoom). On disable
 * the FOV override is cleared (set to 0) so vanilla FOV resumes. Hold-style
 * keybinding is handled by the keybind manager toggling this module.
 *
 * @author NeoCraft
 */
public final class Zoom extends Module {

	private final SliderSetting amount;
	private float previousFov = -1f;

	public Zoom() {
		super("Zoom", "Narrows your field of view for scouting.", Category.RENDER);
		this.amount = new SliderSetting("Zoom", "Lower values zoom in more.", 0.05, 1.0, 0.3);
	}

	@Override
	protected void configure() {
		addSetting(amount);
	}

	@Override
	protected void onEnable() {
		if (adapter != null) {
			previousFov = adapter.getFov();
			adapter.setFov((float) amount.get());
		}
	}

	@Override
	protected void onTick() {
		if (adapter != null && Math.abs(adapter.getFov() - amount.get()) > 0.001) {
			adapter.setFov((float) amount.get());
		}
	}

	@Override
	protected void onDisable() {
		if (adapter != null) {
			adapter.setFov(previousFov >= 0f ? previousFov : 0f);
		}
	}
}
