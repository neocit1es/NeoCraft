package org.neocraft.modules.impl;

/** Potion HUD toggle module. */
public final class PotionModule extends HudToggleModule {
	public PotionModule() { super("PotionHUD", "Shows your active potion effects and durations.", "potion"); }
}
