package org.neocraft.modules.impl;

/** CPS HUD toggle module. */
public final class CpsModule extends HudToggleModule {
	public CpsModule() { super("CPS", "Shows your left/right clicks per second.", "cps"); }
}
