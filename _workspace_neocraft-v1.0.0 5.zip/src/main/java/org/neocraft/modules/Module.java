package org.neocraft.modules;

import org.neocraft.api.MinecraftAdapter;
import org.neocraft.client.NeoCraft;
import org.neocraft.events.EventBus;
import org.neocraft.events.NeoSubscribe;
import org.neocraft.events.TickEvent;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Base class for every NeoCraft module.
 *
 * <p>A module has a name, a {@link Category}, an enable state, an optional
 * keybind, a favourite flag, and an ordered list of {@link Setting}s. Modules
 * register themselves on the {@link EventBus} when enabled so their
 * {@code @NeoSubscribe} handlers receive ticks/render events.
 *
 * @author NeoCraft
 */
public abstract class Module {

	protected final MinecraftAdapter adapter;
	protected final EventBus eventBus;

	private final String name;
	private final String description;
	private final Category category;
	private final List<Setting> settings = new ArrayList<>();

	private boolean enabled;
	private int keyCode;
	private boolean favourite;
	private boolean hidden;

	protected Module(String name, String description, Category category) {
		this.name = name;
		this.description = description;
		this.category = category;
		this.adapter = NeoCraft.get() != null ? NeoCraft.get().adapter() : null;
		this.eventBus = NeoCraft.get() != null ? NeoCraft.get().events() : null;
	}

	/** Convenience constructor used in tests where the adapter is injected. */
	protected Module(String name, String description, Category category, MinecraftAdapter adapter, EventBus eventBus) {
		this.name = name;
		this.description = description;
		this.category = category;
		this.adapter = adapter;
		this.eventBus = eventBus;
	}

	/** Register settings here. Called once by the manager on first enable. */
	protected void configure() {}

	/** Called when the module is enabled. */
	protected void onEnable() {}

	/** Called when the module is disabled. */
	protected void onDisable() {}

	/** Called each tick while enabled. */
	protected void onTick() {}

	// ---- public API --------------------------------------------------------

	public String name() { return name; }
	public String description() { return description; }
	public Category category() { return category; }
	public boolean isEnabled() { return enabled; }
	public boolean isFavourite() { return favourite; }
	public void setFavourite(boolean favourite) { this.favourite = favourite; }
	public boolean isHidden() { return hidden; }
	public void setHidden(boolean hidden) { this.hidden = hidden; }
	public int keyCode() { return keyCode; }
	public void setKeyCode(int keyCode) { this.keyCode = keyCode; }

	public List<Setting> settings() { return Collections.unmodifiableList(settings); }

	/** Find a setting by name. */
	public Setting setting(String name) {
		for (Setting s : settings) if (s.name().equalsIgnoreCase(name)) return s;
		return null;
	}

	/** Typed boolean setting lookup. */
	public BooleanSetting booleanSetting(String name) {
		Setting s = setting(name);
		return s instanceof BooleanSetting ? (BooleanSetting) s : null;
	}

	/** Typed slider setting lookup. */
	public SliderSetting sliderSetting(String name) {
		Setting s = setting(name);
		return s instanceof SliderSetting ? (SliderSetting) s : null;
	}

	/** Typed mode setting lookup. */
	public ModeSetting modeSetting(String name) {
		Setting s = setting(name);
		return s instanceof ModeSetting ? (ModeSetting) s : null;
	}

	protected void addSetting(Setting setting) {
		settings.add(setting);
	}

	/** Enable the module. Safe to call when already enabled. */
	public final void enable() {
		if (enabled) return;
		ensureConfigured();
		enabled = true;
		if (eventBus != null) eventBus.register(this);
		try { onEnable(); } catch (Throwable t) { log("onEnable threw: " + t); }
	}

	/** Disable the module. Safe to call when already disabled. */
	public final void disable() {
		if (!enabled) return;
		enabled = false;
		if (eventBus != null) eventBus.unregister(this);
		try { onDisable(); } catch (Throwable t) { log("onDisable threw: " + t); }
	}

	/** Toggle the module. */
	public final void toggle() {
		if (enabled) disable(); else enable();
	}

	/** Set enabled state explicitly. */
	public final void setEnabled(boolean enabled) {
		if (enabled) enable(); else disable();
	}

	private boolean configured;
	private void ensureConfigured() {
		if (configured) return;
		configured = true;
		try { configure(); } catch (Throwable t) { log("configure threw: " + t); }
	}

	/** Ensure settings are populated even if never enabled (for ClickGUI). */
	public void ensureSettings() { ensureConfigured(); }

	@NeoSubscribe
	private void onTickInternal(TickEvent event) {
		if (enabled) onTick();
	}

	protected void log(String message) {
		System.out.println("[NeoCraft/" + name + "] " + message);
	}

	/** Serialize module state (enabled, key, favourite, settings). */
	public String serialize() {
		StringBuilder sb = new StringBuilder();
		sb.append(enabled ? "1" : "0").append(',');
		sb.append(keyCode).append(',');
		sb.append(favourite ? "1" : "0");
		for (Setting s : settings) {
			sb.append(',').append(s.name()).append('=').append(s.serialize());
		}
		return sb.toString();
	}

	/** Restore module state. */
	public void deserialize(String value) {
		if (value == null || value.isEmpty()) return;
		String[] parts = value.split(",");
		try {
			if (parts.length > 0) setEnabled(parts[0].equals("1"));
			if (parts.length > 1) keyCode = Integer.parseInt(parts[1]);
			if (parts.length > 2) favourite = parts[2].equals("1");
			ensureSettings();
			for (int i = 3; i < parts.length; i++) {
				String p = parts[i];
				int eq = p.indexOf('=');
				if (eq < 0) continue;
				String sname = p.substring(0, eq);
				String sval = p.substring(eq + 1);
				Setting s = setting(sname);
				if (s != null) s.deserialize(sval);
			}
		} catch (Throwable t) {
			log("deserialize failed: " + t);
		}
	}
}
