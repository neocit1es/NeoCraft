package org.neocraft.hud.elements;

import org.neocraft.api.MinecraftAdapter;
import org.neocraft.hud.TextHudElement;

import java.util.List;

public final class PingHud extends TextHudElement {
	public PingHud(MinecraftAdapter adapter) {
		super("ping", "Ping", adapter, true, 4, 22);
	}
	@Override
	protected List<String> lines() {
		int ping = adapter.getPing();
		String text = ping < 0 ? "Ping: --" : "Ping: " + ping + "ms";
		return List.of(text);
	}
}
