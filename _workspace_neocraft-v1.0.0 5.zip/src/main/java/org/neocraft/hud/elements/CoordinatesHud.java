package org.neocraft.hud.elements;

import org.neocraft.api.MinecraftAdapter;
import org.neocraft.hud.TextHudElement;

import java.util.List;

public final class CoordinatesHud extends TextHudElement {
	public CoordinatesHud(MinecraftAdapter adapter) {
		super("coordinates", "Coordinates", adapter, true, 4, 40);
	}
	@Override
	protected List<String> lines() {
		return List.of(
			String.format("XYZ: %.1f / %.1f / %.1f", adapter.getPlayerX(), adapter.getPlayerY(), adapter.getPlayerZ())
		);
	}
}
