package org.neocraft.hud.elements;

import org.neocraft.api.MinecraftAdapter;
import org.neocraft.hud.TextHudElement;
import org.neocraft.theme.Theme;

import java.util.List;

public final class FpsHud extends TextHudElement {
	public FpsHud(MinecraftAdapter adapter) {
		super("fps", "FPS", adapter, true, 4, 4);
	}
	@Override
	protected List<String> lines() {
		int fps = adapter.getFps();
		int color = fps >= 60 ? Theme.liveSuccess() : (fps >= 30 ? Theme.liveWarning() : Theme.liveError());
		// The TextHudElement base draws in liveText; colour is conveyed via a
		// status glyph so the value stays readable while colour signals health.
		String status = fps >= 60 ? "\u25CF" : (fps >= 30 ? "\u25D1" : "\u25CB");
		return List.of(status + " FPS: " + fps);
	}
}
