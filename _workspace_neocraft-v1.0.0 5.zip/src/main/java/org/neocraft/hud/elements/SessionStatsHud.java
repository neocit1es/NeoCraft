package org.neocraft.hud.elements;

import org.neocraft.api.MinecraftAdapter;
import org.neocraft.hud.TextHudElement;

import java.util.List;

/** Session stats — uptime, kills/deaths placeholder, FPS avg. */
public final class SessionStatsHud extends TextHudElement {

	private long sessionStart;

	public SessionStatsHud(MinecraftAdapter adapter) {
		super("session", "Session Stats", adapter, false, 4, 190);
		this.sessionStart = adapter.currentTimeMillis();
	}

	@Override
	protected List<String> lines() {
		long elapsed = adapter.currentTimeMillis() - sessionStart;
		long s = (elapsed / 1000) % 60;
		long m = (elapsed / 60000) % 60;
		long h = elapsed / 3600000;
		return List.of(
			"Session: " + String.format("%d:%02d:%02d", h, m, s),
			"FPS: " + adapter.getFps(),
			"Ping: " + (adapter.getPing() < 0 ? "--" : adapter.getPing() + "ms")
		);
	}
}
