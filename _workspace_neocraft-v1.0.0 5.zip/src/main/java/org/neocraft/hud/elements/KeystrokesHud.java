package org.neocraft.hud.elements;

import org.neocraft.api.MinecraftAdapter;
import org.neocraft.hud.HudElement;
import org.neocraft.theme.Theme;
import org.neocraft.util.PanelRenderer;

/**
 * Keystrokes HUD — W/A/S/D, LMB/RMB, and space, rendered as rounded keys that
 * light up (primary accent) when held.
 */
public final class KeystrokesHud extends HudElement {

	private static final double KEY = 22;
	private static final double GAP = 2;

	public KeystrokesHud(MinecraftAdapter adapter) {
		super("keystrokes", "Keystrokes", adapter, false, 4, 80);
	}

	@Override public double getWidth() { return KEY * 3 + GAP * 2; }
	@Override public double getHeight() { return KEY * 4 + GAP * 3; }

	@Override
	public void render(float partialTicks) {
		PanelRenderer p = panel();
		double x = getX(), y = getY();
		// Row 1: W centered
		drawKey(p, x + KEY + GAP, y, KEY, KEY, "W", 17, adapter.isKeyDown(17)); // W = 17
		// Row 2: A S D
		drawKey(p, x, y + KEY + GAP, KEY, KEY, "A", 30, adapter.isKeyDown(30)); // A
		drawKey(p, x + KEY + GAP, y + KEY + GAP, KEY, KEY, "S", 31, adapter.isKeyDown(31)); // S
		drawKey(p, x + (KEY + GAP) * 2, y + KEY + GAP, KEY, KEY, "D", 32, adapter.isKeyDown(32)); // D
		// Row 3: LMB / RMB (split)
		drawKey(p, x, y + (KEY + GAP) * 2, KEY, KEY, "L", -1, adapter.isMouseLeftDown());
		drawKey(p, x + KEY + GAP, y + (KEY + GAP) * 2, KEY, KEY, "R", -2, adapter.isMouseRightDown());
		drawKey(p, x + (KEY + GAP) * 2, y + (KEY + GAP) * 2, KEY, KEY, "C", -3, adapter.getLeftClickCps() > 0 || adapter.getRightClickCps() > 0);
		// Row 4: space bar
		drawKey(p, x, y + (KEY + GAP) * 3, getWidth(), KEY, "Space", 57, adapter.isKeyDown(57)); // Space
	}

	private void drawKey(PanelRenderer p, double x, double y, double w, double h, String label, int keyCode, boolean held) {
		int fill = held ? Theme.livePrimary() : Theme.liveGlassPanel();
		adapter.renderer().drawRoundedRect(x, y, w, h, 4, fill);
		adapter.renderer().drawHollowRect(x, y, w, h, 1.0f, Theme.liveBorder());
		int color = held ? Theme.liveBackground() : Theme.liveText();
		adapter.fonts().drawCentered(label, x + w / 2.0, y + (h - adapter.fonts().fontHeight()) / 2.0, color);
	}
}
