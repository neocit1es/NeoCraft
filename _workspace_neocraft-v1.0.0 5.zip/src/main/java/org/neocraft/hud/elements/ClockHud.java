package org.neocraft.hud.elements;

import org.neocraft.api.MinecraftAdapter;
import org.neocraft.hud.TextHudElement;

import java.util.List;

/** Clock HUD — real-time clock in HH:MM:SS. */
public final class ClockHud extends TextHudElement {
	public ClockHud(MinecraftAdapter adapter) {
		super("clock", "Clock", adapter, true, 4, 170);
	}
	@Override
	protected List<String> lines() {
		long t = adapter.currentTimeMillis() / 1000L;
		long s = t % 60;
		long m = (t / 60) % 60;
		long h = (t / 3600) % 24;
		return List.of(String.format("Time: %02d:%02d:%02d", h, m, s));
	}
}
