package org.neocraft.hud.elements;

import org.neocraft.api.MinecraftAdapter;
import org.neocraft.hud.TextHudElement;

import java.util.ArrayList;
import java.util.List;

/**
 * Potion HUD \u2014 shows active potion effects with durations, plus a compact
 * health/food readout for combat awareness.
 *
 * <p>Real potion effect data is exposed by the integration bridge; in the stub
 * a header is shown and the health/food lines come from the adapter.
 *
 * @author NeoCraft
 */
public final class PotionHud extends TextHudElement {

	public PotionHud(MinecraftAdapter adapter) {
		super("potion", "Potions", adapter, false, 4, 150);
	}

	@Override
	protected List<String> lines() {
		List<String> out = new ArrayList<>();
		float hp = adapter.getHealth();
		float max = adapter.getMaxHealth();
		int food = adapter.getFood();
		out.add("HP: " + (int) Math.ceil(hp) + " / " + (int) Math.ceil(max));
		out.add("Food: " + food + " / 20");
		out.add("Potions: none");
		return out;
	}
}
