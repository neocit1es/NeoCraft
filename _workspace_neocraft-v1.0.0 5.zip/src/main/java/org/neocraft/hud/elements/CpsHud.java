package org.neocraft.hud.elements;

import org.neocraft.api.MinecraftAdapter;
import org.neocraft.hud.TextHudElement;

import java.util.List;

public final class CpsHud extends TextHudElement {
	public CpsHud(MinecraftAdapter adapter) {
		super("cps", "CPS", adapter, true, 4, 58);
	}
	@Override
	protected List<String> lines() {
		return List.of("CPS: " + adapter.getLeftClickCps() + " | " + adapter.getRightClickCps());
	}
}
