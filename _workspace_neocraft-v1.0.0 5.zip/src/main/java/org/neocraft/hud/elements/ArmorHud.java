package org.neocraft.hud.elements;

import org.neocraft.api.MinecraftAdapter;
import org.neocraft.hud.TextHudElement;

import java.util.ArrayList;
import java.util.List;

/**
 * Armor HUD \u2014 shows the player's armor value and a visual representation of
 * the four armor slots + main hand.
 *
 * <p>The integration bridge exposes real item stacks; in the stub the slot
 * glyphs are placeholders but the armor total is read from the adapter.
 *
 * @author NeoCraft
 */
public final class ArmorHud extends TextHudElement {

	public ArmorHud(MinecraftAdapter adapter) {
		super("armor", "Armor", adapter, false, 4, 130);
	}

	@Override
	protected List<String> lines() {
		int armor = adapter.getArmor();
		List<String> out = new ArrayList<>();
		out.add("Armor: " + armor + " / 20");
		out.add("[H] [C] [L] [B] | Hand");
		return out;
	}

	@Override
	protected double padding() { return 6.0; }
}
