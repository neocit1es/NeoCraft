package org.neocraft.hud;

import org.neocraft.api.ConfigStore;
import org.neocraft.api.MinecraftAdapter;
import org.neocraft.api.FontRenderer;
import org.neocraft.api.GameRenderer;
import org.neocraft.events.EventBus;
import org.neocraft.hud.elements.ArmorHud;
import org.neocraft.hud.elements.ClockHud;
import org.neocraft.hud.elements.CoordinatesHud;
import org.neocraft.hud.elements.CpsHud;
import org.neocraft.hud.elements.FpsHud;
import org.neocraft.hud.elements.KeystrokesHud;
import org.neocraft.hud.elements.PingHud;
import org.neocraft.hud.elements.PotionHud;
import org.neocraft.hud.elements.SessionStatsHud;
import org.neocraft.theme.Theme;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Owns all {@link HudElement}s, their layout, the HUD editor mode, and
 * persistence of positions.
 *
 * <p>In editor mode every enabled element is drawn with a draggable frame and
 * a label, and mouse events are dispatched to the element under the cursor so
 * the user can reposition HUD indicators. Positions are persisted per element.
 *
 * @author NeoCraft
 */
public final class HudManager {

	private final MinecraftAdapter adapter;
	private final EventBus eventBus;
	private final List<HudElement> elements = new ArrayList<>();
	private boolean editor;

	public HudManager(MinecraftAdapter adapter, EventBus eventBus) {
		this.adapter = adapter;
		this.eventBus = eventBus;
		registerElements();
	}

	private void registerElements() {
		elements.add(new FpsHud(adapter));
		elements.add(new PingHud(adapter));
		elements.add(new CoordinatesHud(adapter));
		elements.add(new CpsHud(adapter));
		elements.add(new KeystrokesHud(adapter));
		elements.add(new ArmorHud(adapter));
		elements.add(new PotionHud(adapter));
		elements.add(new ClockHud(adapter));
		elements.add(new SessionStatsHud(adapter));
	}

	public List<HudElement> elements() { return Collections.unmodifiableList(elements); }

	/** Find an element by id. */
	public HudElement get(String id) {
		for (HudElement e : elements) if (e.id().equals(id)) return e;
		return null;
	}

	public boolean isEditor() { return editor; }
	public void setEditor(boolean editor) { this.editor = editor; }
	public void toggleEditor() { this.editor = !this.editor; }

	/** Render all enabled elements. Called by the host each 2D frame. */
	public void render(float partialTicks) {
		for (HudElement e : elements) {
			if (e.isEnabled()) {
				e.render(partialTicks);
				if (editor) renderEditorFrame(e);
			}
		}
		if (editor) renderEditorHint();
	}

	/** Draw a draggable frame + label around an element in editor mode. */
	private void renderEditorFrame(HudElement e) {
		e.renderEditor();
		FontRenderer f = adapter.fonts();
		GameRenderer r = adapter.renderer();
		double labelW = f.stringWidth(e.displayName()) + 8;
		double labelH = f.fontHeight() + 4;
		double lx = e.getX();
		double ly = e.getY() - labelH - 2;
		if (ly < 0) ly = e.getY() + e.getHeight() + 2;
		r.drawRoundedRect(lx, ly, labelW, labelH, 3, Theme.livePanel());
		r.drawHollowRect(lx, ly, labelW, labelH, 1.0f, Theme.liveBorder());
		f.draw(e.displayName(), lx + 4, ly + 2, Theme.livePrimary());
	}

	/** Draw a small hint at the bottom of the screen while editing. */
	private void renderEditorHint() {
		FontRenderer f = adapter.fonts();
		GameRenderer r = adapter.renderer();
		String hint = "Drag elements to reposition \u2014 press the HUD key to exit";
		double w = f.stringWidth(hint) + 16;
		double h = f.fontHeight() + 10;
		double x = (adapter.getScaledWidth() - w) / 2.0;
		double y = adapter.getScaledHeight() - h - 6;
		r.drawRoundedRect(x, y, w, h, 6, Theme.liveGlassPanel());
		r.drawHollowRect(x, y, w, h, 1.0f, Theme.liveBorder());
		f.drawCentered(hint, x + w / 2.0, y + 5, Theme.liveText());
	}

	// ---- editor mouse dispatch --------------------------------------------

	/** Forward a mouse click to the element under the cursor (editor mode). */
	public boolean onMouseClick(double mouseX, double mouseY) {
		if (!editor) return false;
		// iterate top-most last so overlapping elements pick correctly
		for (int i = elements.size() - 1; i >= 0; i--) {
			HudElement e = elements.get(i);
			if (e.isEnabled() && e.onMouseClick(mouseX, mouseY, true)) return true;
		}
		return false;
	}

	/** Forward a mouse drag to whichever element is currently dragging. */
	public void onMouseDrag(double mouseX, double mouseY) {
		for (HudElement e : elements) {
			if (e.isDragging()) e.onMouseDrag(mouseX, mouseY);
		}
	}

	/** Release any dragging element. */
	public void onMouseRelease() {
		for (HudElement e : elements) e.onMouseRelease();
	}

	// ---- persistence -------------------------------------------------------
	public void saveState(ConfigStore cfg) {
		for (HudElement e : elements) {
			e.saveState(cfg);
		}
		cfg.setBoolean("hud.editor", editor);
	}

	public void loadState(ConfigStore cfg) {
		for (HudElement e : elements) {
			e.loadState(cfg);
		}
		editor = cfg.getBoolean("hud.editor", false);
	}

	MinecraftAdapter adapter() { return adapter; }
}
