package org.neocraft.hud;

import org.neocraft.api.MinecraftAdapter;
import org.neocraft.theme.Theme;
import org.neocraft.util.PanelRenderer;

/**
 * A HUD element that renders as a single rounded translucent panel containing
 * one or more text lines. Most NeoCraft HUD elements derive from this.
 *
 * @author NeoCraft
 */
public abstract class TextHudElement extends HudElement {

	protected TextHudElement(String id, String displayName, MinecraftAdapter adapter, boolean defaultEnabled, double defaultX, double defaultY) {
		super(id, displayName, adapter, defaultEnabled, defaultX, defaultY);
	}

	/** Lines to render, top to bottom. */
	protected abstract java.util.List<String> lines();

	/** Padding inside the panel. */
	protected double padding() { return 6.0; }

	/** Spacing between lines. */
	protected double lineSpacing() { return 2.0; }

	@Override
	public double getWidth() {
		double max = 0;
		for (String line : lines()) {
			max = Math.max(max, adapter.fonts().stringWidth(line));
		}
		return max + padding() * 2;
	}

	@Override
	public double getHeight() {
		var l = lines();
		int count = Math.max(1, l.size());
		return count * adapter.fonts().fontHeight() + (count - 1) * lineSpacing() + padding() * 2;
	}

	@Override
	public void render(float partialTicks) {
		java.util.List<String> l = lines();
		PanelRenderer p = panel();
		p.panel(getX(), getY(), getWidth(), getHeight());
		double ty = getY() + padding();
		for (String line : l) {
			adapter.fonts().draw(line, getX() + padding(), ty, Theme.liveText());
			ty += adapter.fonts().fontHeight() + lineSpacing();
		}
	}
}
