package org.neocraft.hud;

import org.neocraft.api.ConfigStore;
import org.neocraft.api.MinecraftAdapter;
import org.neocraft.theme.Theme;
import org.neocraft.util.PanelRenderer;

/**
 * Base class for every on-screen HUD element.
 *
 * <p>Each element owns a draggable {@link PanelRenderer} (rounded translucent
 * panel), an enable flag, and a position. The {@link HudManager} drives
 * rendering; the HUD editor lets the user drag/resize. State is persisted per
 * element.
 *
 * @author NeoCraft
 */
public abstract class HudElement {

	protected final MinecraftAdapter adapter;
	protected final String id;
	private final String displayName;

	private boolean enabled;
	private double x;
	private double y;
	private boolean dragging;
	private double dragOffsetX;
	private double dragOffsetY;

	protected HudElement(String id, String displayName, MinecraftAdapter adapter, boolean defaultEnabled, double defaultX, double defaultY) {
		this.id = id;
		this.displayName = displayName;
		this.adapter = adapter;
		this.enabled = defaultEnabled;
		this.x = defaultX;
		this.y = defaultY;
	}

	public String id() { return id; }
	public String displayName() { return displayName; }
	public boolean isEnabled() { return enabled; }
	public void setEnabled(boolean enabled) { this.enabled = enabled; }
	public void toggle() { enabled = !enabled; }
	public double getX() { return x; }
	public double getY() { return y; }
	public void setPos(double x, double y) { this.x = x; this.y = y; }

	/** Element's current width (for hit-testing & panel sizing). */
	public abstract double getWidth();

	/** Element's current height. */
	public abstract double getHeight();

	/** Draw the element's content at its position. */
	public abstract void render(float partialTicks);

	/** Draw an editor frame (handles + outline) around the element. */
	public void renderEditor() {
		PanelRenderer p = panel();
		p.outline(getX(), getY(), getWidth(), getHeight(), Theme.liveBorder());
	}

	/** Default panel used by elements for the rounded translucent background. */
	protected PanelRenderer panel() {
		return new PanelRenderer(adapter.renderer(), adapter.fonts());
	}

	// ---- editor interaction ------------------------------------------------
	public boolean isDragging() { return dragging; }

	public boolean onMouseClick(double mouseX, double mouseY, boolean editor) {
		if (!editor || !enabled) return false;
		if (mouseX >= x && mouseX <= x + getWidth() && mouseY >= y && mouseY <= y + getHeight()) {
			dragging = true;
			dragOffsetX = mouseX - x;
			dragOffsetY = mouseY - y;
			return true;
		}
		return false;
	}

	public void onMouseDrag(double mouseX, double mouseY) {
		if (!dragging) return;
		double nx = mouseX - dragOffsetX;
		double ny = mouseY - dragOffsetY;
		// clamp into viewport
		int sw = adapter.getScaledWidth();
		int sh = adapter.getScaledHeight();
		if (nx < 0) nx = 0;
		if (ny < 0) ny = 0;
		if (nx + getWidth() > sw) nx = sw - getWidth();
		if (ny + getHeight() > sh) ny = sh - getHeight();
		x = nx;
		y = ny;
	}

	public void onMouseRelease() {
		dragging = false;
	}

	// ---- persistence -------------------------------------------------------
	public void saveState(ConfigStore cfg) {
		String base = "hud." + id;
		cfg.setBoolean(base + ".enabled", enabled);
		cfg.setDouble(base + ".x", x);
		cfg.setDouble(base + ".y", y);
	}

	public void loadState(ConfigStore cfg) {
		String base = "hud." + id;
		enabled = cfg.getBoolean(base + ".enabled", enabled);
		x = cfg.getDouble(base + ".x", x);
		y = cfg.getDouble(base + ".y", y);
	}
}
