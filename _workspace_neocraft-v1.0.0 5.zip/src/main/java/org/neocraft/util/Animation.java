package org.neocraft.util;

/**
 * A smooth, time-driven animated float that eases toward a target value.
 *
 * <p>Used throughout the GUI for fade-ins, slide-ins, and hover transitions.
 * The animation is driven by a clock (millisecond time supplied by the
 * adapter) so it advances independently of frame rate. Call {@link #update}
 * each frame with the current time, then read {@link #value()}.
 *
 * <p>Two modes:
 * <ul>
 *   <li><b>Duration-based</b> \u2014 set via {@link #to(float, long)} with an
 *       explicit duration; progress is derived from elapsed time.</li>
 *   <li><b>Continuous lerp</b> \u2014 set the target with {@link #target(float)}
 *       and a speed; the value asymptotically approaches it every update.</li>
 * </ul>
 *
 * @author NeoCraft
 */
public final class Animation {

	/** Functional interface for an easing curve. */
	@FunctionalInterface
	public interface Ease {
		float apply(float t);
	}

	private float value;
	private float target;
	private float start;
	private long startTime;
	private long duration;
	private boolean animating;
	private Ease ease = Easing::easeOutExpo;

	// continuous-lerp config
	private boolean continuous;
	private float speed = 0.15f; // fraction of remaining distance per update

	/** Create an animation starting at {@code initial}. */
	public Animation(float initial) {
		this.value = initial;
		this.target = initial;
		this.start = initial;
	}

	/** Set the easing curve used for duration-based animations. */
	public Animation ease(Ease ease) {
		if (ease != null) this.ease = ease;
		return this;
	}

	/** Current animated value. */
	public float value() {
		return value;
	}

	/** Current target value. */
	public float target() {
		return target;
	}

	/** Whether a duration-based animation is still running. */
	public boolean isAnimating() {
		return animating;
	}

	/** Whether the value has reached the target (within a small epsilon). */
	public boolean settled() {
		return Math.abs(value - target) < 0.001f;
	}

	/** Instantly snap to {@code v}. */
	public void snap(float v) {
		value = v;
		target = v;
		start = v;
		animating = false;
		continuous = false;
	}

	/** Animate to {@code v} over {@code millis} milliseconds (uses system clock). */
	public void to(float v, long millis) {
		to(v, millis, System.currentTimeMillis());
	}

	/** Animate to {@code v} over {@code millis} starting at {@code nowMillis}. */
	public void to(float v, long millis, long nowMillis) {
		if (Math.abs(v - target) < 1e-6f && !animating) return;
		start = value;
		target = v;
		startTime = nowMillis;
		duration = Math.max(1L, millis);
		animating = true;
		continuous = false;
	}

	/** Set continuous-lerp mode: approach {@code v} asymptotically. */
	public void target(float v) {
		target = v;
		continuous = true;
		animating = false;
	}

	/** Set the continuous-lerp speed (0-1; higher = snappier). */
	public void speed(float s) {
		this.speed = Math.max(0.001f, Math.min(1f, s));
	}

	/** Advance the animation. {@code nowMillis} is the current clock time. */
	public void update(long nowMillis) {
		if (continuous) {
			value += (target - value) * speed;
			if (Math.abs(value - target) < 0.001f) {
				value = target;
				continuous = false;
			}
			return;
		}
		if (!animating) return;
		float t = (nowMillis - startTime) / (float) duration;
		if (t >= 1f) {
			value = target;
			animating = false;
		} else {
			value = start + (target - start) * ease.apply(t);
		}
	}

	/** Advance using {@link System#currentTimeMillis} as the clock. */
	public void update() {
		update(System.currentTimeMillis());
	}
}
