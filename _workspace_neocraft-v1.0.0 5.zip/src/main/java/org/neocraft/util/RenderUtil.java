package org.neocraft.util;

import org.neocraft.api.GameRenderer;
import org.neocraft.theme.Theme;

/**
 * Higher-level render helpers built on top of {@link GameRenderer}.
 *
 * <p>These compose the primitive draw calls into reusable widgets: glow
 * halos, rounded progress bars, and gradient buttons \u2014 the visual building
 * blocks of the NeoCraft GUI.
 *
 * @author NeoCraft
 */
public final class RenderUtil {

	private final GameRenderer r;

	public RenderUtil(GameRenderer renderer) {
		this.r = renderer;
	}

	/**
	 * Draw a soft glow halo around a rectangle by stacking translucent rounded
	 * rectangles of increasing size. Cheap fake-bloom for highlights.
	 */
	public void glow(double x, double y, double w, double h, int color, int layers) {
		for (int i = layers; i > 0; i--) {
			double expand = i * 1.5;
			int alpha = (int) (40 * (1.0 - (i / (double) layers)));
			if (alpha < 4) continue;
			int c = Theme.withAlpha(color, alpha);
			r.drawRoundedRect(x - expand, y - expand, w + expand * 2, h + expand * 2, 6 + expand, c);
		}
	}

	/** Rounded progress bar (0..1) with a track and a filled portion. */
	public void progressBar(double x, double y, double w, double h, double progress, int fillColor, int trackColor) {
		progress = Math.max(0, Math.min(1, progress));
		r.drawRoundedRect(x, y, w, h, h / 2.0, trackColor);
		if (progress > 0) {
			r.drawRoundedRect(x, y, w * progress, h, h / 2.0, fillColor);
		}
	}

	/** Rounded button background: a vertical gradient from top to bottom. */
	public void roundedButton(double x, double y, double w, double h, int top, int bottom) {
		r.drawRoundedRect(x, y, w, h, h / 2.0, Theme.withAlpha(top, 0xFF));
		// overlay a subtle gradient for depth
		r.drawGradientRect(x, y, w, h, Theme.withAlpha(top, 0xFF), Theme.withAlpha(bottom, 0xFF));
		r.drawHollowRect(x, y, w, h, 1.0f, Theme.liveBorder());
	}

	/** A horizontal divider line. */
	public void divider(double x, double y, double w, int color) {
		r.drawRect(x, y, w, 1, color);
	}

	/** Inset shadow (top edge darker) for a recessed panel. */
	public void insetTop(double x, double y, double w, int color) {
		r.drawRect(x, y, w, 1, color);
	}
}
