package org.neocraft.util;

/**
 * Easing functions for smooth, natural animations.
 *
 * <p>All functions map a linear progress {@code t} in [0,1] to an eased
 * progress, also in [0,1] (overshooting easings may briefly exceed 1). These
 * are pure math with no allocations, safe for the render hot path.
 *
 * @author NeoCraft
 */
public final class Easing {

	private Easing() {}

	/** Linear (no easing). */
	public static float linear(float t) {
		return clamp01(t);
	}

	/** Quadratic ease-in. */
	public static float easeIn(float t) {
		t = clamp01(t);
		return t * t;
	}

	/** Quadratic ease-out. */
	public static float easeOut(float t) {
		t = clamp01(t);
		return 1 - (1 - t) * (1 - t);
	}

	/** Quadratic ease-in-out. */
	public static float easeInOut(float t) {
		t = clamp01(t);
		return t < 0.5f ? 2 * t * t : 1 - (float) Math.pow(-2 * t + 2, 2) / 2;
	}

	/** Cubic ease-in-out. */
	public static float easeInOutCubic(float t) {
		t = clamp01(t);
		return t < 0.5f ? 4 * t * t * t : 1 - (float) Math.pow(-2 * t + 2, 3) / 2;
	}

	/** Exponential ease-out \u2014 fast start, slow finish. Great for fade-ins. */
	public static float easeOutExpo(float t) {
		t = clamp01(t);
		return t >= 1f ? 1f : 1f - (float) Math.pow(2, -10 * t);
	}

	/** Exponential ease-in \u2014 slow start, fast finish. */
	public static float easeInExpo(float t) {
		t = clamp01(t);
		return t <= 0f ? 0f : (float) Math.pow(2, 10 * t - 10);
	}

	/** Back ease-out \u2014 overshoots slightly then settles. Playful for pop-ins. */
	public static float easeOutBack(float t) {
		t = clamp01(t);
		final float c1 = 1.70158f;
		final float c3 = c1 + 1;
		return 1 + c3 * (float) Math.pow(t - 1, 3) + c1 * (float) Math.pow(t - 1, 2);
	}

	/** Elastic ease-out \u2014 bounces around the target. */
	public static float easeOutElastic(float t) {
		t = clamp01(t);
		if (t <= 0f) return 0f;
		if (t >= 1f) return 1f;
		final float c4 = (2f * (float) Math.PI) / 3f;
		return (float) Math.pow(2, -10 * t) * (float) Math.sin((t * 10 - 0.75f) * c4) + 1f;
	}

	private static float clamp01(float t) {
		return t < 0f ? 0f : (t > 1f ? 1f : t);
	}
}
