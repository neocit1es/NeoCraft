package org.neocraft.util;

import org.neocraft.api.ConfigStore;
import org.neocraft.client.Brand;

/**
 * Manages the built-in NeoCraft PvP resource pack. The pack ships inside the
 * client JAR (under {@code /neocraft/assets/neocraft/}) and provides quality-of-
 * life PvP tweaks: reduced fire overlay height, cleaner GUI container
 * backgrounds, lower-opacity particle textures, and simplified crosshair.
 *
 * <p>The pack can be toggled on or off from the settings screen. When enabled,
 * the integration bridge injects it into Minecraft's resource pack list as the
 * highest-priority pack so it overrides vanilla assets without replacing the
 * user's chosen main pack.
 *
 * @author NeoCraft
 */
public final class ResourcePackManager {

	private static final String PACK_ID = "neocraft_pvp";
	private static final String ENABLED_KEY = "resourcepack.enabled";
	private static final String PACK_PATH = "/neocraft/assets/neocraft/";

	private final ConfigStore config;
	private boolean enabled;

	public ResourcePackManager(ConfigStore config) {
		this.config = config;
		this.enabled = config.getBoolean(ENABLED_KEY, true);
	}

	/** Whether the built-in PvP pack is active. */
	public boolean isEnabled() {
		return enabled;
	}

	/** Enable or disable the pack. Persists immediately. */
	public void setEnabled(boolean enabled) {
		this.enabled = enabled;
		config.setBoolean(ENABLED_KEY, enabled);
		config.save();
	}

	/** Toggle the pack on/off. Returns the new state. */
	public boolean toggle() {
		setEnabled(!enabled);
		return enabled;
	}

	/** The internal pack identifier. */
	public String packId() {
		return PACK_ID;
	}

	/** The classpath-relative path to the pack root. */
	public String packPath() {
		return PACK_PATH;
	}

	/** Human-readable pack name for the settings screen. */
	public String packName() {
		return Brand.NAME + " PvP Pack";
	}

	/** Pack description. */
	public String packDescription() {
		return "Low-fire overlay, clean GUI, reduced particles, simplified crosshair.";
	}

	/** Persist state into the given root config (called on shutdown). */
	public void saveState(ConfigStore root) {
		root.setBoolean(ENABLED_KEY, enabled);
	}

	/** Load state from the given root config (called on startup). */
	public void loadState(ConfigStore root) {
		this.enabled = root.getBoolean(ENABLED_KEY, true);
	}
}
