package org.neocraft.util;

import org.neocraft.api.GameRenderer;
import org.neocraft.api.MinecraftAdapter;
import org.neocraft.theme.Theme;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Lightweight floating-particle field used behind the main menu and other
 * full-screen GUIs for visual depth.
 *
 * <p>Particles drift upward with a slight horizontal sway, wrap around the
 * screen edges, and fade in and out. The system is allocation-light: particles
 * are pooled and updated in place.
 *
 * @author NeoCraft
 */
public final class ParticleField {

	private static final class Particle {
		double x, y;
		double vx, vy;
		float size;
		float alpha;
		float alphaTarget;
		int color;
	}

	private final MinecraftAdapter adapter;
	private final List<Particle> particles = new ArrayList<>();
	private final Random random = new Random();
	private final int count;
	private final double speed;
	private int lastW;
	private int lastH;

	/**
	 * @param adapter the game adapter (for screen size + renderer)
	 * @param count   number of particles
	 * @param speed   drift speed multiplier
	 */
	public ParticleField(MinecraftAdapter adapter, int count, double speed) {
		this.adapter = adapter;
		this.count = count;
		this.speed = speed;
	}

	private void init(int w, int h) {
		particles.clear();
		for (int i = 0; i < count; i++) {
			Particle p = new Particle();
			p.x = random.nextDouble() * w;
			p.y = random.nextDouble() * h;
			p.vx = (random.nextDouble() - 0.5) * 0.3 * speed;
			p.vy = -(random.nextDouble() * 0.4 + 0.15) * speed;
			p.size = (random.nextFloat() * 2.0f + 0.8f);
			p.alpha = random.nextFloat() * 0.5f;
			p.alphaTarget = random.nextFloat() * 0.6f + 0.2f;
			p.color = random.nextBoolean() ? Theme.livePrimary() : Theme.liveSecondary();
			particles.add(p);
		}
		lastW = w;
		lastH = h;
	}

	/** Update and render the particle field. Call each frame. */
	public void render(float partialTicks) {
		int w = adapter.getScaledWidth();
		int h = adapter.getScaledHeight();
		if (particles.isEmpty() || w != lastW || h != lastH) {
			init(w, h);
		}
		GameRenderer r = adapter.renderer();
		for (Particle p : particles) {
			p.x += p.vx;
			p.y += p.vy;
			// sway
			p.vx += (random.nextDouble() - 0.5) * 0.02;
			// fade toward target, occasionally flip
			p.alpha += (p.alphaTarget - p.alpha) * 0.02f;
			if (random.nextDouble() < 0.005) p.alphaTarget = random.nextFloat() * 0.6f + 0.1f;
			// wrap
			if (p.y < -10) { p.y = h + 10; p.x = random.nextDouble() * w; }
			if (p.x < -10) p.x = w + 10;
			if (p.x > w + 10) p.x = -10;
			float a = Math.max(0f, Math.min(1f, p.alpha));
			r.drawParticle(p.x, p.y, p.size, p.color, a);
		}
	}

	/** Number of active particles. */
	public int count() {
		return particles.size();
	}
}
