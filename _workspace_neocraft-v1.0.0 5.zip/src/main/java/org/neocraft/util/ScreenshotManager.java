package org.neocraft.util;

import org.neocraft.api.MinecraftAdapter;
import org.neocraft.client.Brand;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Screenshot manager — wraps the adapter's screenshot capability, keeps a
 * recent list, and notifies the user via the notification system.
 *
 * @author NeoCraft
 */
public final class ScreenshotManager {

	private final MinecraftAdapter adapter;
	private final List<String> recent = new ArrayList<>();
	private static final int MAX_RECENT = 24;

	public ScreenshotManager(MinecraftAdapter adapter) {
		this.adapter = adapter;
	}

	/** Take a screenshot and record it. Returns the file name or null on failure. */
	public String capture() {
		String name = adapter.takeScreenshot();
		if (name != null) {
			recent.add(0, name);
			while (recent.size() > MAX_RECENT) recent.remove(recent.size() - 1);
		}
		return name;
	}

	public List<String> recent() { return Collections.unmodifiableList(recent); }

	/** Prefix used for NeoCraft screenshot file names. */
	public static String prefix() { return Brand.NAMESPACE; }
}
