package org.neocraft.util;

import org.neocraft.api.FontRenderer;
import org.neocraft.api.GameRenderer;
import org.neocraft.theme.Theme;

/**
 * Reusable helper for drawing the rounded translucent "glass" panels that every
 * NeoCraft HUD element and GUI widget uses.
 *
 * <p>Centralising the panel style here keeps the look consistent across the
 * whole client and means a style change is a one-line edit.
 *
 * @author NeoCraft
 */
public final class PanelRenderer {

	private final GameRenderer renderer;
	private final FontRenderer fonts;

	public PanelRenderer(GameRenderer renderer, FontRenderer fonts) {
		this.renderer = renderer;
		this.fonts = fonts;
	}

	public GameRenderer renderer() { return renderer; }
	public FontRenderer fonts() { return fonts; }

	/** Draw a filled rounded translucent panel with a soft border. */
	public void panel(double x, double y, double width, double height) {
		panel(x, y, width, height, 6.0);
	}

	public void panel(double x, double y, double width, double height, double radius) {
		renderer.drawRoundedRect(x, y, width, height, radius, Theme.liveGlassPanel());
		renderer.drawHollowRect(x, y, width, height, 1.0f, Theme.liveBorder());
	}

	/** Blurred glass panel (background blur + tint + border). */
	public void glass(double x, double y, double width, double height) {
		renderer.drawBlur(x, y, width, height, 6.0f);
		renderer.drawRoundedRect(x, y, width, height, 6.0, Theme.withAlpha(Theme.liveBackground(), 0x80));
		renderer.drawHollowRect(x, y, width, height, 1.0f, Theme.liveBorder());
	}

	/** Just an outline. */
	public void outline(double x, double y, double width, double height, int color) {
		renderer.drawHollowRect(x, y, width, height, 1.0f, color);
	}

	/** A small accent dot (used in toggles/HUD). */
	public void dot(double x, double y, double radius, int color) {
		renderer.drawCircle(x, y, radius, color);
	}

	/** Labeled text line inside a panel, vertically centered. */
	public void labeledLine(double x, double y, double width, String label, String value, int labelColor, int valueColor) {
		fonts().draw(label, x + 6, y + 4, labelColor);
		fonts().drawRight(value, x + width - 6, y + 4, valueColor);
	}
}
