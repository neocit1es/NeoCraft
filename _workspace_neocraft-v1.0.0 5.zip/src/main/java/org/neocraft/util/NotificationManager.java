package org.neocraft.util;

import org.neocraft.api.MinecraftAdapter;
import org.neocraft.theme.Theme;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * Toast-style notification system. Notifications slide in from the top-right,
 * auto-dismiss after a timeout, and render as rounded translucent panels with a
 * severity-coloured left bar.
 *
 * <p>Time is sourced from the adapter's clock so auto-dismiss behaviour is
 * deterministic in tests.
 *
 * @author NeoCraft
 */
public final class NotificationManager {

	public enum Severity { INFO, SUCCESS, WARNING, ERROR }

	private static final class Notification {
		final String title;
		final String message;
		final Severity severity;
		final long createdAt;
		final long duration;
		float anim; // 0 = off-screen, 1 = settled

		Notification(String title, String message, Severity severity, long duration, long now) {
			this.title = title;
			this.message = message;
			this.severity = severity;
			this.createdAt = now;
			this.duration = duration;
			this.anim = 0f;
		}
	}

	private final MinecraftAdapter adapter;
	private final List<Notification> active = new CopyOnWriteArrayList<>();

	public NotificationManager(MinecraftAdapter adapter) {
		this.adapter = adapter;
	}

	public void info(String title, String message) { post(title, message, Severity.INFO, 3000); }
	public void success(String title, String message) { post(title, message, Severity.SUCCESS, 3000); }
	public void warning(String title, String message) { post(title, message, Severity.WARNING, 4000); }
	public void error(String title, String message) { post(title, message, Severity.ERROR, 5000); }

	public void post(String title, String message, Severity severity, long durationMillis) {
		active.add(new Notification(title, message, severity, durationMillis, adapter.currentTimeMillis()));
	}

	/** Render and age notifications. Called each 2D frame. */
	public void render(float partialTicks) {
		long now = adapter.currentTimeMillis();
		double x = adapter.getScaledWidth() - 4;
		double y = 4;
		double width = 200;
		double height = 34;

		List<Notification> toRemove = new ArrayList<>();
		for (Notification n : active) {
			long age = now - n.createdAt;
			if (age > n.duration) {
				n.anim = Math.max(0f, n.anim - 0.1f);
				if (n.anim <= 0.01f) toRemove.add(n);
			} else {
				n.anim = Math.min(1f, n.anim + 0.1f);
			}
			int color = severityColor(n.severity);
			double slide = (1f - n.anim) * (width + 10);
			double nx = x + slide;
			// panel
			adapter.renderer().drawRoundedRect(nx - width, y, width, height, 6, Theme.liveGlassPanel());
			// accent bar
			adapter.renderer().drawRect(nx - width, y, 3, height, color);
			adapter.renderer().drawHollowRect(nx - width, y, width, height, 1.0f, Theme.liveBorder());
			adapter.fonts().draw(n.title, nx - width + 10, y + 6, color);
			adapter.fonts().draw(n.message, nx - width + 10, y + 18, Theme.liveTextDim());
			y += height + 4;
		}
		active.removeAll(toRemove);
	}

	private int severityColor(Severity s) {
		switch (s) {
			case SUCCESS: return Theme.liveSuccess();
			case WARNING: return Theme.liveWarning();
			case ERROR:   return Theme.liveError();
			default:      return Theme.livePrimary();
		}
	}

	public int activeCount() { return active.size(); }

	/** Remove all active notifications (used on shutdown / reset). */
	public void clear() { active.clear(); }
}
