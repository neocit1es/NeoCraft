package org.neocraft.util;

import org.neocraft.api.FontRenderer;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Caches {@link FontRenderer} measurements so hot-path GUI code (which measures
 * the same strings every frame) does not recompute widths repeatedly.
 *
 * <p>Uses a small LRU cache to bound memory. Thread-safe via synchronisation on
 * the cache map.
 *
 * @author NeoCraft
 */
public final class TextCache {

	private static final int MAX_ENTRIES = 512;

	private final FontRenderer fonts;
	private final Map<String, Integer> widthCache = new LinkedHashMap<String, Integer>(64, 0.75f, true) {
		@Override
		protected boolean removeEldestEntry(Map.Entry<String, Integer> eldest) {
			return size() > MAX_ENTRIES;
		}
	};

	public TextCache(FontRenderer fonts) {
		this.fonts = fonts;
	}

	/** Cached string width. */
	public synchronized int width(String text) {
		if (text == null) return 0;
		Integer cached = widthCache.get(text);
		if (cached != null) return cached;
		int w = fonts.stringWidth(text);
		widthCache.put(text, w);
		return w;
	}

	/** Truncate {@code text} with an ellipsis so it fits within {@code maxWidth}. */
	public synchronized String truncate(String text, int maxWidth) {
		if (text == null || width(text) <= maxWidth) return text;
		String ellipsis = "\u2026";
		int ellW = width(ellipsis);
		StringBuilder sb = new StringBuilder(text);
		while (sb.length() > 1 && width(sb.toString()) + ellW > maxWidth) {
			sb.deleteCharAt(sb.length() - 1);
		}
		return sb.append(ellipsis).toString();
	}

	/** Wrap {@code text} to {@code maxWidth} lines (delegates to the font). */
	public List<String> wrap(String text, int maxWidth) {
		return fonts.splitToWidth(text, maxWidth);
	}

	/** Clear the cache. */
	public synchronized void clear() {
		widthCache.clear();
	}

	/** Current cache size (testing). */
	public synchronized int size() {
		return widthCache.size();
	}
}
