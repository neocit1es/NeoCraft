package org.neocraft.util;

import org.neocraft.api.ConfigStore;
import org.neocraft.api.MinecraftAdapter;
import org.neocraft.client.Brand;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/**
 * Profile manager — named, switchable configurations. Each profile is an
 * isolated {@link ConfigStore} namespace holding module/HUD/theme state.
 *
 * @author NeoCraft
 */
public final class Profiles {

	private static final String REGISTRY_KEY = "profiles.list";
	private static final String ACTIVE_KEY = "profiles.active";

	private final MinecraftAdapter adapter;
	private String active;
	private ConfigStore activeStoreCache;
	private String cachedFor;

	public Profiles(MinecraftAdapter adapter) {
		this.adapter = adapter;
	}

	/** All known profile names, with the built-in default first. */
	public List<String> list() {
		Set<String> names = new LinkedHashSet<>();
		names.add("Default");
		String raw = adapter.config().get(REGISTRY_KEY, "");
		if (raw != null && !raw.isEmpty()) {
			for (String n : raw.split("\\|")) {
				if (!n.isEmpty()) names.add(n);
			}
		}
		return new ArrayList<>(names);
	}

	public String active() {
		return active == null ? "Default" : active;
	}

	/** Create a new profile. Returns false if it already exists. */
	public boolean create(String name) {
		List<String> names = list();
		if (names.contains(name)) return false;
		names.add(name);
		adapter.config().set(REGISTRY_KEY, join(names));
		adapter.config().save();
		return true;
	}

	/** Delete a profile (cannot delete Default). */
	public boolean delete(String name) {
		if ("Default".equalsIgnoreCase(name)) return false;
		List<String> names = list();
		if (!names.remove(name)) return false;
		adapter.config().set(REGISTRY_KEY, join(names));
		if (name.equals(active)) active = "Default";
		adapter.config().save();
		return true;
	}

	/** Switch the active profile. */
	public void switchTo(String name) {
		if (!list().contains(name)) return;
		this.active = name;
		this.activeStoreCache = null;
		this.cachedFor = null;
		adapter.config().set(ACTIVE_KEY, name);
		adapter.config().save();
	}

	/** Namespace for the active profile. Cached per active name. */
	public ConfigStore activeStore() {
		String name = active();
		if (activeStoreCache == null || !name.equals(cachedFor)) {
			activeStoreCache = adapter.config().namespace("profile." + name);
			cachedFor = name;
		}
		return activeStoreCache;
	}

	public void saveState(ConfigStore root) {
		root.set(ACTIVE_KEY, active());
		root.set(REGISTRY_KEY, join(list()));
	}

	public void loadState(ConfigStore root) {
		this.active = root.get(ACTIVE_KEY, "Default");
		root.set(REGISTRY_KEY, join(list()));
	}

	private String join(List<String> names) {
		return String.join("|", names);
	}

	public String brand() { return Brand.FULL_BRAND; }
}
