package org.neocraft.adapter;

import org.neocraft.api.GameRenderer;

/**
 * Stub renderer that records draw calls (used by unit tests to assert layout).
 */
public final class StubRenderer implements GameRenderer {

	private float globalAlpha = 1.0f;
	private int color = 0xFFFFFFFF;
	private int blendDepth = 0;
	private boolean scissor = false;
	private int drawCount = 0;

	public int getDrawCount() { return drawCount; }
	public void resetCount() { drawCount = 0; }
	public boolean isScissorActive() { return scissor; }
	public int getBlendDepth() { return blendDepth; }

	@Override public void drawRect(double x, double y, double w, double h, int argb) { drawCount++; }
	@Override public void drawRoundedRect(double x, double y, double w, double h, double radius, int argb) { drawCount++; }
	@Override public void drawHollowRect(double x, double y, double w, double h, float lw, int argb) { drawCount++; }
	@Override public void drawGradientRect(double x, double y, double w, double h, int top, int bottom) { drawCount++; }
	@Override public void drawHorizontalGradient(double x, double y, double w, double h, int left, int right) { drawCount++; }
	@Override public void drawLine(double x1, double y1, double x2, double y2, float lw, int argb) { drawCount++; }
	@Override public void drawCircle(double cx, double cy, double r, int argb) { drawCount++; }
	@Override public void drawBlur(double x, double y, double w, double h, float strength) { drawCount++; }
	@Override public void drawParticle(double x, double y, double size, int argb, float alpha) { drawCount++; }
	@Override public void enableScissor(double x, double y, double w, double h) { scissor = true; drawCount++; }
	@Override public void disableScissor() { scissor = false; }
	@Override public void pushBlend() { blendDepth++; }
	@Override public void popBlend() { if (blendDepth > 0) blendDepth--; }
	@Override public void setGlobalAlpha(float alpha) { this.globalAlpha = Math.max(0f, Math.min(1f, alpha)); }
	@Override public float getGlobalAlpha() { return globalAlpha; }
	@Override public void setColor(int argb) { this.color = argb; }
}
