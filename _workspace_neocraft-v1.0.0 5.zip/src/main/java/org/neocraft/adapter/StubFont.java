package org.neocraft.adapter;

import org.neocraft.api.FontRenderer;

import java.util.ArrayList;
import java.util.List;

/**
 * Deterministic stub font that estimates widths from character count so GUI
 * layout math is testable without the real Minecraft font renderer.
 */
public final class StubFont implements FontRenderer {

	private static final int CHAR_W = 6;
	private static final int HEIGHT = 9;

	@Override
	public void drawString(String text, double x, double y, int argb, boolean shadow) {
		// no-op in stub
	}

	@Override
	public int stringWidth(String text) {
		if (text == null || text.isEmpty()) return 0;
		int w = 0;
		for (int i = 0; i < text.length(); i++) {
			w += CHAR_W;
		}
		return w;
	}

	@Override
	public int fontHeight() {
		return HEIGHT;
	}

	@Override
	public List<String> splitToWidth(String text, int maxWidth) {
		List<String> out = new ArrayList<>();
		if (text == null || text.isEmpty()) {
			out.add("");
			return out;
		}
		StringBuilder line = new StringBuilder();
		for (String word : text.split(" ")) {
			String candidate = line.length() == 0 ? word : line + " " + word;
			if (stringWidth(candidate) > maxWidth && line.length() > 0) {
				out.add(line.toString());
				line = new StringBuilder(word);
			} else {
				line = new StringBuilder(candidate);
			}
		}
		if (line.length() > 0) out.add(line.toString());
		return out;
	}
}
