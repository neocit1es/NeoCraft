package org.neocraft.adapter;

import org.neocraft.api.ConfigStore;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * In-memory stub {@link ConfigStore} for unit testing profiles and persistence.
 *
 * <p>Namespaces layer on top of their parent: a child stores its own keys and
 * falls back to the parent for any key it does not own, while the parent never
 * sees the child's keys. This mirrors how NeoCraft profiles stack overrides.
 */
public final class StubConfig implements ConfigStore {

	private final StubConfig parent;
	private final Map<String, String> data = new LinkedHashMap<>();

	public StubConfig() {
		this(null);
	}

	private StubConfig(StubConfig parent) {
		this.parent = parent;
	}

	@Override public void set(String key, String value) {
		if (value == null) data.remove(key); else data.put(key, value);
	}

	@Override public String get(String key, String defaultValue) {
		if (data.containsKey(key)) return data.get(key);
		if (parent != null) return parent.get(key, defaultValue);
		return defaultValue;
	}

	@Override public void setInt(String key, int value) { set(key, Integer.toString(value)); }
	@Override public int getInt(String key, int defaultValue) {
		String v = get(key, null);
		if (v == null) return defaultValue;
		try { return Integer.parseInt(v); } catch (NumberFormatException e) { return defaultValue; }
	}
	@Override public void setDouble(String key, double value) { set(key, Double.toString(value)); }
	@Override public double getDouble(String key, double defaultValue) {
		String v = get(key, null);
		if (v == null) return defaultValue;
		try { return Double.parseDouble(v); } catch (NumberFormatException e) { return defaultValue; }
	}
	@Override public void setBoolean(String key, boolean value) { set(key, Boolean.toString(value)); }
	@Override public boolean getBoolean(String key, boolean defaultValue) {
		String v = get(key, null);
		if (v == null) return defaultValue;
		return Boolean.parseBoolean(v);
	}
	@Override public void remove(String key) { data.remove(key); }
	@Override public void save() { /* in-memory */ }
	@Override public void reload() { /* in-memory */ }
	@Override public ConfigStore namespace(String name) { return new StubConfig(this); }

	/** Test helper: number of keys owned directly by this store. */
	public int size() { return data.size(); }
}
