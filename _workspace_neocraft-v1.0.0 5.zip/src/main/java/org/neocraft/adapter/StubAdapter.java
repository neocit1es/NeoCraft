package org.neocraft.adapter;

import org.neocraft.api.ConfigStore;
import org.neocraft.api.FontRenderer;
import org.neocraft.api.GameRenderer;
import org.neocraft.api.MinecraftAdapter;

/**
 * Self-contained stub implementation of {@link MinecraftAdapter} used so the
 * NeoCraft core compiles and unit-tests in any environment without the
 * proprietary Minecraft runtime.
 *
 * <p>This is <em>not</em> shipped to end users. The real wiring is
 * {@code org.neocraft.adapter.McpAdapter} in {@code /integration}.
 *
 * @author NeoCraft
 */
public final class StubAdapter implements MinecraftAdapter {

	private final StubRenderer renderer = new StubRenderer();
	private final StubFont fonts = new StubFont();
	private final StubConfig config = new StubConfig();

	private long time = 0L;
	private int fps = 120;
	private int ping = 20;
	private int leftCps = 0;
	private int rightCps = 0;
	private int mouseX = 0;
	private int mouseY = 0;
	private int scaledW = 854;
	private int scaledH = 480;
	private boolean[] keys = new boolean[256];
	private boolean mouseLeft;
	private boolean mouseRight;
	private boolean inGame = true;
	private boolean inWorld = true;
	private double px = 128.5, py = 70.0, pz = -312.5;
	private float health = 20f;
	private float maxHealth = 20f;
	private int food = 20;
	private int armor = 0;
	private double reach = 3.0;
	private float gamma = 0.5f;
	private float fov = 0f;
	private boolean sprinting = false;
	private boolean sneaking = false;
	private double moveSpeed = 0.0;

	/** Advance the stub clock by {@code millis}. */
	public void advance(long millis) {
		this.time += millis;
	}

	public void setFps(int fps) { this.fps = fps; }
	public void setPing(int ping) { this.ping = ping; }
	public void setLeftCps(int cps) { this.leftCps = cps; }
	public void setRightCps(int cps) { this.rightCps = cps; }
	public void setMouse(int x, int y) { this.mouseX = x; this.mouseY = y; }
	public void setScaledSize(int w, int h) { this.scaledW = w; this.scaledH = h; }
	public void setKey(int code, boolean down) { if (code >= 0 && code < keys.length) keys[code] = down; }
	public void setMouseLeft(boolean down) { this.mouseLeft = down; }
	public void setMouseRight(boolean down) { this.mouseRight = down; }
	public void setPlayer(double x, double y, double z) { this.px = x; this.py = y; this.pz = z; }
	public void setInGame(boolean v) { this.inGame = v; }
	public void setInWorld(boolean v) { this.inWorld = v; }
	public void setHealth(float v) { this.health = v; }
	public void setMaxHealth(float v) { this.maxHealth = v; }
	public void setFood(int v) { this.food = v; }
	public void setArmor(int v) { this.armor = v; }
	public void setReach(double v) { this.reach = v; }
	public void setSneaking(boolean v) { this.sneaking = v; }
	public void setMoveSpeed(double v) { this.moveSpeed = v; }
	public StubConfig rawConfig() { return config; }

	@Override public String getClientBrand() { return "NeoCraft v1.0.0"; }
	@Override public String getMinecraftVersion() { return "Minecraft 1.12.2"; }
	@Override public long currentTimeMillis() { return time; }
	@Override public float getPartialTicks() { return (time % 50L) / 50.0f; }
	@Override public int getFps() { return fps; }
	@Override public boolean isKeyDown(int keyCode) { return keyCode >= 0 && keyCode < keys.length && keys[keyCode]; }
	@Override public boolean isMouseLeftDown() { return mouseLeft; }
	@Override public boolean isMouseRightDown() { return mouseRight; }
	@Override public int getMouseX() { return mouseX; }
	@Override public int getMouseY() { return mouseY; }
	@Override public int getScaledWidth() { return scaledW; }
	@Override public int getScaledHeight() { return scaledH; }
	@Override public boolean isInGame() { return inGame; }
	@Override public boolean isInWorld() { return inWorld; }
	@Override public double getPlayerX() { return px; }
	@Override public double getPlayerY() { return py; }
	@Override public double getPlayerZ() { return pz; }
	@Override public int getPing() { return ping; }
	@Override public int getLeftClickCps() { return leftCps; }
	@Override public int getRightClickCps() { return rightCps; }
	@Override public float getFrameDelta() { return 0.05f; }
	@Override public GameRenderer renderer() { return renderer; }
	@Override public FontRenderer fonts() { return fonts; }
	@Override public void enableGuiMatrix() { renderer.pushBlend(); }
	@Override public void disableGuiMatrix() { renderer.popBlend(); }
	@Override public ConfigStore config() { return config; }
	@Override public float getHealth() { return health; }
	@Override public float getMaxHealth() { return maxHealth; }
	@Override public int getFood() { return food; }
	@Override public int getArmor() { return armor; }
	@Override public double getReach() { return reach; }
	@Override public float getGamma() { return gamma; }
	@Override public void setGamma(float gamma) { this.gamma = gamma; }
	@Override public float getFov() { return fov; }
	@Override public void setFov(float fov) { this.fov = fov; }
	@Override public boolean isSprinting() { return sprinting; }
	@Override public void setSprinting(boolean sprinting) { this.sprinting = sprinting; }
	@Override public boolean isSneaking() { return sneaking; }
	@Override public double getMoveSpeed() { return moveSpeed; }
	@Override public String takeScreenshot() { return "neocraft_" + time + ".png"; }
}
