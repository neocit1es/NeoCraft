# NeoCraft

**NeoCraft** is a modern, original PvP client layer for **Minecraft 1.12.2** (Eaglercraft-compatible), built around a clean adapter architecture. The entire client — branding, theming, module framework, HUD, GUI, animations, profiles, notifications, and a built-in PvP resource pack — is written as portable, MIT-licensed Java that contains **zero** proprietary Minecraft code. It compiles and fully unit-tests in any standard JDK 17 environment, then drops into your own 1.12.2 workspace through a thin integration bridge.

> *"The future of PvP."*

NeoCraft was inspired by the feature set of the Tuff Network's Eaglercraft PvP client (TuffClient) and the open-source TuffXPlus server plugin. It is, however, a **completely separate and original** codebase: no TuffClient binaries or decompiled code are included, and no TuffXPlus plugin code is distributed. Full attribution is preserved in the [LICENSE](LICENSE) and on the in-game credits screen.

---

## Table of Contents

- [Highlights](#highlights)
- [Architecture](#architecture)
- [Feature Catalogue](#feature-catalogue)
- [Project Structure](#project-structure)
- [Building](#building)
- [Testing](#testing)
- [Integrating into Minecraft 1.12.2](#integrating-into-minecraft-1122)
- [Configuration & Profiles](#configuration--profiles)
- [Theming](#theming)
- [License](#license)

---

## Highlights

- **Original, MIT-licensed source.** The NeoCraft core never imports `net.minecraft.*`. All game interaction flows through a single `MinecraftAdapter` interface, so the project is clean-room and free of proprietary dependencies.
- **Compiles and tests anywhere.** A self-contained `StubAdapter` lets the entire client build and run its 87-test suite in a plain JDK 17 sandbox — no Minecraft jars required.
- **One-file integration.** Ship the core jar plus the MCP bridge (`McpAdapter`) into your Eaglercraft 1.12.2 workspace and call `NeoCraft.init(new McpAdapter())`. See [INTEGRATION.md](INTEGRATION.md).
- **Tuff-style PvP modules.** Fullbright, Sprint, Zoom, Reach Display, Keystrokes, CPS, Coordinates, FPS, Ping, Armor HUD, Potion HUD, Clock, Session Stats, and a Notifications trigger — each with toggle, keybind, and configurable settings.
- **Modern GUI.** Redesigned main menu with glass logo panel and glow, animated loading screen with progress bar and cycling messages, a polished ClickGUI with category sidebar, scroll, search, favorites, and expandable per-module settings, plus a tabbed settings screen and a credits screen.
- **Centralized theme system.** Five built-in presets (NeoCraft Cyan, Amethyst, Emerald, Sunset, Crimson) with a live palette that swaps instantly. Custom presets can be installed at runtime.
- **Draggable HUD editor.** Nine HUD elements in translucent rounded panels, freely repositioned and clamped, with layout persisted per profile.
- **Profiles, notifications, screenshots.** Named switchable config namespaces, toast-style severity-colored notifications with auto-dismiss, and a screenshot manager with a 24-item recent list.
- **Deterministic and tested.** Animations and auto-dismiss use an adapter-provided clock (not `System.currentTimeMillis()`), so every GUI animation and notification lifecycle is unit-testable.
- **Zero-warning build.** The entire core compiles under `-Xlint:all -Werror` with no warnings.

---

## Architecture

NeoCraft follows an **adapter pattern** that cleanly separates portable logic from platform-specific wiring.

```
        ┌─────────────────────────────────────────────┐
        │              NeoCraft core                   │
        │  (client, gui, hud, modules, theme, render,  │
        │   events, util) — no net.minecraft imports   │
        └──────────────────┬──────────────────────────┘
                           │ talks only through
                           ▼
                ┌──────────────────────┐
                │   MinecraftAdapter    │  (interface)
                │   GameRenderer        │
                │   FontRenderer        │
                │   ConfigStore         │
                └─────┬────────────┬────┘
                      │            │
          ┌───────────▼──┐    ┌────▼──────────────┐
          │  StubAdapter │    │   McpAdapter       │
          │  (sandbox)   │    │   (1.12.2 bridge)  │
          └──────────────┘    └────────────────────┘
```

The `org.neocraft.api` package defines four interfaces — `MinecraftAdapter`, `GameRenderer`, `FontRenderer`, and `ConfigStore` — that together describe everything NeoCraft needs from the host game. The `org.neocraft.adapter` package provides `StubAdapter` (and `StubRenderer`, `StubFont`, `StubConfig`) for sandbox compilation and testing. The `integration` source set provides the real `McpAdapter` family, which is compiled only inside the user's 1.12.2 workspace where MCP-mapped classes are available.

This means the core jar (`NeoCraft-1.0.0-core.jar`) is fully portable and testable, while the integration jar (`NeoCraft-1.0.0-integration.jar`) is the thin glue you drop into your mod.

---

## Feature Catalogue

### Modules (16)

| Module | Category | Description |
|--------|----------|-------------|
| Fullbright | Render | Locks gamma to maximum for full night vision. |
| Sprint | Movement | Force-sprints while moving forward. |
| Zoom | Render | Reduces FOV for a scoped view; adjustable zoom level. |
| ReachDisplay | Render | Shows your current block/attack reach distance. |
| Keystrokes | HUD | WASD + mouse key overlay with CPS-aware coloring. |
| Cps | HUD | Left/right clicks-per-second counter. |
| Coordinates | HUD | Live XYZ coordinate readout. |
| Fps | HUD | Frames-per-second display. |
| Ping | HUD | Network latency in milliseconds. |
| Armor | HUD | Armor durability bar. |
| Potion | HUD | Active potion effects with durations. |
| Clock | HUD | Real-time clock. |
| SessionStats | HUD | Kill/death and session-time tracker. |
| HudToggle | System | Toggles the entire HUD overlay. |
| HudEditor | System | Opens the draggable HUD editor. |
| NotificationsTrigger | System | Fires toast notifications on configurable events (e.g. low health). |

Each module supports a keybind, a favorite flag, and typed settings (boolean, slider, mode, keybind). Modules are searchable, categorized, and persist their state per profile.

### GUI Screens

- **Main Menu** — Glass logo panel with brand glow, six rounded buttons (Singleplayer, Multiplayer, Mods, Settings, Credits, Quit), hover glow, gradient vignette, version footer, fade-in.
- **ClickGUI** — Category sidebar with icons, live search bar, scrollable module cards with expandable settings, favorite stars, keybind badges, animated sidebar slide-in.
- **Settings** — Three tabs (Theme, Profiles, General). Theme tab shows preset cards with colour swatches; Profiles tab manages create/switch/delete; General tab toggles notifications, screenshots, FPS HUD, and coordinates HUD. Includes a search bar.
- **Credits** — Brand glow, wrapped MIT license summary, attribution block preserving TuffXPlus and TuffClient credits, ESC to close.
- **Loading Screen** — Brand pulse glow, progress bar, cycling loading messages every 2.5 seconds, `setProgress`/`isDone`/`setMessage` API.

### HUD Elements (9)

Armor, Clock, Coordinates, CPS, FPS, Keystrokes, Ping, Potion, Session Stats — each rendered as a draggable, translucent rounded panel in the HUD editor.

### Systems

- **Notification system** — Toast-style, slide-in, severity-colored (info/success/warning/error), auto-dismiss using the adapter clock for deterministic testing.
- **Profiles** — Named switchable config namespaces via `ConfigStore.namespace("profile.<name>")`. The active store is cached per profile name and invalidated on switch. The default profile cannot be deleted.
- **Screenshot manager** — Captures via `adapter.takeScreenshot()`, maintains a most-recent-first list capped at 24 entries.
- **Theme registry** — Five built-in presets, live palette swap, save/load state, install custom presets, reset to defaults.
- **Resource pack manager** — Built-in PvP pack (low-fire, clean GUI, reduced particles), enabled by default, toggleable and persistent.
- **Event bus** — Annotation-driven (`@NeoSubscribe`), priority-ordered, cancellable. `EventBus.register()` walks the full class hierarchy to discover inherited subscribers.

---

## Project Structure

```
neocraft/
├── build.gradle                  # JDK 17, -Xlint:all -Werror, core + integration jars
├── settings.gradle
├── gradle.properties
├── LICENSE                       # MIT + attribution (TuffXPlus, TuffClient, Mojang)
├── README.md                     # This file
├── INTEGRATION.md                # Step-by-step 1.12.2 workspace wiring
├── CHANGELOG.md                  # Version history
├── todo.md                       # Build roadmap
│
├── src/main/java/org/neocraft/
│   ├── api/                      # MinecraftAdapter, GameRenderer, FontRenderer, ConfigStore
│   ├── adapter/                  # StubAdapter, StubRenderer, StubFont, StubConfig
│   ├── client/                   # NeoCraft (singleton), Brand, Log
│   ├── events/                   # EventBus, NeoEvent, @NeoSubscribe, Tick/Render/KeyInput events
│   ├── modules/                  # Module, Category, ModuleManager, Setting types
│   │   └── impl/                 # 16 module implementations
│   ├── theme/                    # Theme, ThemePreset, ThemeRegistry
│   ├── render/                   # (render utilities live in util/)
│   ├── hud/                      # HudElement, HudManager, TextHudElement
│   │   └── elements/             # 9 HUD elements
│   ├── gui/                      # Screen, ClickGui, MainMenu, SettingsScreen, CreditsScreen, LoadingScreen, widgets
│   └── util/                     # Animation, Easing, ParticleField, RenderUtil, PanelRenderer, TextCache,
│                                 #   NotificationManager, Profiles, ScreenshotManager, ResourcePackManager
│
├── src/main/resources/neocraft/
│   └── assets/neocraft/pack.mcmeta   # Built-in PvP resource pack metadata
│
├── src/test/java/org/neocraft/test/  # 7 test classes, 87 tests total
│
└── integration/org/neocraft/adapter/  # MCP bridge (compiled in 1.12.2 workspace only)
    ├── McpAdapter.java
    ├── McpRenderer.java
    ├── McpFont.java
    └── McpConfig.java
```

---

## Building

### Prerequisites

- **JDK 17** (the build targets `JavaVersion.VERSION_17`).
- **Gradle 8.5+** (a wrapper is not bundled; use a system Gradle or generate one with `gradle wrapper`).

### Build the core jar

```bash
cd neocraft
gradle build
```

This compiles the core against the stub, runs the full test suite, and produces:

- `build/libs/NeoCraft-1.0.0-core.jar` — the portable, dependency-free core.

### Build the integration jar

```bash
gradle integrationJar
```

This compiles the `/integration` source set (which depends on the core's output) and produces:

- `build/libs/NeoCraft-1.0.0-integration.jar` — the MCP bridge.

> The integration jar compiles in this sandbox because the bridge methods are currently stubs that throw `UnsupportedOperationException`. To make them functional, uncomment the MCP-mapped implementation hints inside each `Mcp*.java` file and compile inside your 1.12.2 workspace. See [INTEGRATION.md](INTEGRATION.md).

### Compile-only checks

```bash
gradle compileJava            # core only
gradle compileIntegrationJava # core + integration
```

---

## Testing

NeoCraft has **87 unit tests** across seven test classes, all passing under JDK 17:

| Test class | Tests | Coverage |
|------------|-------|----------|
| `AdapterStubTest` | 6 | Stub adapter behaviors and test helpers |
| `CoreSystemsTest` | 8 | NeoCraft singleton, event bus, branding |
| `ModulesTest` | 9 | Module registration, settings, keybinds, favorites, search |
| `RenderUtilTest` | 9 | Animation, easing, glow, progress bar, text cache |
| `HudEditorTest` | 6 | HUD drag/clamp/save and element lookup |
| `GuiTest` | 21 | Main menu, ClickGUI, settings, credits, loading, fade-in |
| `SystemsTest` | 28 | Notifications, profiles, screenshots, theme registry, integration |

```bash
gradle test --rerun-tasks
```

The tests use `StubAdapter` and `StubRenderer`, which expose helpers like `advance(long millis)`, `setScaledSize(w, h)`, `setHealth(float)`, `setPlayer(x, y, z)`, `setKey(int, boolean)`, and `StubRenderer.getDrawCount()` for deterministic assertions. Because animations and notifications use the adapter clock (`adapter.currentTimeMillis()`), every timing-dependent behavior is fully testable without real time.

---

## Integrating into Minecraft 1.12.2

The short version:

1. Build the core and integration jars (above).
2. In your Eaglercraft 1.12.2 workspace, add both jars to the classpath (or copy the source files into your `src/main/java` tree).
3. Uncomment the MCP-mapped implementation hints in `McpAdapter`, `McpRenderer`, `McpFont`, and `McpConfig`.
4. From your mod's init event handler, call:

```java
import org.neocraft.client.NeoCraft;
import org.neocraft.adapter.McpAdapter;

NeoCraft.init(new McpAdapter());
```

5. Route your render tick, input, and key events into `NeoCraft.get().events()`.

For the complete, annotated walkthrough — including event routing, CPS counter wiring, and HUD/ClickGUI open hooks — see **[INTEGRATION.md](INTEGRATION.md)**.

---

## Configuration & Profiles

NeoCraft persists all state through the `ConfigStore` interface. In the sandbox this is an in-memory stub; in 1.12.2 it maps to a `Properties` file at `.minecraft/neocraft/config.properties`.

**Profiles** are isolated namespaces (`profile.<name>.<key>`). You can create, switch to, and delete profiles from the Settings screen. The default profile (`default`) cannot be deleted. Deleting the active profile reverts to `default`. The active store is cached per profile name for performance and invalidated on switch.

Persisted state includes: module enabled/disabled flags, module settings, keybinds, favorites, HUD element positions, the active theme preset, the active profile, resource pack toggle, and general settings (notifications, screenshots, FPS/coordinates HUD).

---

## Theming

NeoCraft ships **five built-in theme presets**, all swappable live from the Settings → Theme tab:

| Preset | Primary | Secondary | Vibe |
|--------|---------|-----------|------|
| NeoCraft (Cyan) | `#00E5FF` | `#8B5CF6` | Default — cool cyan/purple |
| Amethyst | `#8B5CF6` | `#00E5FF` | Purple-led |
| Emerald | `#38D39F` | `#00E5FF` | Green-led |
| Sunset | `#F5B041` | `#EF4444` | Warm amber/red |
| Crimson | `#EF4444` | `#8B5CF6` | Red-led |

The shared background (`#0E1016`), panel (`#181C24`), and text (`#F5F7FA`) tones keep every preset coherent. Custom presets can be installed at runtime via `ThemeRegistry.get().install(preset)`, and the active selection persists across restarts.

---

## License

NeoCraft is released under the **MIT License**. See [LICENSE](LICENSE) for the full text.

Attribution is preserved for the projects that inspired NeoCraft:

- **TuffXPlus** (MIT License, © TuffNetwork) — the server-side Spigot plugin whose PvP design inspired NeoCraft's module concepts. NeoCraft does not distribute TuffXPlus code.
- **TuffClient** (Tuff Network) — the Eaglercraft PvP client whose feature set inspired NeoCraft's modules and HUD. NeoCraft re-implements equivalent functionality as original source code and includes no TuffClient binaries or decompiled code.
- **Minecraft 1.12.2** — © Mojang AB. NeoCraft is a mod layer intended for integration into a licensed/owned copy of the game and contains no Mojang assets.
