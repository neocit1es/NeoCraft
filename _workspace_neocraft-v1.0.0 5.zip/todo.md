# NeoCraft — Build Roadmap

Original, MIT-licensed PvP mod layer for Minecraft 1.12.2 (Eaglercraft-compatible).
Adapter pattern: core logic compiles here against a stub; real MCP bridge ships in /integration.

## Phase 0 — Foundation
- [x] Install JDK 17
- [x] Create project structure & git repo
- [x] Build system (build.gradle, settings.gradle, .gitignore, gradle props)
- [x] Adapter API layer (MinecraftAdapter + Game/Font/Config abstraction interfaces)
- [x] Stub implementation (compiles + tests here, -Xlint:all -Werror clean)
- [x] First compile of core + stub (Milestone 1 commit)

## Phase 1 — Branding & Theme
- [x] NeoCraft core/bootstrap (NeoCraft.java client class, config dir, version)
- [x] Centralized Theme class (exact palette)
- [x] Branding constants (version, name, credits w/ attribution)
- [x] Log banner / startup
- [x] Milestone 2 commit

## Phase 2 — Module Framework
- [x] Module base, Category, ModuleManager, settings (bool/slider/mode/keybind)
- [x] Event bus (NeoEvent, @NeoSubscribe, EventBus)
- [x] Module keybind manager
- [x] Milestone 3 commit

## Phase 3 — Modules (Tuff-style mods)
- [x] Fullbright, Sprint, Keystrokes, CPS, Coordinates, FPS, Ping
- [x] ArmorHUD, PotionHUD, Clock, ReachDisplay, SessionStats, NotificationsTrigger
- [x] Module favorites
- [x] Milestone 4 commit

## Phase 4 — Render & Theme utilities
- [x] Render utilities (rounded rects, blur, particles, glass panels, gradients)
- [x] Font rendering wrappers + caching
- [x] Animation system (eased values, smooth fades)
- [x] Milestone 5 commit

## Phase 5 — HUD system
- [x] HUDManager, HudElement base, HUD editor (drag/resize/save)
- [x] All HUD elements wired (rounded translucent panels)
- [x] Milestone 6 commit

## Phase 6 — GUI (Main Menu + ClickGUI)
- [x] Main menu redesign (rounded buttons, blur, particles, glass, fades, footer)
- [x] ClickGUI (rounded, blur, animations, scroll, search, icons, favorites, sliders/toggles)
- [x] Settings screen (searchable settings, theme selector)
- [x] Credits screen (with license attribution preserved)
- [x] Animated loading screen (brand, pulse glow, progress bar, cycling messages)
- [x] Milestone 7 commit

## Phase 7 — Systems
- [x] Notification system (toast lifecycle, severity colors, adapter-clock auto-dismiss)
- [x] Profiles (create/switch/delete, namespace isolation, cached activeStore)
- [x] Screenshot manager (capture, recent list, 24-item cap)
- [x] Theme selector + persistence (5 built-in presets, live palette swap, save/load)
- [x] GUI wiring (settings screen theme picker, profile list, notification triggers)
- [x] Milestone 8 commit

## Phase 8 — Resources & Integration
- [x] Built-in PvP resource pack stub (selectable in settings, enabled by default)
- [x] Real MCP-mapped adapter bridge in /integration (McpAdapter, McpRenderer, McpFont, McpConfig — compiles clean)
- [x] README + integration guide + build instructions (README.md, INTEGRATION.md)
- [x] LICENSE (MIT, attribution preserved) — verified complete
- [x] Changelog (CHANGELOG.md)
- [x] Final compile, format, remove dead code (clean build, zero warnings, unused imports removed, 87 tests pass)
- [x] Milestone 9 commit + complete (commit 967c0fd)
