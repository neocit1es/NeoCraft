# Changelog

All notable changes to **NeoCraft** are documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/), and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

---

## [1.0.0] — 2026

The inaugural release of NeoCraft, a modern, original PvP client layer for Minecraft 1.12.2.

### Added

**Architecture & Foundation**
- Adapter pattern with four portability interfaces: `MinecraftAdapter`, `GameRenderer`, `FontRenderer`, `ConfigStore`.
- Self-contained `StubAdapter` / `StubRenderer` / `StubFont` / `StubConfig` for sandbox compilation and deterministic unit testing.
- Real MCP-mapped integration bridge (`McpAdapter`, `McpRenderer`, `McpFont`, `McpConfig`) in the `/integration` source set, shipped as commented reference implementations.
- JDK 17 / Gradle build with `-Xlint:all -Werror` zero-warning policy and separate core + integration jar tasks.
- NeoCraft client singleton (`NeoCraft.init()` / `get()` / `shutdown()` / `resetForTesting()`) owning all subsystems.
- Centralized branding (`Brand`) and startup banner (`Log`).

**Theming**
- Centralized `Theme` class with static ARGB constants (Primary `#00E5FF`, Secondary `#8B5CF6`, Background `#0E1016`, Panel `#181C24`, Text `#F5F7FA`, Success `#38D39F`, Warning `#F5B041`, Error `#EF4444`) plus a mutable live palette.
- `ThemeRegistry` with five built-in presets: NeoCraft (Cyan), Amethyst, Emerald, Sunset, Crimson.
- Live palette swap on preset change, with save/load persistence and runtime custom preset installation via `install()`.
- Reset-to-defaults support.

**Module Framework**
- `Module` base class with `Category` enum and four `Setting` types: `BooleanSetting`, `SliderSetting`, `ModeSetting`, `KeybindSetting`.
- `ModuleManager` for lifecycle, keybind handling, state persistence, favorites, and search.
- Annotation-driven `EventBus` with `@NeoSubscribe`, priority ordering, and cancellation. `register()` walks the full class hierarchy to discover inherited subscribers.
- Event types: `TickEvent`, `Render2DEvent`, `RenderEvent`, `KeyInputEvent`.

**Modules (16)**
- Render: Fullbright (gamma lock), Zoom (FOV reduction), ReachDisplay (reach distance).
- Movement: Sprint (force-sprint while moving forward).
- HUD: Keystrokes (WASD + mouse with CPS coloring), CPS (left/right counter), Coordinates (XYZ), FPS, Ping, Armor (durability), Potion (effects + duration), Clock, SessionStats (kills/deaths/time).
- System: HudToggle (overlay toggle), HudEditor (opens HUD editor), NotificationsTrigger (toast on configurable events like low health).

**Render & Animation Utilities**
- `RenderUtil` instance class: `glow()`, `progressBar()`, `roundedButton()`, `divider()`, `insetTop()`.
- `Animation` class supporting both duration-based and continuous-lerp modes.
- `Easing` class with eight curves (linear, ease-in/out, ease-in-out, ease-out-back, etc.).
- `ParticleField` for animated GUI backgrounds.
- `PanelRenderer` for translucent rounded glass panels.
- `TextCache` for font width caching and ellipsis truncation.

**HUD System**
- `HudElement` base class with draggable panels, `HudManager` for rendering/editor/persistence, and `TextHudElement` base.
- Nine HUD elements, each rendered as a translucent rounded panel.
- HUD editor with drag, clamp-to-screen, and per-profile layout persistence.
- Element lookup by ID.

**GUI Framework & Screens**
- `Screen` base class with particle background, fade-in animation (adapter-clock-driven for testability), and input routing.
- Widget toolkit: `Widget`, `Button`, `ToggleWidget`, `SliderWidget`, `Label`, `SearchBar`.
- Redesigned **Main Menu**: glass logo panel with brand glow, six rounded buttons (Singleplayer, Multiplayer, Mods, Settings, Credits, Quit), hover glow, gradient vignette, version footer, fade-in. `MenuAction` callback and `buttonIdAt()` helper.
- **ClickGUI**: category sidebar with icons, live search bar, scrollable module cards with expandable settings, favorite stars, keybind badges, animated sidebar slide-in.
- **Settings Screen**: three tabs (Theme, Profiles, General). Theme tab with preset cards and colour swatches; Profiles tab with create/switch/delete; General tab with notification/screenshot/FPS-HUD/coordinates-HUD toggles. Search bar filters presets. `activeTab()` returns the tab name as a `String`.
- **Credits Screen**: brand glow, wrapped MIT license summary, attribution block preserving TuffXPlus and TuffClient credits, ESC to close.
- **Loading Screen**: brand pulse glow, progress bar, cycling loading messages every 2.5 seconds, `setProgress()`/`isDone()`/`setMessage()` API.

**Systems**
- **Notification system**: toast-style, slide-in, severity-colored (info/success/warning/error), auto-dismiss using the adapter clock for deterministic testing. `clear()` support.
- **Profiles**: named switchable config namespaces via `ConfigStore.namespace("profile.<name>")`. Active store cached per profile name, invalidated on switch. Default profile cannot be deleted; deleting the active profile reverts to default.
- **Screenshot manager**: capture via `adapter.takeScreenshot()`, most-recent-first list capped at 24 entries.
- **Resource pack manager**: built-in PvP pack (low-fire, clean GUI, reduced particles), enabled by default, toggleable and persistent. `pack.mcmeta` metadata included.

**Testing**
- 87 unit tests across seven test classes, all passing under JDK 17:
  - `AdapterStubTest` (6) — stub adapter behaviors and test helpers.
  - `CoreSystemsTest` (8) — singleton, event bus, branding.
  - `ModulesTest` (9) — registration, settings, keybinds, favorites, search.
  - `RenderUtilTest` (9) — animation, easing, glow, progress bar, text cache.
  - `HudEditorTest` (6) — drag/clamp/save and element lookup.
  - `GuiTest` (21) — main menu, ClickGUI, settings, credits, loading, fade-in.
  - `SystemsTest` (28) — notifications, profiles, screenshots, theme registry, integration.

**Documentation**
- `README.md` — overview, architecture, feature catalogue, build/test instructions, structure.
- `INTEGRATION.md` — step-by-step 1.12.2 workspace wiring guide.
- `CHANGELOG.md` — this file.
- `LICENSE` — MIT with attribution preserved for TuffXPlus (MIT, © TuffNetwork), TuffClient (inspiration), and Minecraft 1.12.2 (© Mojang AB).

### Design Notes

- NeoCraft's core never imports `net.minecraft.*`; all game access goes through `MinecraftAdapter`. This keeps the project original and free of proprietary code.
- Screen fade-in animations, ClickGUI sidebar animation, loading screen pulse, and notification auto-dismiss all use the adapter clock (`adapter.currentTimeMillis()`) rather than `System.currentTimeMillis()`, ensuring deterministic unit testing.
- The integration bridge compiles in the NeoCraft sandbox (methods throw `UnsupportedOperationException`) and is completed by uncommenting MCP-mapped implementation hints inside the user's 1.12.2 workspace.
- NeoCraft is inspired by but separate from the Tuff Network's TuffClient and the open-source TuffXPlus server plugin. No TuffClient binaries or decompiled code, and no TuffXPlus plugin code, are distributed.

---

[1.0.0]: https://github.com/neocraft/neocraft/releases/tag/v1.0.0
