package org.neocraft.adapter;

import org.neocraft.api.ConfigStore;

// import java.io.File;
// import java.io.FileInputStream;
// import java.io.FileOutputStream;
// import java.util.Properties;

/**
 * Real {@link ConfigStore} implementation backed by a Java {@code Properties}
 * file on disk inside the Minecraft game directory
 * ({@code .minecraft/neocraft/config.properties}).
 *
 * <p>Namespaces are implemented as key-prefixed children: a namespace
 * {@code profile.PvP} stores keys as {@code profile.PvP.<key>}. This mirrors
 * the stub's namespace layering but with real disk persistence.
 *
 * @author NeoCraft
 */
public final class McpConfig implements ConfigStore {

	// private final File file;
	// private final Properties props = new Properties();
	// private final McpConfig parent;
	// private final String prefix;
	//
	// public McpConfig() {
	//     this(new File(Minecraft.getMinecraft().gameDir, "neocraft/config.properties"));
	// }
	//
	// public McpConfig(File file) {
	//     this.file = file;
	//     this.parent = null;
	//     this.prefix = "";
	//     reload();
	// }
	//
	// private McpConfig(McpConfig parent, String prefix) {
	//     this.file = parent.file;
	//     this.parent = parent;
	//     this.prefix = prefix + ".";
	//     this.props = parent.props; // share the underlying Properties object
	// }

	@Override
	public void set(String key, String value) {
		// if (value == null) props.remove(prefix + key);
		// else props.setProperty(prefix + key, value);
		throw new UnsupportedOperationException("Compile in 1.12.2 workspace — see INTEGRATION.md");
	}

	@Override
	public String get(String key, String defaultValue) {
		// String v = props.getProperty(prefix + key);
		// if (v == null && parent != null) return parent.get(key, defaultValue);
		// return v != null ? v : defaultValue;
		throw new UnsupportedOperationException("Compile in 1.12.2 workspace");
	}

	@Override
	public void setInt(String key, int value) {
		// set(key, Integer.toString(value));
		throw new UnsupportedOperationException("Compile in 1.12.2 workspace");
	}

	@Override
	public int getInt(String key, int defaultValue) {
		// String v = get(key, null);
		// if (v == null) return defaultValue;
		// try { return Integer.parseInt(v); } catch (NumberFormatException e) { return defaultValue; }
		throw new UnsupportedOperationException("Compile in 1.12.2 workspace");
	}

	@Override
	public void setDouble(String key, double value) {
		// set(key, Double.toString(value));
		throw new UnsupportedOperationException("Compile in 1.12.2 workspace");
	}

	@Override
	public double getDouble(String key, double defaultValue) {
		// String v = get(key, null);
		// if (v == null) return defaultValue;
		// try { return Double.parseDouble(v); } catch (NumberFormatException e) { return defaultValue; }
		throw new UnsupportedOperationException("Compile in 1.12.2 workspace");
	}

	@Override
	public void setBoolean(String key, boolean value) {
		// set(key, Boolean.toString(value));
		throw new UnsupportedOperationException("Compile in 1.12.2 workspace");
	}

	@Override
	public boolean getBoolean(String key, boolean defaultValue) {
		// String v = get(key, null);
		// if (v == null) return defaultValue;
		// return Boolean.parseBoolean(v);
		throw new UnsupportedOperationException("Compile in 1.12.2 workspace");
	}

	@Override
	public void remove(String key) {
		// props.remove(prefix + key);
		throw new UnsupportedOperationException("Compile in 1.12.2 workspace");
	}

	@Override
	public void save() {
		// try (FileOutputStream out = new FileOutputStream(file)) {
		//     file.getParentFile().mkdirs();
		//     props.store(out, "NeoCraft configuration");
		// } catch (IOException e) {
		//     e.printStackTrace();
		// }
		throw new UnsupportedOperationException("Compile in 1.12.2 workspace");
	}

	@Override
	public void reload() {
		// if (!file.exists()) return;
		// try (FileInputStream in = new FileInputStream(file)) {
		//     props.load(in);
		// } catch (IOException e) {
		//     e.printStackTrace();
		// }
		throw new UnsupportedOperationException("Compile in 1.12.2 workspace");
	}

	@Override
	public ConfigStore namespace(String name) {
		// return new McpConfig(this, name);
		throw new UnsupportedOperationException("Compile in 1.12.2 workspace");
	}
}
