package org.neocraft.adapter;

import org.neocraft.api.GameRenderer;

// import net.minecraft.client.Minecraft;
// import net.minecraft.client.gui.Gui;
// import net.minecraft.client.renderer.GlStateManager;
// import net.minecraft.client.renderer.Tessellator;
// import net.minecraft.client.renderer.BufferBuilder;
// import net.minecraft.client.renderer.vertex.DefaultVertexFormats;

/**
 * Real {@link GameRenderer} implementation backed by Minecraft 1.12.2's
 * GL state manager and Tessellator.
 *
 * <p>Each draw call maps to the equivalent vanilla rendering primitive:
 * <ul>
 *   <li>{@code drawRect} &rarr; {@code Gui.drawRect}</li>
 *   <li>{@code drawRoundedRect} &rarr; custom Tessellator quad with corner clipping</li>
 *   <li>{@code drawGradientRect} &rarr; {@code drawGradientRect} via Tessellator</li>
 *   <li>{@code drawCircle} &rarr; Tessellator triangle fan</li>
 *   <li>{@code drawBlur} &rarr; stencil-based Gaussian blur shader pass</li>
 * </ul>
 *
 * <p>Compile this only inside the 1.12.2 workspace. See INTEGRATION.md.
 *
 * @author NeoCraft
 */
public final class McpRenderer implements GameRenderer {

	// private final Minecraft mc;
	//
	// public McpRenderer(Minecraft mc) {
	//     this.mc = mc;
	// }

	@Override
	public void drawRect(double x, double y, double w, double h, int argb) {
		// int left = (int) x, top = (int) y, right = (int)(x + w), bottom = (int)(y + h);
		// float a = (argb >> 24 & 255) / 255.0f;
		// float r = (argb >> 16 & 255) / 255.0f;
		// float g = (argb >> 8 & 255) / 255.0f;
		// float b = (argb & 255) / 255.0f;
		// Tessellator t = Tessellator.getInstance();
		// BufferBuilder b = t.getBuffer();
		// GlStateManager.enableBlend();
		// GlStateManager.disableTexture2D();
		// GlStateManager.tryBlendFuncSeparate(
		//     SourceFactor.SRC_ALPHA, DestFactor.ONE_MINUS_SRC_ALPHA, ...);
		// GlStateManager.color(r, g, b, a);
		// b.begin(7, DefaultVertexFormats.POSITION);
		// b.pos(left, bottom, 0).endVertex();
		// b.pos(right, bottom, 0).endVertex();
		// b.pos(right, top, 0).endVertex();
		// b.pos(left, top, 0).endVertex();
		// t.draw();
		// GlStateManager.enableTexture2D();
		// GlStateManager.disableBlend();
		throw new UnsupportedOperationException("Compile in 1.12.2 workspace — see INTEGRATION.md");
	}

	@Override
	public void drawRoundedRect(double x, double y, double w, double h, double radius, int argb) {
		// Draw four corner quarter-circles + two rectangles to form a rounded rect
		throw new UnsupportedOperationException("Compile in 1.12.2 workspace");
	}

	@Override
	public void drawHollowRect(double x, double y, double w, double h, float lineWidth, int argb) {
		// Draw four thin rectangles for each edge
		throw new UnsupportedOperationException("Compile in 1.12.2 workspace");
	}

	@Override
	public void drawGradientRect(double x, double y, double w, double h, int topArgb, int bottomArgb) {
		// Tessellator with POSITION_COLOR format, interpolate top->bottom
		throw new UnsupportedOperationException("Compile in 1.12.2 workspace");
	}

	@Override
	public void drawHorizontalGradient(double x, double y, double w, double h, int leftArgb, int rightArgb) {
		// Tessellator with POSITION_COLOR format, interpolate left->right
		throw new UnsupportedOperationException("Compile in 1.12.2 workspace");
	}

	@Override
	public void drawLine(double x1, double y1, double x2, double y2, float lineWidth, int argb) {
		// GlStateManager.glLineWidth(lineWidth); Tessellator LINES mode
		throw new UnsupportedOperationException("Compile in 1.12.2 workspace");
	}

	@Override
	public void drawCircle(double cx, double cy, double r, int argb) {
		// Tessellator triangle fan, 32 segments
		throw new UnsupportedOperationException("Compile in 1.12.2 workspace");
	}

	@Override
	public void drawBlur(double x, double y, double w, double h, float strength) {
		// Stencil mask region, then run Gaussian blur shader (Kwlicants-style)
		throw new UnsupportedOperationException("Compile in 1.12.2 workspace");
	}

	@Override
	public void drawParticle(double x, double y, double size, int argb, float alpha) {
		// Small blended circle or textured point
		throw new UnsupportedOperationException("Compile in 1.12.2 workspace");
	}

	@Override
	public void enableScissor(double x, double y, double w, double h) {
		// GlStateManager.enableScissor();
		// Scale to display resolution: int scale = new ScaledResolution(mc).getScaleFactor();
		// GlStateManager.scissor((int)(x*scale), (int)((sh-y-h)*scale), (int)(w*scale), (int)(h*scale));
		throw new UnsupportedOperationException("Compile in 1.12.2 workspace");
	}

	@Override
	public void disableScissor() {
		// GlStateManager.disableScissor();
		throw new UnsupportedOperationException("Compile in 1.12.2 workspace");
	}

	@Override
	public void pushBlend() {
		// GlStateManager.pushAttrib(); GlStateManager.enableBlend(); ...
		throw new UnsupportedOperationException("Compile in 1.12.2 workspace");
	}

	@Override
	public void popBlend() {
		// GlStateManager.popAttrib();
		throw new UnsupportedOperationException("Compile in 1.12.2 workspace");
	}

	@Override
	public void setGlobalAlpha(float alpha) {
		// GlStateManager.color(1, 1, 1, alpha);
		throw new UnsupportedOperationException("Compile in 1.12.2 workspace");
	}

	@Override
	public float getGlobalAlpha() {
		return 1.0f;
	}

	@Override
	public void setColor(int argb) {
		// GlStateManager.color(r, g, b, a);
		throw new UnsupportedOperationException("Compile in 1.12.2 workspace");
	}
}
