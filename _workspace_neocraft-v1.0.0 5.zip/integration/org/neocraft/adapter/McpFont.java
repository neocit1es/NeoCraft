package org.neocraft.adapter;

import org.neocraft.api.FontRenderer;

// import net.minecraft.client.Minecraft;
// import net.minecraft.util.text.TextFormatting;

/**
 * Real {@link FontRenderer} implementation wrapping Minecraft 1.12.2's
 * built-in font renderer ({@code net.minecraft.client.gui.FontRenderer}).
 *
 * <p>All draw calls delegate to {@code mc.fontRenderer.drawString} with
 * appropriate shadow, colour, and alignment parameters. The NeoCraft color
 * system uses ARGB ints; these are passed directly to the vanilla font renderer
 * which accepts the same format (with alpha in the top byte).
 *
 * @author NeoCraft
 */
public final class McpFont implements FontRenderer {

	// private final net.minecraft.client.gui.FontRenderer fr;
	//
	// public McpFont(Minecraft mc) {
	//     this.fr = mc.fontRenderer;
	// }

	@Override
	public void drawString(String text, double x, double y, int argb, boolean shadow) {
		// fr.drawString(text, (float) x, (float) y, argb, shadow);
		throw new UnsupportedOperationException("Compile in 1.12.2 workspace — see INTEGRATION.md");
	}

	@Override
	public void draw(String text, double x, double y, int argb) {
		// fr.drawStringWithShadow(text, (float) x, (float) y, argb);
		throw new UnsupportedOperationException("Compile in 1.12.2 workspace");
	}

	@Override
	public void drawNoShadow(String text, double x, double y, int argb) {
		// fr.drawString(text, (float) x, (float) y, argb, false);
		throw new UnsupportedOperationException("Compile in 1.12.2 workspace");
	}

	@Override
	public void drawCentered(String text, double x, double y, int argb) {
		// fr.drawStringWithShadow(text,
		//     (float)(x - fr.getStringWidth(text) / 2.0), (float) y, argb);
		throw new UnsupportedOperationException("Compile in 1.12.2 workspace");
	}

	@Override
	public void drawRight(String text, double x, double y, int argb) {
		// fr.drawStringWithShadow(text,
		//     (float)(x - fr.getStringWidth(text)), (float) y, argb);
		throw new UnsupportedOperationException("Compile in 1.12.2 workspace");
	}

	@Override
	public int stringWidth(String text) {
		// return fr.getStringWidth(text);
		throw new UnsupportedOperationException("Compile in 1.12.2 workspace");
	}

	@Override
	public int fontHeight() {
		// return fr.FONT_HEIGHT;
		throw new UnsupportedOperationException("Compile in 1.12.2 workspace");
	}

	@Override
	public java.util.List<String> splitToWidth(String text, int maxWidth) {
		// return fr.listFormattedStringToWidth(text, maxWidth);
		throw new UnsupportedOperationException("Compile in 1.12.2 workspace");
	}
}
