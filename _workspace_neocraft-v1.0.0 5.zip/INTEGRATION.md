# NeoCraft — Integration Guide (Minecraft 1.12.2)

This guide walks you through wiring NeoCraft into an **Eaglercraft 1.12.2 workspace** (or any MCP-mapped Minecraft 1.12.2 development environment). NeoCraft's core is fully portable and contains no proprietary code; the bridge in `/integration` is the only piece that touches Minecraft classes, and it is designed to be completed inside your workspace.

---

## Table of Contents

- [Prerequisites](#prerequisites)
- [Overview](#overview)
- [Step 1 — Add the jars to your workspace](#step-1--add-the-jars-to-your-workspace)
- [Step 2 — Complete the MCP bridge](#step-2--complete-the-mcp-bridge)
- [Step 3 — Initialize NeoCraft](#step-3--initialize-neocraft)
- [Step 4 — Route game events](#step-4--route-game-events)
- [Step 5 — Open the GUIs](#step-5--open-the-guis)
- [Step 6 — Wire the CPS counter](#step-6--wire-the-cps-counter)
- [Step 7 — Verify](#step-7--verify)
- [Adapter method reference](#adapter-method-reference)

---

## Prerequisites

- A working **Eaglercraft 1.12.2** development workspace (or a Forge/ForgeGradle MCP-mapped 1.12.2 environment) with `net.minecraft.*` classes on the classpath.
- **JDK 17** for building the NeoCraft jars.
- The NeoCraft core jar (`NeoCraft-1.0.0-core.jar`) and the integration jar (`NeoCraft-1.0.0-integration.jar`), built via `gradle build` and `gradle integrationJar`.

---

## Overview

NeoCraft uses an adapter pattern. The core (`org.neocraft.*`) only ever calls methods on four interfaces:

- `MinecraftAdapter` — input, timing, player/world state, rendering entry points, config.
- `GameRenderer` — 2D immediate-mode drawing (rects, gradients, circles, blur, particles, scissor, blend).
- `FontRenderer` — string drawing, measurement, wrapping.
- `ConfigStore` — key/value persistence with namespaces.

The `integration` source set provides `McpAdapter`, `McpRenderer`, `McpFont`, and `McpConfig` — concrete implementations of these interfaces. They ship as **commented-out reference implementations** that throw `UnsupportedOperationException` so they compile in the sandbox. Your job is to uncomment the real MCP calls.

```
Your mod  ──▶  NeoCraft.init(new McpAdapter())
                       │
            McpAdapter ─┬─▶ McpRenderer  (Tessellator / GlStateManager)
                        ├─▶ McpFont      (mc.fontRenderer)
                        └─▶ McpConfig    (Properties file on disk)
```

---

## Step 1 — Add the jars to your workspace

**Option A — Jars on the classpath:**

Copy both jars into your workspace's `mods/` or `libs/` directory and add them to your build's `compileOnly`/`implementation` dependencies:

```groovy
dependencies {
    implementation files('libs/NeoCraft-1.0.0-core.jar')
    implementation files('libs/NeoCraft-1.0.0-integration.jar')
}
```

**Option B — Source files (recommended for editing the bridge):**

Copy the entire `integration/org/neocraft/adapter/` tree and the `src/main/java/org/neocraft/` tree into your workspace's source directory. This gives you direct access to uncomment and edit the MCP calls.

Either way, ensure the `org.neocraft.api` interfaces and `org.neocraft.adapter.Mcp*` classes resolve.

---

## Step 2 — Complete the MCP bridge

Open each file in `integration/org/neocraft/adapter/` and uncomment the implementation hints. Each method has a commented-out body showing the intended MCP call.

### McpAdapter.java

Uncomment the field declarations at the top:

```java
private final Minecraft mc = Minecraft.getMinecraft();
private final McpRenderer renderer = new McpRenderer(mc);
private final McpFont fonts = new McpFont(mc.fontRenderer);
private final McpConfig config = new McpConfig();
```

Then uncomment each method body. Key mappings:

| Adapter method | MCP implementation |
|----------------|---------------------|
| `getClientBrand()` | `return org.neocraft.client.Brand.displayVersion();` |
| `getMinecraftVersion()` | `return "Minecraft 1.12.2";` |
| `currentTimeMillis()` | `return System.currentTimeMillis();` (already uncommented) |
| `getPartialTicks()` | `return mc.getRenderPartialTicks();` |
| `getFrameDelta()` | `return mc.getRenderPartialTicks() / 20.0f;` |
| `getFps()` | `return Minecraft.getDebugFPS();` |
| `getScaledWidth()` | `return new ScaledResolution(mc).getScaledWidth();` |
| `getScaledHeight()` | `return new ScaledResolution(mc).getScaledHeight();` |
| `getMouseX()` | `return Mouse.getX() * getScaledWidth() / mc.displayWidth;` |
| `getMouseY()` | `return getScaledHeight() - Mouse.getY() * getScaledHeight() / mc.displayHeight - 1;` |
| `isMouseLeftDown()` | `return Mouse.isButtonDown(0);` |
| `isMouseRightDown()` | `return Mouse.isButtonDown(1);` |
| `isKeyDown(int)` | `return Keyboard.isKeyDown(keyCode);` |
| `isInGame()` | `return mc.player != null && mc.world != null;` |
| `isInWorld()` | `return mc.world != null;` |
| `getPlayerX/Y/Z()` | `return mc.player.posX/posY/posZ;` |
| `getPing()` | `mc.getConnection().getPlayerInfo(mc.player.getUniqueID()).getResponseTime()` |
| `getHealth()` | `return mc.player.getHealth();` |
| `getMaxHealth()` | `return mc.player.getMaxHealth();` |
| `getFood()` | `return mc.player.getFoodStats().getFoodLevel();` |
| `getArmor()` | Sum of `armorInventory` damage reduction |
| `getReach()` | `return mc.playerController.getBlockReachDistance();` |
| `getGamma()` / `setGamma()` | `mc.gameSettings.gammaSetting` |
| `getFov()` / `setFov()` | `mc.gameSettings.fovSetting` |
| `isSprinting()` / `setSprinting()` | `mc.player.isSprinting()` / `mc.player.setSprinting(b)` |
| `isSneaking()` | `return mc.player.isSneaking();` |
| `getMoveSpeed()` | `return mc.player.capabilities.getWalkSpeed();` |
| `renderer()` | `return renderer;` |
| `fonts()` | `return fonts;` |
| `config()` | `return config;` |
| `enableGuiMatrix()` / `disableGuiMatrix()` | GlStateManager push/pop + blend |
| `takeScreenshot()` | `ScreenShotHelper.saveScreenshot(...)` |

For `getLeftClickCps()` / `getRightClickCps()`, see [Step 6](#step-6--wire-the-cps-counter).

### McpRenderer.java

Uncomment the constructor and each draw method. The comments describe the Tessellator/GlStateManager approach for each primitive. For `drawRect`, the vanilla `Gui.drawRect` is a good starting point; for `drawRoundedRect`, compose corner quarter-circles plus two rectangles; for `drawBlur`, use a stencil-based Gaussian blur shader pass. `enableScissor`/`disableScissor` map to `GlStateManager.enableScissor()`/`disableScissor()` with display-resolution scaling.

### McpFont.java

Uncomment the constructor (`this.fr = mc.fontRenderer;`) and delegate every method to the vanilla `FontRenderer`. The ARGB int format NeoCraft uses is directly compatible with `fr.drawString(text, x, y, argb, shadow)`.

### McpConfig.java

Uncomment the `Properties`-backed implementation. The default constructor points at `new File(Minecraft.getMinecraft().gameDir, "neocraft/config.properties")`. Namespaces use a key-prefix layering scheme (`profile.PvP.<key>`), and child stores share the underlying `Properties` object with their parent for atomic saves.

---

## Step 3 — Initialize NeoCraft

From your mod's init event handler (Eaglercraft's `ModInitializer`, Forge's `FMLInitializationEvent`, or your bootstrap equivalent), call:

```java
import org.neocraft.client.NeoCraft;
import org.neocraft.adapter.McpAdapter;

@EventHandler
public void init(FMLInitializationEvent event) {
    NeoCraft.init(new McpAdapter());
}
```

`NeoCraft.init()` is idempotent and safe to call once. It will:

1. Load the persisted theme selection.
2. Register all built-in modules and load their persisted state.
3. Load the HUD layout.
4. Restore the last active profile.
5. Load the resource pack toggle.
6. Print the NeoCraft startup banner.

On shutdown, call `NeoCraft.get().shutdown()` to persist all state.

---

## Step 4 — Route game events

NeoCraft's `EventBus` expects three event types from the host:

### Tick event (every game tick)

```java
NeoCraft.get().events().post(new org.neocraft.events.TickEvent());
```

Fire this from your tick handler (e.g. `ClientTickEvent.Phase.END`). Modules like Sprint and Fullbright react here.

### Render 2D event (every frame, after HUD)

```java
NeoCraft.get().events().post(new org.neocraft.events.Render2DEvent(partialTicks));
```

Fire this from your `RenderGameOverlayEvent.Post` handler (or Eaglercraft's overlay render hook). The HUD manager and notifications render here.

### Key input event (on key press)

```java
NeoCraft.get().events().post(new org.neocraft.events.KeyInputEvent(keyCode));
```

Fire this from your key input handler. The module manager checks keybinds and toggles modules here.

The event bus is annotation-driven: modules subscribe with `@NeoSubscribe` methods. You do not need to manually dispatch to individual modules — just post the three events above.

---

## Step 5 — Open the GUIs

To open the ClickGUI (typically bound to Right Shift or a configurable key):

```java
import org.neocraft.gui.ClickGui;
import org.neocraft.client.NeoCraft;

// In your key handler or GUI-open hook:
ClickGui gui = new ClickGui(NeoCraft.get().adapter());
mc.displayGuiScreen(gui);  // or your Eaglercraft equivalent
```

To open the redesigned main menu, settings, or credits screens:

```java
new org.neocraft.gui.MainMenu(NeoCraft.get().adapter());
new org.neocraft.gui.SettingsScreen(NeoCraft.get().adapter());
new org.neocraft.gui.CreditsScreen(NeoCraft.get().adapter());
```

The `MainMenu` exposes a `MenuAction` callback so you can wire its buttons to your workspace's existing singleplayer/multiplayer screens.

---

## Step 6 — Wire the CPS counter

`getLeftClickCps()` and `getRightClickCps()` need a small CPS counter in `McpAdapter`. Add a timestamp deque and prune clicks older than one second:

```java
private final java.util.ArrayDeque<Long> leftClicks = new java.util.ArrayDeque<>();
private final java.util.ArrayDeque<Long> rightClicks = new java.util.ArrayDeque<>();

// Call from your mouse-click handler (onClick / onMiddleClick etc.):
public void onLeftClick() {
    leftClicks.addLast(System.currentTimeMillis());
    prune(leftClicks);
}
public void onRightClick() {
    rightClicks.addLast(System.currentTimeMillis());
    prune(rightClicks);
}
private void prune(java.util.ArrayDeque<Long> q) {
    long cutoff = System.currentTimeMillis() - 1000L;
    while (!q.isEmpty() && q.peekFirst() < cutoff) q.pollFirst();
}

@Override
public int getLeftClickCps() {
    prune(leftClicks);
    return leftClicks.size();
}
@Override
public int getRightClickCps() {
    prune(rightClicks);
    return rightClicks.size();
}
```

Hook `onLeftClick()`/`onRightClick()` into your workspace's mouse-click event so the deque stays current.

---

## Step 7 — Verify

After completing the bridge and wiring events:

1. Launch the game. You should see the NeoCraft startup banner in the console/log.
2. The HUD elements (FPS, Coordinates, etc.) should render if their modules are enabled.
3. Press your ClickGUI keybind — the rounded ClickGUI should open with the category sidebar and module cards.
4. Open Settings → Theme and switch presets; the live palette should update instantly.
5. Create and switch profiles in Settings → Profiles; module/HUD state should isolate per profile.
6. Exit and relaunch — all state should persist.

If anything throws `UnsupportedOperationException`, you missed uncommenting a method body in the bridge.

---

## Adapter method reference

The complete `MinecraftAdapter` interface (45 methods) is documented in `src/main/java/org/neocraft/api/MinecraftAdapter.java`. Here is the full list grouped by concern:

**Identity:** `getClientBrand()`, `getMinecraftVersion()`

**Timing:** `currentTimeMillis()`, `getPartialTicks()`, `getFps()`, `getFrameDelta()`

**Input:** `isKeyDown(int)`, `isMouseLeftDown()`, `isMouseRightDown()`, `getMouseX()`, `getMouseY()`, `getScaledWidth()`, `getScaledHeight()`

**Player/world:** `isInGame()`, `isInWorld()`, `getPlayerX()`, `getPlayerY()`, `getPlayerZ()`, `getPing()`, `getLeftClickCps()`, `getRightClickCps()`

**Gameplay:** `getHealth()`, `getMaxHealth()`, `getFood()`, `getArmor()`, `getReach()`, `getGamma()`, `setGamma(float)`, `getFov()`, `setFov(float)`, `isSprinting()`, `setSprinting(boolean)`, `isSneaking()`, `getMoveSpeed()`

**Rendering:** `renderer()`, `fonts()`, `enableGuiMatrix()`, `disableGuiMatrix()`

**Persistence:** `config()`, `takeScreenshot()`

The `StubAdapter` in `src/main/java/org/neocraft/adapter/StubAdapter.java` is a complete reference for expected return values and defaults, and is the easiest template to mirror when implementing `McpAdapter`.
