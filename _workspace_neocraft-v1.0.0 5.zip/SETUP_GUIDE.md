# NeoCraft — Setup Guide (Read This First)

You now have the full NeoCraft source tree. This file tells you exactly what you have, what works, and what to do next. No fluff.

---

## What's in this ZIP

```
neocraft/
├── SETUP_GUIDE.md          ← you are here
├── README.md               ← full feature list + architecture
├── INTEGRATION.md          ← detailed 1.12.2 wiring steps
├── CHANGELOG.md            ← version history
├── LICENSE                 ← MIT + attribution
├── todo.md                 ← build roadmap (all done)
├── build.gradle            ← Gradle build (JDK 17)
├── settings.gradle
├── gradle.properties
├── .gitignore
│
├── src/main/java/...       ← the CORE (90 files, fully tested)
├── src/main/resources/     ← resource pack metadata
├── src/test/java/...       ← 87 unit tests (all passing)
└── integration/...         ← the MCP BRIDGE (needs completion)
```

---

## What works RIGHT NOW vs. what doesn't

### ✅ The core — done and tested
All of this is written, compiles with zero warnings, and has 87 passing tests:

- 16 PvP modules (Fullbright, Sprint, Zoom, Keystrokes, CPS, etc.)
- 9 HUD elements with a drag-and-drop editor
- 5 GUI screens (Main Menu, ClickGUI, Settings, Credits, Loading)
- 5 theme presets with live switching
- Profiles, notifications, screenshot manager, resource pack toggle
- Animation system, event bus, centralized theming

**The core is portable Java. It never imports `net.minecraft.*`. It compiles and tests in plain JDK 17 with no Minecraft dependencies.**

### ❌ The bridge — needs completion
The files in `integration/org/neocraft/adapter/` connect the core to Minecraft. Right now every method in them is **commented out** and replaced with `throw UnsupportedOperationException`. This is because this project was built in an environment that doesn't have the proprietary Minecraft classes.

**Until you complete the bridge, NeoCraft will NOT run in Minecraft. It will crash on startup.**

---

## What you need to do (3 steps)

### Step 1 — Get a 1.12.2 workspace ready

You need a Minecraft 1.12.2 development environment with MCP-mapped classes on the classpath. Any of these work:

- An **Eaglercraft 1.12.2** workspace (the original target)
- A **Forge 1.12.2** dev environment (ForgeGradle with MCP mappings)
- Any setup where `net.minecraft.client.Minecraft` and friends resolve

You also need **JDK 17**.

### Step 2 — Complete the bridge (uncomment the code)

Open these 4 files and uncomment the implementation code inside each method:

```
integration/org/neocraft/adapter/McpAdapter.java    (39 methods)
integration/org/neocraft/adapter/McpRenderer.java   (15 methods)
integration/org/neocraft/adapter/McpFont.java       (8 methods)
integration/org/neocraft/adapter/McpConfig.java     (12 methods)
```

Each method already has the correct MCP call written as a comment right above the `throw` line. You literally just:
1. Delete the `// ` prefix from the implementation lines
2. Delete the `throw new UnsupportedOperationException(...)` line
3. Uncomment the field declarations at the top of each file

**The full step-by-step with a method-by-method mapping table is in `INTEGRATION.md`. Read it.**

### Step 3 — Initialize NeoCraft and route events

In your mod's init handler, call:

```java
import org.neocraft.client.NeoCraft;
import org.neocraft.adapter.McpAdapter;

NeoCraft.init(new McpAdapter());
```

Then route three events from your game loop into NeoCraft's event bus:

```java
// Every game tick:
NeoCraft.get().events().post(new org.neocraft.events.TickEvent());

// Every frame (after HUD render):
NeoCraft.get().events().post(new org.neocraft.events.Render2DEvent(partialTicks));

// On key press:
NeoCraft.get().events().post(new org.neocraft.events.KeyInputEvent(keyCode));
```

And wire the CPS counter (mouse click → timestamp deque). See INTEGRATION.md Step 6.

On shutdown: `NeoCraft.get().shutdown();`

**That's it.** Once the bridge is uncommented and events are routed, NeoCraft runs.

---

## How to verify the core works (before touching Minecraft)

If you have JDK 17 and Gradle 8.5+ installed, you can prove the core is solid right now:

```bash
cd neocraft
gradle clean build        # should say BUILD SUCCESSFUL
gradle test --rerun-tasks # should show 87 PASSED, 0 FAILED
```

If you don't have Gradle installed, generate a wrapper first:

```bash
gradle wrapper --gradle-version 8.5
./gradlew build
./gradlew test
```

This builds and tests the core against the stub adapter — no Minecraft needed. It proves the logic is correct.

---

## What you can build into jars

```bash
gradle build             # → build/libs/NeoCraft-1.0.0-core.jar
gradle integrationJar    # → build/libs/NeoCraft-1.0.0-integration.jar
```

- **core.jar** — the portable core. Always builds.
- **integration.jar** — the bridge. Builds here as stubs; becomes real after you uncomment the code in your 1.12.2 workspace.

---

## Quick troubleshooting

| Problem | Cause | Fix |
|---------|-------|-----|
| `UnsupportedOperationException` at runtime | Bridge method still commented out | Uncomment it (see INTEGRATION.md) |
| Won't compile in your workspace | Minecraft classes not on classpath | Ensure MCP mappings are set up |
| Nothing renders on screen | Events not routed | Post TickEvent/Render2DEvent/KeyInputEvent |
| HUD won't show | HudToggle module off or HUD elements disabled | Enable via ClickGUI |
| Tests fail after edits | You changed core behavior | Run `gradle test` to see which |

---

## The honest summary

- **The core is finished and proven.** 87 tests, zero warnings, clean architecture.
- **The bridge is a template, not working code.** You must uncomment the MCP calls inside your 1.12.2 workspace.
- **Estimated work for you:** 1–2 hours of uncommenting + wiring events, assuming you have a working 1.12.2 dev setup. INTEGRATION.md walks you through every method.

Read `INTEGRATION.md` next — it has the complete method-to-MCP mapping table and event routing details.
